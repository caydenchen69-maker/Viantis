# Viantis

A cross-platform study companion for students, built with **React Native (Expo SDK 57)**, **TypeScript** and **Tailwind CSS via NativeWind**. Clean, minimal UI on a `#F9FAFB` canvas with indigo/violet accents and a persisted dark-mode toggle.

## Features

| Area | What's included |
| --- | --- |
| **Dashboard** | Streak/XP hero card, quick actions, focus-timer quick start, today's plan, weekly activity chart, upcoming deadlines, arcade & community teasers. |
| **Smart Schedule** | Weekly calendar strip planner, tasks with subjects/priorities/estimates, task editor, overdue tracking. |
| **Pomodoro timer** | Drift-free timer (absolute end timestamp), focus/short/long phases, presets, auto-start breaks, chime + haptics, ambient sound loops, XP + session logging on completion. |
| **Study Arcade** | Quiz engine that turns flashcards into games: **Space Shooter**, **Trivia Tower** (lives + floors), **Flashcard Match** (memory grid). XP scoring, personal bests, global/friends leaderboards, customizable emoji avatars. |
| **AI Homework Helper** | Streaming chat UI with markdown-lite rendering, suggested prompts, camera/library image upload with OCR pass, stop/regenerate. Works in demo mode offline; plugs into your own LLM proxy. |
| **School Finder** | Location-aware search (expo-location) with Haversine distance sort, map view (react-native-maps; list fallback on web), filters for type, majors, acceptance rate, rating and radius, detail page with student reviews. |
| **Community** | Hot/New/Top feed, tag filters (`#Exams`, `#CollegePrep`…), up/downvotes, nested comment threads, post composer, report + moderator removal, realtime study-lounge chat. |

Everything renders from **mock data** out of the box. Add Supabase credentials and the services switch to live queries automatically.

## Getting started

```bash
npm install
cp .env.example .env        # optional – app runs fully in demo mode without it
npm start                   # Expo dev server → press i / a / w
```

Useful scripts:

```bash
npm run typecheck   # tsc --noEmit
npm run lint        # eslint (expo config + React Compiler rules)
npm run test:bundle # expo export for web to /tmp/viantis-web (smoke test)
```

> `react-native-maps`, `expo-location`, `expo-image-picker` and `expo-audio` need a development build (`npx expo run:ios` / `run:android`) rather than Expo Go for full functionality.

## Project structure

```
App.tsx                     Entry: providers + root navigator
global.css                  Tailwind layers (NativeWind input)
tailwind.config.js          Design tokens (brand palette, surfaces, radii)
babel.config.js / metro.config.js  NativeWind wiring
supabase/schema.sql         Tables, RLS policies, realtime publication
assets/sounds/              Procedurally generated chime + ambient loops
src/
  components/
    ui/          Text, Card, Button, Chip, Badge, Avatar, Input, Screen, Skeleton…
    dashboard/   StreakCard, FocusCard, QuickActions, WeeklyActivity, Header
    schedule/    CalendarStrip, TaskItem, TimerRing
    arcade/      GameCard, QuizRound, MatchGrid, LeaderboardRow
    ai/          ChatBubble (markdown-lite), ChatComposer
    finder/      SchoolCard, FilterSheet, SchoolMap (+ .web fallback)
    community/   PostCard, CommentItem
  screens/       One folder per feature (dashboard, schedule, arcade, ai, finder, community, settings, auth)
  navigation/    RootNavigator (native stack) → TabNavigator (5 tabs) → ScheduleStack; typed params + deep links
  services/      supabase client, auth, tasks, arcade, ai, schools, community, chat (realtime), sound
  hooks/         useAsync, useTasks, usePomodoro, useStudyStats, useLocation, useRealtimeChat, useImagePicker
  providers/     ThemeProvider (light/dark/system, persisted), AuthProvider (Supabase session or guest)
  data/          Mock data for every feature
  constants/     Theme tokens, runtime config, XP rules
  types/         Shared domain models
  utils/         date, format, cn
```

### Navigation

```
RootStack
├── Tabs
│   ├── ScheduleTab  → ScheduleStack: Dashboard (landing) → Planner
│   ├── ArcadeTab
│   ├── AIHelperTab
│   ├── FinderTab
│   └── CommunityTab
├── Pomodoro · TaskEditor (modal) · Leaderboard · SchoolDetail
├── PostDetail · CreatePost (modal) · CommunityChat · Settings (modal)
└── Game · Auth (full-screen modals)
```

The Dashboard is the root of the **Schedule** tab so the tab bar keeps the five requested destinations while the app still opens on an overview. Detail screens live on the root stack so any tab can push them and so the tab bar hides during focus sessions and games.

## Design system

- **Type**: Instrument Serif for display/headings, Inter for UI text (`src/constants/typography.ts`, loaded in `App.tsx`). Use the `Text` component's `variant` / `weight` / `italic` props rather than raw `font-*` classes so the right static font file is picked on every platform.
- **Colour**: `#F9FAFB` canvas, near-black ink, one `deep` indigo-black panel per screen as the focal point, indigo reserved for a few accents (progress, "today", upvotes). Arcade games use muted paper tints (`tints` in `theme.ts`) instead of gradients.
- **Layout**: hairline-divided rows for lists; cards only where the content is a discrete object (posts, schools). Pill buttons and inputs, monogram avatars.

## Theming

- Tailwind tokens live in `tailwind.config.js` (`primary` indigo, `accent` violet, `canvas`/`surface`/`deep`/`ink`/`line` with `-dark` variants). Use `dark:` classes for dark mode.
- `src/constants/theme.ts` mirrors those tokens for places that need raw values (icons, tints, navigation theme).
- `ThemeProvider` persists the preference (`light` / `dark` / `system`) and drives NativeWind's `colorScheme`, React Navigation's theme and the status bar together. Toggle from the dashboard header or Settings.

## Backend integration

### Supabase

1. Create a project and run `supabase/schema.sql` in the SQL editor.
2. Set `EXPO_PUBLIC_SUPABASE_URL` and `EXPO_PUBLIC_SUPABASE_ANON_KEY` in `.env`.
3. Restart the dev server. Auth (email/password, magic link), tasks, sessions, posts, comments, votes, leaderboard and realtime chat now hit Supabase; anything that fails falls back gracefully.

`src/services/supabase.ts` exports `supabase` (nullable) and `TABLES`. Each service checks for the client and otherwise uses in-memory mock stores, so screens never need to know which mode they're in.

### AI Helper

Exported / public builds never call a language-model provider. The helper uses local demo answers so no API URL or key exists in the client bundle.

Live calls are limited to this repo in the IDE: put `LLM_UPSTREAM_URL` and `LLM_API_KEY` in `.env` (not `EXPO_PUBLIC_*`), then `npm run ai-gateway`. The process listens on loopback only and rate-limits requests. The app talks to it only while `__DEV__` is true (`npm start`).

### Maps

iOS uses Apple Maps out of the box. For Android add a Google Maps key under `android.config.googleMaps.apiKey` in `app.json` (or read `EXPO_PUBLIC_GOOGLE_MAPS_ANDROID_KEY` in a config plugin).

## Roadmap ideas

- Persist arcade best scores and streak roll-over server-side (`increment_xp` RPC is in the schema).
- Add `cafe`, `forest`, `lofi` ambient loops to `assets/sounds` and register them in `sound.service.ts`.
- Push notifications for task deadlines via `expo-notifications` (plugin is already configured).
- Web map via MapLibre in `SchoolMap.web.tsx`.
