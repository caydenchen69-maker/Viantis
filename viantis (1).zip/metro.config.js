const path = require('path');
const { getDefaultConfig } = require('expo/metro-config');
const { withNativeWind } = require('nativewind/metro');

const config = getDefaultConfig(__dirname);
const isProduction = process.env.NODE_ENV === 'production';

if (isProduction) {
  const defaultResolve = config.resolver.resolveRequest;
  config.resolver.resolveRequest = (context, moduleName, platform) => {
    if (moduleName === './ai.live' || moduleName.endsWith('/services/ai.live')) {
      return {
        type: 'sourceFile',
        filePath: path.resolve(__dirname, 'src/services/ai.live.stub.ts'),
      };
    }
    if (defaultResolve) return defaultResolve(context, moduleName, platform);
    return context.resolveRequest(context, moduleName, platform);
  };
}

module.exports = withNativeWind(config, { input: './global.css' });
