#!/usr/bin/env node
/**
 * Keep the static web preview reachable.
 *
 * The app itself is a static export. What goes down is the local file
 * server or the Cloudflare quick tunnel in front of it. This process
 * watches both, restarts them, and writes the live URL to
 * /tmp/viantis-preview-url.txt.
 *
 * Quick tunnels still change hostname after a hard restart. For a
 * permanent link, deploy the export to Cloudflare Pages / Netlify / Vercel.
 */
import { spawn } from 'node:child_process';
import { writeFileSync, existsSync } from 'node:fs';

const PORT = Number(process.env.PREVIEW_PORT || 8081);
const WEB_DIR = process.env.PREVIEW_DIR || '/tmp/viantis-web';
const URL_FILE = '/tmp/viantis-preview-url.txt';
const LOG_FILE = '/tmp/viantis-preview-keeper.log';
const CLOUDFLARED = process.env.CLOUDFLARED || '/tmp/cloudflared';

const children = new Set();
let tunnelUrl = '';

const log = (msg) => {
  const line = `[${new Date().toISOString()}] ${msg}`;
  console.log(line);
  try {
    writeFileSync(LOG_FILE, `${line}\n`, { flag: 'a' });
  } catch {
    // ignore log write failures
  }
};

const writeUrl = (url) => {
  tunnelUrl = url;
  writeFileSync(URL_FILE, `${url}\n`);
  log(`preview url ${url}`);
};

const spawnTracked = (command, args, { onStdout, onStderr } = {}) => {
  const child = spawn(command, args, { stdio: ['ignore', 'pipe', 'pipe'] });
  children.add(child);
  child.stdout.on('data', (buf) => onStdout?.(buf.toString()));
  child.stderr.on('data', (buf) => onStderr?.(buf.toString()));
  child.on('exit', () => children.delete(child));
  return child;
};

const waitFor = (fn, timeoutMs, intervalMs = 400) =>
  new Promise((resolve, reject) => {
    const start = Date.now();
    const tick = async () => {
      try {
        if (await fn()) return resolve(true);
      } catch {
        // keep waiting
      }
      if (Date.now() - start > timeoutMs) return reject(new Error('timed out'));
      setTimeout(tick, intervalMs);
    };
    tick();
  });

const httpOk = async (url) => {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 8000);
  try {
    const res = await fetch(url, { signal: ctrl.signal, redirect: 'follow' });
    return res.ok;
  } catch {
    return false;
  } finally {
    clearTimeout(timer);
  }
};

const ensureExport = () => {
  if (!existsSync(`${WEB_DIR}/index.html`)) {
    throw new Error(`No web export at ${WEB_DIR}. Run: npm run test:bundle`);
  }
};

const startServe = () => {
  log(`starting serve on :${PORT}`);
  return spawnTracked('npx', ['--yes', 'serve', '-s', '-l', String(PORT), WEB_DIR], {
    onStdout: (text) => {
      if (text.includes('Accepting') || text.includes('http')) log(text.trim());
    },
    onStderr: (text) => log(text.trim()),
  });
};

const startTunnel = () => {
  if (!existsSync(CLOUDFLARED)) {
    throw new Error(`cloudflared missing at ${CLOUDFLARED}`);
  }
  log('starting cloudflared (http2)');
  return spawnTracked(
    CLOUDFLARED,
    ['tunnel', '--url', `http://127.0.0.1:${PORT}`, '--protocol', 'http2', '--no-autoupdate'],
    {
      onStdout: (text) => {
        const match = text.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/);
        if (match) writeUrl(match[0]);
        if (text.includes('ERR') || text.includes('INF |')) log(text.trim());
      },
      onStderr: (text) => {
        const match = text.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/);
        if (match) writeUrl(match[0]);
        log(text.trim());
      },
    },
  );
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const supervise = async () => {
  ensureExport();

  let serve = null;
  let tunnel = null;

  const localUrl = `http://127.0.0.1:${PORT}/`;

  for (;;) {
    if (!(await httpOk(localUrl))) {
      if (serve && serve.exitCode == null) serve.kill('SIGTERM');
      serve = startServe();
      await waitFor(() => httpOk(localUrl), 20000);
      log('local serve is up');
    }

    if (!tunnel || tunnel.exitCode != null) {
      tunnelUrl = '';
      tunnel = startTunnel();
      await waitFor(() => Boolean(tunnelUrl), 30000);
      log('public hostname printed — leaving the process up unless it exits');
    }

    await sleep(8000);
  }
};

const shutdown = () => {
  for (const child of children) {
    try {
      child.kill('SIGTERM');
    } catch {
      // already gone
    }
  }
  process.exit(0);
};

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

supervise().catch((err) => {
  log(err.stack || err.message);
  process.exit(1);
});
