/**
 * Loopback-only LLM gateway. Bind is 127.0.0.1 so nothing on the network
 * (including the public web export) can reach the upstream provider.
 *
 * Env (server-only, never EXPO_PUBLIC_*):
 *   LLM_UPSTREAM_URL  POST target for chat JSON { messages }
 *   LLM_API_KEY       sent as Authorization: Bearer
 *   LLM_OCR_URL       optional POST target for { image }
 *   AI_GATEWAY_PORT   default 8787
 */
import { readFileSync } from 'node:fs';
import http from 'node:http';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

try {
  const envPath = join(dirname(fileURLToPath(import.meta.url)), '..', '.env');
  for (const line of readFileSync(envPath, 'utf8').split('\n')) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq < 1) continue;
    const key = trimmed.slice(0, eq).trim();
    const value = trimmed.slice(eq + 1).trim().replace(/^['"]|['"]$/g, '');
    if (key && process.env[key] === undefined) process.env[key] = value;
  }
} catch {
  // .env is optional; process env is enough
}

const HOST = '127.0.0.1';
const PORT = Number.parseInt(process.env.AI_GATEWAY_PORT || '8787', 10);
const UPSTREAM = (process.env.LLM_UPSTREAM_URL || '').trim();
const OCR_UPSTREAM = (process.env.LLM_OCR_URL || '').trim();
const API_KEY = (process.env.LLM_API_KEY || '').trim();

const WINDOW_MS = 10 * 60 * 1000;
const MAX_PER_WINDOW = 8;
const DAY_MS = 24 * 60 * 60 * 1000;
const MAX_PER_DAY = 40;
const MAX_BODY_BYTES = 180_000;
const MAX_MESSAGES = 8;
const MAX_CHARS = 4_000;
const MAX_IMAGES = 1;
const MAX_IMAGE_CHARS = 800_000;
const UPSTREAM_TIMEOUT_MS = 25_000;

/** @type {Map<string, number[]>} */
const hits = new Map();
/** @type {Set<string>} */
const inflight = new Set();

const isLoopback = (addr) =>
  addr === '127.0.0.1' || addr === '::1' || addr === ':ffff:127.0.0.1';

const prune = (list, since) => list.filter((t) => t > since);

const limited = (ip) => {
  const now = Date.now();
  const next = prune(hits.get(ip) ?? [], now - DAY_MS);
  const recent = next.filter((t) => t > now - WINDOW_MS);
  if (recent.length >= MAX_PER_WINDOW || next.length >= MAX_PER_DAY) return true;
  next.push(now);
  hits.set(ip, next);
  return false;
};

const readBody = (req) =>
  new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY_BYTES) {
        reject(Object.assign(new Error('payload too large'), { status: 413 }));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });

const sanitizeMessages = (raw) => {
  if (!Array.isArray(raw)) return null;
  const messages = raw.slice(0, MAX_MESSAGES).map((m) => {
    const role = m?.role === 'assistant' || m?.role === 'system' ? m.role : 'user';
    const content = String(m?.content ?? '').slice(0, MAX_CHARS);
    const images = Array.isArray(m?.images)
      ? m.images
          .filter((img) => typeof img === 'string' && img.length <= MAX_IMAGE_CHARS)
          .slice(0, MAX_IMAGES)
      : undefined;
    return images?.length ? { role, content, images } : { role, content };
  });
  return messages.every((m) => m.content.trim() || m.images?.length) ? messages : null;
};

const json = (res, status, body) => {
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Cache-Control': 'no-store',
  });
  res.end(JSON.stringify(body));
};

const forward = async (url, payload) => {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), UPSTREAM_TIMEOUT_MS);
  try {
    const headers = { 'Content-Type': 'application/json' };
    if (API_KEY) headers.Authorization = `Bearer ${API_KEY}`;
    const res = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
      signal: ctrl.signal,
    });
    const text = await res.text();
    if (!res.ok) throw Object.assign(new Error('upstream'), { status: 502 });
    return text;
  } finally {
    clearTimeout(timer);
  }
};

const server = http.createServer(async (req, res) => {
  const ip = req.socket.remoteAddress || '';
  if (!isLoopback(ip)) {
    json(res, 403, { error: 'forbidden' });
    return;
  }
  if (req.method !== 'POST') {
    json(res, 404, { error: 'not found' });
    return;
  }

  const url = new URL(req.url || '/', `http://${HOST}`);
  const isChat = url.pathname === '/chat';
  const isOcr = url.pathname === '/ocr';
  if (!isChat && !isOcr) {
    json(res, 404, { error: 'not found' });
    return;
  }
  if (isChat && !UPSTREAM) {
    json(res, 503, { error: 'unavailable' });
    return;
  }
  if (isOcr && !OCR_UPSTREAM) {
    json(res, 503, { error: 'unavailable' });
    return;
  }
  if (inflight.has(ip)) {
    json(res, 429, { error: 'busy' });
    return;
  }
  if (limited(ip)) {
    json(res, 429, { error: 'rate limited' });
    return;
  }

  inflight.add(ip);
  try {
    const parsed = JSON.parse(await readBody(req));
    if (isChat) {
      const messages = sanitizeMessages(parsed.messages);
      if (!messages) {
        json(res, 400, { error: 'invalid' });
        return;
      }
      const raw = await forward(UPSTREAM, { messages });
      try {
        const asJson = JSON.parse(raw);
        json(res, 200, { content: String(asJson.content ?? asJson.choices?.[0]?.message?.content ?? '') });
      } catch {
        res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
        res.end(raw);
      }
      return;
    }

    const image = typeof parsed.image === 'string' ? parsed.image.slice(0, MAX_IMAGE_CHARS) : '';
    if (!image) {
      json(res, 400, { error: 'invalid' });
      return;
    }
    const raw = await forward(OCR_UPSTREAM, { image });
    const asJson = JSON.parse(raw);
    json(res, 200, { text: String(asJson.text ?? '') });
  } catch (err) {
    const status = err && typeof err === 'object' && 'status' in err ? Number(err.status) || 502 : 502;
    json(res, status, { error: status === 413 ? 'too large' : status === 429 ? 'rate limited' : 'unavailable' });
  } finally {
    inflight.delete(ip);
  }
});

server.listen(PORT, HOST, () => {
  console.log(`AI gateway listening on ${HOST}:${PORT} (loopback only)`);
  console.log(`upstream: ${UPSTREAM ? 'configured' : 'missing LLM_UPSTREAM_URL'}`);
});
