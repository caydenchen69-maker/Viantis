import './global.css';

import { useFonts } from 'expo-font';
import React, { Component, useEffect, useState, type ErrorInfo, type ReactNode } from 'react';
import { ActivityIndicator, Pressable, View } from 'react-native';

import { Text } from '@/components/ui';
import { fontAssets } from '@/constants/typography';
import { RootNavigator } from '@/navigation';
import { AppProviders, useAuth, useTheme } from '@/providers';

const FONT_TIMEOUT_MS = 2500;

class ErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state: { error: Error | null } = { error: null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('Viantis render error', error, info.componentStack);
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 28, backgroundColor: '#FBF7F0' }}>
        <Text variant="heading" className="text-center">
          Something went wrong
        </Text>
        <Text variant="caption" tone="muted" className="mt-2 text-center">
          {this.state.error.message}
        </Text>
        <Pressable
          onPress={() => this.setState({ error: null })}
          style={{ marginTop: 20, paddingHorizontal: 20, paddingVertical: 10, backgroundColor: '#111827', borderRadius: 999 }}
        >
          <Text variant="label" style={{ color: '#FFFFFF' }}>
            Try again
          </Text>
        </Pressable>
      </View>
    );
  }
}

function AppShell({ fontsReady }: { fontsReady: boolean }) {
  const { ready, colors } = useTheme();
  const { loading } = useAuth();

  if (!ready || loading || !fontsReady) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.canvas }}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  return <RootNavigator />;
}

export default function App() {
  const [fontsLoaded, fontError] = useFonts(fontAssets);
  const [timedOut, setTimedOut] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setTimedOut(true), FONT_TIMEOUT_MS);
    return () => clearTimeout(timer);
  }, []);

  // Never block the UI on a stalled font download. System fonts take over if needed.
  const fontsReady = fontsLoaded || fontError !== null || timedOut;

  return (
    <ErrorBoundary>
      <AppProviders>
        <AppShell fontsReady={fontsReady} />
      </AppProviders>
    </ErrorBoundary>
  );
}
