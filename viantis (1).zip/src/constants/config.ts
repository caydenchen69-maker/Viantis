// Runtime configuration derived from EXPO_PUBLIC_* environment variables.
// Everything here is safe to ship in the client bundle. Keys must be accessed
// statically so Expo can inline them at build time.

const nonEmpty = (value: string | undefined) => (value && value.length > 0 ? value : undefined);

export const config = {
  supabaseUrl: nonEmpty(process.env.EXPO_PUBLIC_SUPABASE_URL),
  supabaseAnonKey: nonEmpty(process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY),
  googleMapsAndroidKey: nonEmpty(process.env.EXPO_PUBLIC_GOOGLE_MAPS_ANDROID_KEY),
} as const;

export const isSupabaseConfigured = Boolean(config.supabaseUrl && config.supabaseAnonKey);

export const APP_NAME = 'Viantis';

export const STORAGE_KEYS = {
  themePreference: '@viantis/theme',
  pomodoroSettings: '@viantis/pomodoro',
  onboardingComplete: '@viantis/onboarding',
  guestProfile: '@viantis/guest-profile',
  helperMode: '@viantis/helper-mode',
  helperDraft: '@viantis/helper-draft',
  userDecks: '@viantis/user-decks',
  sharedLibrary: '@viantis/shared-library',
  userTasks: '@viantis/user-tasks',
  userSessions: '@viantis/user-sessions',
} as const;

export const XP_RULES = {
  focusSessionComplete: 25,
  taskComplete: 40,
  gameRound: 15,
  postCreated: 10,
  helpfulComment: 5,
  dailyStreakBonus: 20,
} as const;

/** XP required to reach a given level (quadratic curve keeps early levels quick). */
export const xpForLevel = (level: number) => Math.round(100 * level * level * 0.75);

export const levelForXP = (xp: number) => {
  let level = 1;
  while (xpForLevel(level + 1) <= xp) level += 1;
  return level;
};
