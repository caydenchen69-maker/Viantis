// Single source of truth for design tokens that need to be consumed
// outside of className props (navigation theme, icon colors, SVG).
// Keep in sync with tailwind.config.js.
//
// Editorial VIANTIS system: charcoal canvas, cream dossier cards,
// coral-red accents, black/white type.

export const palette = {
  charcoal: {
    950: '#0C1211',
    900: '#121D1B',
    800: '#1A2422',
    700: '#24302D',
    600: '#2F3C39',
  },
  cream: {
    50: '#FBF7F0',
    100: '#F4EFE6',
    200: '#E8E0D2',
    300: '#D4C9B6',
  },
  coral: {
    50: '#FDECEC',
    100: '#F8C9C9',
    400: '#EE7A7A',
    500: '#E55C5C',
    600: '#D14A4A',
    700: '#B33B3B',
  },
  gray: {
    50: '#F5F4F1',
    100: '#EDECE8',
    200: '#D8D6D0',
    300: '#B8B5AE',
    400: '#8A8780',
    500: '#6B6862',
    600: '#4A4844',
    700: '#2E2C29',
    800: '#1A1917',
    900: '#111111',
    950: '#0A0A0A',
  },
  deep: '#121D1B',
  deepDark: '#0C1211',
  success: '#2F6B4F',
  warning: '#C4841D',
  danger: '#D14A4A',
  info: '#3D6B73',
  white: '#FFFFFF',
} as const;

export interface ThemeColors {
  canvas: string;
  surface: string;
  surfaceMuted: string;
  cream: string;
  deep: string;
  line: string;
  ink: string;
  inkMuted: string;
  inkSubtle: string;
  primary: string;
  primarySoft: string;
  accent: string;
  accentSoft: string;
  header: string;
  tabBar: string;
  tabInactive: string;
  success: string;
  warning: string;
  danger: string;
}

export const lightColors: ThemeColors = {
  canvas: '#FBF7F0',
  surface: '#FFFFFF',
  surfaceMuted: '#F4EFE6',
  cream: palette.cream[100],
  deep: palette.charcoal[900],
  line: '#E4DDD2',
  ink: '#111111',
  inkMuted: '#5C5852',
  inkSubtle: '#8A8780',
  primary: palette.coral[500],
  primarySoft: palette.coral[50],
  accent: palette.coral[500],
  accentSoft: palette.coral[50],
  header: palette.gray[100],
  tabBar: '#FFFFFF',
  tabInactive: '#8A8780',
  success: palette.success,
  warning: palette.warning,
  danger: palette.danger,
};

export const darkColors: ThemeColors = {
  canvas: palette.charcoal[900],
  surface: palette.charcoal[800],
  surfaceMuted: palette.charcoal[700],
  cream: palette.cream[100],
  deep: palette.charcoal[950],
  line: '#2A3532',
  ink: '#F6F1E8',
  inkMuted: '#B8B3A8',
  inkSubtle: '#7A766E',
  primary: palette.coral[400],
  primarySoft: 'rgba(229, 92, 92, 0.16)',
  accent: palette.coral[400],
  accentSoft: 'rgba(229, 92, 92, 0.16)',
  header: palette.gray[100],
  tabBar: palette.charcoal[800],
  tabInactive: '#7A766E',
  success: '#6EBA8F',
  warning: '#E4B44A',
  danger: '#EE7A7A',
};

/** Quiet tints for arcade games and subject accents — still colorful, never neon. */
export interface Tint {
  bg: string;
  fg: string;
}

export type TintName = 'indigo' | 'amber' | 'mint' | 'rose' | 'sky';

const lightTints: Record<TintName, Tint> = {
  indigo: { bg: '#E4E0F6', fg: '#2C2756' },
  amber: { bg: '#F3E4C2', fg: '#5C3D12' },
  mint: { bg: '#D5E8DC', fg: '#1F3D2E' },
  rose: { bg: '#F3D6D4', fg: '#6B2A2A' },
  sky: { bg: '#D7E4E6', fg: '#1E3A3E' },
};

const darkTints: Record<TintName, Tint> = {
  indigo: { bg: '#2A2744', fg: '#D4CFF0' },
  amber: { bg: '#3D2F18', fg: '#F0D9A8' },
  mint: { bg: '#1C3328', fg: '#C5E4D2' },
  rose: { bg: '#3A2222', fg: '#F0C8C4' },
  sky: { bg: '#1C3034', fg: '#C5DDE0' },
};

export const tints = lightTints;

export const tintFor = (name: TintName, isDark: boolean): Tint => (isDark ? darkTints : lightTints)[name];

export const spacing = {
  screenX: 20,
  cardPadding: 16,
  sectionGap: 28,
} as const;

export const radii = {
  card: 10,
  pill: 999,
} as const;
