import type { ImageSourcePropType } from 'react-native';

export type CampusPhotoId = 'harvard' | 'stanford' | 'mit' | 'yale' | 'princeton' | 'columbia';

export const campusPhotos: Record<CampusPhotoId, ImageSourcePropType> = {
  harvard: require('../../assets/images/campus/college-harvard.jpg'),
  stanford: require('../../assets/images/campus/college-stanford.jpg'),
  mit: require('../../assets/images/campus/college-mit.jpg'),
  yale: require('../../assets/images/campus/college-yale.jpg'),
  princeton: require('../../assets/images/campus/college-princeton.jpg'),
  columbia: require('../../assets/images/campus/college-columbia.jpg'),
};

export const campusCaptions: Record<CampusPhotoId, string> = {
  harvard: 'Harvard · Widener Library',
  stanford: 'Stanford · Main Quad',
  mit: 'MIT · Killian Court',
  yale: 'Yale · Harkness Tower',
  princeton: 'Princeton · Nassau Hall',
  columbia: 'Columbia · Low Library',
};

const bySchoolId: Partial<Record<string, CampusPhotoId>> = {
  sc1: 'mit',
  sc7: 'harvard',
};

const cycle: CampusPhotoId[] = ['harvard', 'stanford', 'mit', 'yale', 'princeton', 'columbia'];

export const photoForSchool = (id: string): CampusPhotoId => {
  const mapped = bySchoolId[id];
  if (mapped) return mapped;
  const n = [...id].reduce((acc, ch) => acc + ch.charCodeAt(0), 0);
  return cycle[n % cycle.length]!;
};
