import { Ionicons } from '@expo/vector-icons';
import React, { useCallback, useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { BrandHeader } from '@/components/brand';
import { PostCard } from '@/components/community/PostCard';
import { CampusPhoto, Chip, Screen, SegmentedControl, Skeleton, Text } from '@/components/ui';
import { mockTags } from '@/data';
import { useAsync, useAuth } from '@/hooks';
import type { TabScreenProps } from '@/navigation/types';
import { useTheme } from '@/providers/ThemeProvider';
import { communityService, type FeedSort } from '@/services';
import type { Post } from '@/types';

export function CommunityScreen({ navigation }: TabScreenProps<'CommunityTab'>) {
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { session } = useAuth();
  const [sort, setSort] = useState<FeedSort>('hot');
  const [tag, setTag] = useState<string | null>(null);

  const { data: posts, loading, refresh, setData } = useAsync(() => communityService.listPosts({ sort, tag }), [sort, tag]);

  const vote = useCallback(
    async (post: Post, direction: 1 | -1) => {
      const updated = await communityService.votePost(post, direction, session?.user.id);
      setData((prev) => prev?.map((p) => (p.id === post.id ? updated : p)));
    },
    [session?.user.id, setData],
  );

  return (
    <View className="flex-1 bg-canvas dark:bg-canvas-dark">
      <BrandHeader />
      <Screen refreshing={loading} onRefresh={refresh} safeTop={false} contentClassName="pb-28">
        <Text variant="overline" tone="primary" className="mb-2" style={{ letterSpacing: 1.6 }}>
          Collective
        </Text>
        <Text variant="display" className="mb-4">
          Community
        </Text>
        <CampusPhoto photo="yale" height={132} dim={0.28} className="mb-5">
          <View className="flex-1 justify-end p-4">
            <Text variant="caption" tone="inverseMuted">
              Yale · Harkness Tower
            </Text>
            <Text variant="heading" tone="inverse" className="mt-1">
              Study together
            </Text>
          </View>
        </CampusPhoto>

        <Pressable
          onPress={() => navigation.navigate('CommunityChat')}
          className="mb-6 flex-row items-center gap-2.5 border-y border-line py-3.5 dark:border-line-dark active:opacity-70"
        >
          <View className="h-2 w-2 rounded-full bg-success" />
          <Text variant="body" className="flex-1" numberOfLines={1}>
            Study lounge
            <Text variant="body" tone="muted">
              {' '}· 3 chatting · group Pomodoro at 8 PM
            </Text>
          </Text>
          <Ionicons name="arrow-forward" size={15} color={colors.inkMuted} />
        </Pressable>

        <SegmentedControl<FeedSort>
          options={[
            { value: 'hot', label: 'Hot' },
            { value: 'new', label: 'New' },
            { value: 'top', label: 'Top' },
          ]}
          value={sort}
          onChange={setSort}
          className="mb-3"
        />

        <ScrollView horizontal showsHorizontalScrollIndicator={false} className="-mx-5 mb-4" contentContainerClassName="px-5 gap-2">
          <Chip label="All" selected={tag === null} onPress={() => setTag(null)} size="sm" />
          {mockTags.map((t) => (
            <Chip key={t.id} label={`#${t.label}`} selected={tag === t.label} onPress={() => setTag(tag === t.label ? null : t.label)} size="sm" />
          ))}
        </ScrollView>

        <View className="gap-3">
          {loading && !posts
            ? Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} height={220} rounded={20} />)
            : posts?.map((post) => (
                <PostCard
                  key={post.id}
                  post={post}
                  onPress={(p) => navigation.navigate('PostDetail', { postId: p.id })}
                  onVote={vote}
                  onTagPress={(t) => setTag(t)}
                />
              ))}
        </View>
      </Screen>

      <Pressable
        onPress={() => navigation.navigate('CreatePost')}
        accessibilityRole="button"
        accessibilityLabel="New post"
        className="absolute right-5 h-13 flex-row items-center gap-2 rounded-full bg-ink px-5 py-3.5 dark:bg-ink active:opacity-90"
        style={{ bottom: insets.bottom + 20 }}
      >
        <Ionicons name="create-outline" size={20} color="#FFFFFF" />
        <Text variant="label" weight="semibold" className="text-white dark:text-ink">
          Write
        </Text>
      </Pressable>
    </View>
  );
}
