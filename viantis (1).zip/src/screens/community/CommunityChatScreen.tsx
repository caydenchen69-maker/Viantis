import { Ionicons } from '@expo/vector-icons';
import React, { useRef, useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, Pressable, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Text } from '@/components/ui';
import { fonts } from '@/constants/typography';
import { useRealtimeChat } from '@/hooks';
import type { RootStackScreenProps } from '@/navigation/types';
import { useTheme } from '@/providers/ThemeProvider';
import { supabase } from '@/services';
import type { ChatRoomMessage } from '@/types';
import { cn } from '@/utils/cn';
import { formatTime } from '@/utils/date';

export function CommunityChatScreen({ route }: RootStackScreenProps<'CommunityChat'>) {
  const roomId = route.params?.roomId ?? 'general';
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { messages, send, currentUserId } = useRealtimeChat(roomId);
  const [draft, setDraft] = useState('');
  const listRef = useRef<FlatList<ChatRoomMessage>>(null);

  const submit = async () => {
    const text = draft.trim();
    if (!text) return;
    setDraft('');
    await send(text);
    setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 50);
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={insets.top + 44} className="flex-1 bg-canvas dark:bg-canvas-dark">
      <View className="flex-row items-center gap-2 border-b border-line px-5 py-2.5 dark:border-line-dark">
        <View className="h-2 w-2 rounded-full bg-success" />
        <Text variant="caption" tone="muted" className="flex-1">
          #{roomId} · {supabase ? 'Realtime via Supabase' : 'Local demo — messages are not persisted'}
        </Text>
      </View>

      <FlatList
        ref={listRef}
        data={messages}
        keyExtractor={(m) => m.id}
        contentContainerClassName="px-5 py-4"
        onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: false })}
        renderItem={({ item, index }) => {
          const mine = item.authorId === currentUserId;
          const prev = messages[index - 1];
          const showName = !mine && prev?.authorId !== item.authorId;
          return (
            <View className={cn('mb-1.5 max-w-[80%]', mine ? 'self-end' : 'self-start')}>
              {showName && (
                <Text variant="caption" tone="muted" className="mb-0.5 ml-1 font-medium">
                  {item.authorName}
                </Text>
              )}
              <View
                className={cn(
                  'rounded-2xl px-3.5 py-2',
                  mine ? 'rounded-br-md bg-primary-600 dark:bg-primary-500' : 'rounded-bl-md bg-surface border border-line dark:bg-surface-dark dark:border-line-dark',
                )}
              >
                <Text variant="body" className={mine ? 'text-white dark:text-ink' : undefined}>
                  {item.body}
                </Text>
              </View>
              <Text variant="caption" tone="subtle" className={cn('mt-0.5 text-[11px]', mine ? 'self-end mr-1' : 'ml-1')}>
                {formatTime(item.createdAt)}
              </Text>
            </View>
          );
        }}
      />

      <View className="flex-row items-end gap-2 px-4 pt-2" style={{ paddingBottom: insets.bottom + 8 }}>
        <View className="min-h-[44px] flex-1 justify-center rounded-[22px] border border-line bg-surface px-4 py-2 dark:border-line-dark dark:bg-surface-dark">
          <TextInput
            value={draft}
            onChangeText={setDraft}
            placeholder="Message the lounge…"
            placeholderTextColor={colors.inkSubtle}
            multiline
            className="text-[15px] leading-5 text-ink dark:text-ink-dark"
            style={{ maxHeight: 100, fontFamily: fonts.sans.regular }}
            onSubmitEditing={submit}
            blurOnSubmit={false}
          />
        </View>
        <Pressable
          onPress={submit}
          disabled={!draft.trim()}
          className="h-11 w-11 items-center justify-center rounded-full bg-primary-600 dark:bg-primary-500"
          style={{ opacity: draft.trim() ? 1 : 0.3 }}
          accessibilityLabel="Send message"
        >
          <Ionicons name="arrow-up" size={22} color={colors.canvas} />
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}
