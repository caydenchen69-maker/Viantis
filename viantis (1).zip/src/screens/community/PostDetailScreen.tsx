import { Ionicons } from '@expo/vector-icons';
import React, { useCallback, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, Pressable, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { CommentItem } from '@/components/community/CommentItem';
import { PostCard } from '@/components/community/PostCard';
import { Screen, SectionHeader, Skeleton, Text } from '@/components/ui';
import { fonts } from '@/constants/typography';
import { useAsync, useAuth } from '@/hooks';
import type { RootStackScreenProps } from '@/navigation/types';
import { useTheme } from '@/providers/ThemeProvider';
import { communityService } from '@/services';
import type { Comment, Post } from '@/types';

/** Moderator tooling is shown for the demo profile; wire to a `role` claim in production. */
const MODERATOR_IDS = new Set(['u_me']);

export function PostDetailScreen({ route }: RootStackScreenProps<'PostDetail'>) {
  const { postId } = route.params;
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { profile, session } = useAuth();
  const { data: post, setData: setPost } = useAsync(() => communityService.getPost(postId), [postId]);
  const { data: comments, refresh: refreshComments } = useAsync(() => communityService.listComments(postId), [postId]);
  const [draft, setDraft] = useState('');
  const [replyTo, setReplyTo] = useState<Comment | null>(null);
  const [sending, setSending] = useState(false);

  const canModerate = profile ? MODERATOR_IDS.has(profile.id) : false;

  const vote = useCallback(
    async (p: Post, direction: 1 | -1) => {
      setPost(await communityService.votePost(p, direction, session?.user.id));
    },
    [session?.user.id, setPost],
  );

  const submit = async () => {
    if (!draft.trim() || !profile) return;
    setSending(true);
    try {
      await communityService.addComment(
        postId,
        draft.trim(),
        { id: profile.id, username: profile.username, displayName: profile.displayName, avatar: profile.avatar },
        replyTo?.id,
      );
      setDraft('');
      setReplyTo(null);
      await refreshComments();
      setPost((p) => (p ? { ...p, commentCount: p.commentCount + 1 } : p));
    } finally {
      setSending(false);
    }
  };

  const moderate = (comment: Comment) => {
    if (canModerate) {
      Alert.alert('Remove comment?', 'The comment will be replaced with a removal notice.', [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => {
            await communityService.removeComment(comment.id);
            refreshComments();
          },
        },
      ]);
    } else {
      Alert.alert('Report comment', 'Thanks. A moderator will review this shortly.');
    }
  };

  const reportPost = () => {
    if (!post) return;
    Alert.alert('Report post', 'Why are you reporting this?', [
      { text: 'Spam', onPress: () => communityService.reportPost(post.id, 'spam', profile?.id).then(() => setPost({ ...post, isFlagged: true })) },
      { text: 'Harassment', onPress: () => communityService.reportPost(post.id, 'harassment', profile?.id).then(() => setPost({ ...post, isFlagged: true })) },
      { text: 'Cancel', style: 'cancel' },
    ]);
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={insets.top + 44} className="flex-1">
      <Screen safeTop={false} contentClassName="pt-3 pb-6">
        {post ? (
          <PostCard post={post} onPress={() => {}} onVote={vote} expanded />
        ) : (
          <Skeleton height={240} rounded={20} />
        )}

        <Pressable onPress={reportPost} className="mt-3 flex-row items-center justify-end gap-1.5 active:opacity-70">
          <Ionicons name="flag-outline" size={14} color={colors.inkSubtle} />
          <Text variant="caption" tone="subtle">
            Report post
          </Text>
        </Pressable>

        <SectionHeader title={`${post?.commentCount ?? 0} comments`} className="mt-6 mb-1" />
        <View>
          {comments === undefined ? (
            <Skeleton height={80} />
          ) : comments.length === 0 ? (
            <Text variant="body" tone="muted" className="py-3">
              Be the first to comment.
            </Text>
          ) : (
            comments.map((c, i) => (
              <View key={c.id} className={i > 0 ? 'border-t border-line dark:border-line-dark' : undefined}>
                <CommentItem comment={c} onReply={setReplyTo} onModerate={moderate} canModerate={canModerate} />
              </View>
            ))
          )}
        </View>
      </Screen>

      <View className="px-4 pt-2" style={{ paddingBottom: insets.bottom + 8 }}>
        {replyTo && (
          <View className="mb-2 flex-row items-center justify-between rounded-lg bg-surface-muted px-3 py-1.5 dark:bg-surface-muted-dark">
            <Text variant="caption" tone="muted">
              Replying to {replyTo.author.displayName}
            </Text>
            <Pressable onPress={() => setReplyTo(null)} hitSlop={8}>
              <Ionicons name="close" size={16} color={colors.inkMuted} />
            </Pressable>
          </View>
        )}
        <View className="flex-row items-end gap-2">
          <View className="min-h-[44px] flex-1 justify-center rounded-[22px] border border-line bg-surface px-4 py-2 dark:border-line-dark dark:bg-surface-dark">
            <TextInput
              value={draft}
              onChangeText={setDraft}
              placeholder="Add a comment…"
              placeholderTextColor={colors.inkSubtle}
              multiline
              className="text-[15px] leading-5 text-ink dark:text-ink-dark"
              style={{ maxHeight: 100, fontFamily: fonts.sans.regular }}
            />
          </View>
          <Pressable
            onPress={submit}
            disabled={!draft.trim() || sending}
            className="h-11 w-11 items-center justify-center rounded-full bg-primary-600 dark:bg-primary-500"
            style={{ opacity: draft.trim() && !sending ? 1 : 0.3 }}
            accessibilityLabel="Send comment"
          >
            <Ionicons name="arrow-up" size={22} color={colors.canvas} />
          </Pressable>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}
