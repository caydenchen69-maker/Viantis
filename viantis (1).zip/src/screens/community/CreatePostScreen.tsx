import React, { useState } from 'react';
import { View } from 'react-native';

import { Button, Chip, Input, Screen, Text } from '@/components/ui';
import { mockTags } from '@/data';
import { useAuth } from '@/hooks';
import type { RootStackScreenProps } from '@/navigation/types';
import { communityService } from '@/services';
import type { PostKind } from '@/types';

const kinds: { value: PostKind; label: string; icon: React.ComponentProps<typeof Chip>['icon'] }[] = [
  { value: 'discussion', label: 'Discussion', icon: 'chatbubbles-outline' },
  { value: 'question', label: 'Question', icon: 'help-circle-outline' },
  { value: 'tip', label: 'Study tip', icon: 'bulb-outline' },
  { value: 'review', label: 'School review', icon: 'school-outline' },
];

export function CreatePostScreen({ navigation }: RootStackScreenProps<'CreatePost'>) {
  const { profile } = useAuth();
  const [kind, setKind] = useState<PostKind>('discussion');
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);

  const toggleTag = (t: string) =>
    setTags((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : prev.length < 3 ? [...prev, t] : prev));

  const submit = async () => {
    if (!profile || !title.trim() || !body.trim()) return;
    setSaving(true);
    try {
      await communityService.createPost(
        { kind, title: title.trim(), body: body.trim(), tags },
        { id: profile.id, username: profile.username, displayName: profile.displayName, avatar: profile.avatar, level: profile.level },
      );
      navigation.goBack();
    } finally {
      setSaving(false);
    }
  };

  return (
    <Screen safeTop={false} contentClassName="pt-4">
      <Text variant="label" tone="muted" className="mb-2">
        Post type
      </Text>
      <View className="mb-5 flex-row flex-wrap gap-2">
        {kinds.map((k) => (
          <Chip key={k.value} label={k.label} icon={k.icon} selected={kind === k.value} onPress={() => setKind(k.value)} />
        ))}
      </View>

      <Input label="Title" placeholder="Give it a clear, specific title" value={title} onChangeText={setTitle} maxLength={120} containerClassName="mb-4" />
      <Input
        label="Body"
        placeholder="Share the details. Markdown-lite: **bold** and bullet lists work."
        value={body}
        onChangeText={setBody}
        multiline
        containerClassName="mb-5"
        className="min-h-[140px] py-2"
        style={{ textAlignVertical: 'top' }}
      />

      <Text variant="label" tone="muted" className="mb-2">
        Tags <Text variant="caption" tone="subtle">(up to 3)</Text>
      </Text>
      <View className="mb-8 flex-row flex-wrap gap-2">
        {mockTags.map((t) => (
          <Chip key={t.id} label={`#${t.label}`} selected={tags.includes(t.label)} onPress={() => toggleTag(t.label)} size="sm" />
        ))}
      </View>

      <Button label="Publish" variant="ink" size="lg" fullWidth onPress={submit} loading={saving} disabled={!title.trim() || !body.trim()} />
      <Text variant="caption" tone="subtle" className="mt-3 text-center">
        Posts are reviewed by community moderators. Be kind and stay on topic.
      </Text>
    </Screen>
  );
}
