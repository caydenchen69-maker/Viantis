import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useState } from 'react';
import { Pressable, View } from 'react-native';

import { GameCard } from '@/components/arcade/GameCard';
import { LeaderboardRow } from '@/components/arcade/LeaderboardRow';
import { SharedDeckCard } from '@/components/arcade/SharedDeckCard';
import { BrandHeader, ChatFab } from '@/components/brand';
import { ArcadeCabinetMark, ConsoleMark } from '@/components/icons';
import { CampusPhoto, Screen, SectionHeader, Text } from '@/components/ui';
import { campusCaptions } from '@/constants/campus';
import { leaderboardWithGuest, mockFriendsLeaderboard, mockGames } from '@/data';
import { useAuth } from '@/hooks';
import { useDecks } from '@/hooks/useDecks';
import type { TabScreenProps } from '@/navigation/types';
import { useTheme } from '@/providers/ThemeProvider';
import type { Deck } from '@/types';
import { cn } from '@/utils/cn';
import { timeAgo } from '@/utils/date';
import { formatCompact } from '@/utils/format';

export function ArcadeScreen({ navigation }: TabScreenProps<'ArcadeTab'>) {
  const { profile } = useAuth();
  const { colors } = useTheme();
  const { decks, customDecks, sharedDecks, ownedBySource, refresh, createDeck, addSharedToLibrary, subjectsById } =
    useDecks();
  const friends = leaderboardWithGuest(mockFriendsLeaderboard, profile).slice(0, 4);

  useFocusEffect(
    useCallback(() => {
      void refresh();
    }, [refresh]),
  );

  const [addingId, setAddingId] = useState<string | null>(null);

  const onCreate = async () => {
    const deck = await createDeck({ title: 'Untitled deck', subjectId: 's_eng' });
    navigation.navigate('DeckEditor', { deckId: deck.id });
  };

  const onAddShared = async (deck: Deck) => {
    setAddingId(deck.id);
    try {
      const created = await addSharedToLibrary(deck.id);
      if (created) navigation.navigate('DeckEditor', { deckId: created.id });
    } finally {
      setAddingId(null);
    }
  };

  const openDeck = (deck: Deck) => {
    if (deck.custom) navigation.navigate('DeckEditor', { deckId: deck.id });
    else navigation.navigate('Game', { gameId: 'flashcard_match', deckId: deck.id });
  };

  return (
    <View className="flex-1 bg-canvas dark:bg-canvas-dark">
      <BrandHeader />
      <Screen safeTop={false} contentClassName="pb-28">
      <CampusPhoto photo="stanford" height={188} dim={0.32} grayscale className="mb-7" rounded={false}>
        <View className="flex-1 justify-between p-4">
          <View className="flex-row items-center justify-between">
            <Text variant="caption" tone="inverseMuted">
              {campusCaptions.stanford}
            </Text>
            {profile && (
              <Pressable onPress={() => navigation.navigate('Leaderboard')} className="items-end active:opacity-70">
                <Text variant="heading" tone="inverse" style={{ fontSize: 20, lineHeight: 24 }}>
                  {formatCompact(profile.xp)} XP
                </Text>
                <Text variant="caption" tone="inverseMuted">
                  Level {profile.level}
                </Text>
              </Pressable>
            )}
          </View>
          <View>
            <View className="mb-2 flex-row items-center gap-2.5">
              <ArcadeCabinetMark color="#F6F1E8" size={22} focused accent="#E55C5C" />
              <ConsoleMark color="#F6F1E8" size={22} />
            </View>
            <Text variant="display" tone="inverse">
              Arcade
            </Text>
            <Text variant="caption" tone="inverseMuted" className="mt-1.5">
              Cabinets, decks, and a weekly climb.
            </Text>
          </View>
        </View>
      </CampusPhoto>

      <View className="mb-9 gap-3">
        {mockGames.map((game) => (
          <GameCard key={game.id} game={game} onPress={(g) => navigation.navigate('Game', { gameId: g.id })} />
        ))}
      </View>

      <SectionHeader
        title="Your decks"
        subtitle={customDecks.length ? `${customDecks.length} of yours` : 'Make cards for a class or a chapter'}
        actionLabel="Manage"
        onAction={() => navigation.navigate('DeckLibrary')}
        className="mb-1"
      />
      <Pressable
        onPress={() => void onCreate()}
        className="mb-1 flex-row items-center gap-3 rounded-2xl border border-dashed border-primary-300 bg-primary-50 px-4 py-3.5 dark:border-primary-700 dark:bg-primary-500/10 active:opacity-80"
      >
        <View className="h-8 w-8 items-center justify-center rounded-full bg-primary-600 dark:bg-primary-500">
          <Ionicons name="add" size={18} color="#FFFFFF" />
        </View>
        <View className="flex-1">
          <Text variant="body" weight="medium">
            New deck
          </Text>
          <Text variant="caption" tone="muted">
            Write your own terms and definitions
          </Text>
        </View>
      </Pressable>
      <View className="mb-9">
        {decks.map((deck, i) => {
          const subject = subjectsById.get(deck.subjectId);
          return (
            <Pressable
              key={deck.id}
              className={cn(
                'flex-row items-center gap-3.5 py-3.5 active:opacity-80',
                i < decks.length - 1 && 'border-b border-line dark:border-line-dark',
              )}
              onPress={() => openDeck(deck)}
            >
              <View className="h-2 w-2 rounded-full" style={{ backgroundColor: subject?.color ?? colors.inkSubtle }} />
              <View className="flex-1">
                <Text variant="body" weight="medium" numberOfLines={1}>
                  {deck.title}
                </Text>
                <Text variant="caption" tone="muted">
                  {deck.cardCount} cards
                  {deck.custom ? ' · yours' : ''}
                  {deck.lastStudied ? ` · ${timeAgo(deck.lastStudied)}` : ' · not studied yet'}
                </Text>
              </View>
              <Ionicons name={deck.custom ? 'create-outline' : 'arrow-forward'} size={16} color={colors.inkSubtle} />
            </Pressable>
          );
        })}
      </View>

      <SectionHeader
        title="Community sets"
        subtitle="Hiragana and katakana ship in the app. Add a friend’s set with a share code."
        actionLabel="See all"
        onAction={() => navigation.navigate('DeckLibrary')}
        className="mb-3"
      />
      <View className="mb-9 gap-3">
        {sharedDecks.slice(0, 3).map((deck) => {
          const mineId = ownedBySource.get(deck.id);
          return (
            <SharedDeckCard
              key={deck.id}
              deck={deck}
              subjectName={subjectsById.get(deck.subjectId)?.name}
              subjectColor={subjectsById.get(deck.subjectId)?.color ?? colors.inkSubtle}
              alreadyAdded={Boolean(mineId)}
              busy={addingId === deck.id}
              onPlay={() => navigation.navigate('Game', { gameId: 'flashcard_match', deckId: deck.id })}
              onAdd={() => void onAddShared(deck)}
              onOpenMine={mineId ? () => navigation.navigate('DeckEditor', { deckId: mineId }) : undefined}
            />
          );
        })}
      </View>

      <SectionHeader title="Friends" actionLabel="Global leaderboard" onAction={() => navigation.navigate('Leaderboard')} className="mb-1" />
      <View>
        {friends.map((entry, i) => (
          <LeaderboardRow key={entry.user.id} entry={entry} last={i === friends.length - 1} />
        ))}
      </View>

      <Text variant="caption" tone="muted" className="mt-8">
        A 7-day streak unlocks the gold avatar frame and a 2× XP weekend.
      </Text>
      </Screen>
      <ChatFab prompt="Help me build a study deck for this week." />
    </View>
  );
}
