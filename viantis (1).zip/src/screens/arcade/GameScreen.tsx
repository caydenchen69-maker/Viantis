import { Ionicons } from '@expo/vector-icons';
import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { MatchGrid } from '@/components/arcade/MatchGrid';
import { QuizRound, type RoundResult } from '@/components/arcade/QuizRound';
import { Button, Text } from '@/components/ui';
import { palette } from '@/constants/theme';
import { mockGames } from '@/data';
import { useAuth } from '@/hooks';
import type { RootStackScreenProps } from '@/navigation/types';
import { arcadeService } from '@/services';
import type { Flashcard, QuizQuestion } from '@/types';

type Stage = 'intro' | 'loading' | 'playing' | 'results';

export function GameScreen({ route, navigation }: RootStackScreenProps<'Game'>) {
  const { gameId, deckId } = route.params;
  const insets = useSafeAreaInsets();
  const { addXP, session } = useAuth();
  const game = mockGames.find((g) => g.id === gameId)!;

  // Deck-launched rounds skip the intro; the loading state kicks off below.
  const [stage, setStage] = useState<Stage>(deckId ? 'loading' : 'intro');
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [cards, setCards] = useState<Flashcard[]>([]);
  const [result, setResult] = useState<RoundResult | null>(null);
  const [xpEarned, setXpEarned] = useState(0);

  const load = useCallback(async () => {
    setStage('loading');
    if (gameId === 'flashcard_match') {
      const all = deckId
        ? await arcadeService.listFlashcards(deckId)
        : (await Promise.all((await arcadeService.listDecks()).map((d) => arcadeService.listFlashcards(d.id)))).flat();
      setCards(all);
    } else {
      setQuestions(await arcadeService.buildRound({ deckId, count: gameId === 'trivia_tower' ? 10 : 8 }));
    }
    setStage('playing');
  }, [gameId, deckId]);

  const onFinish = useCallback(
    (r: RoundResult) => {
      const xp = arcadeService.scoreRound(gameId, r.correct, r.total);
      setResult(r);
      setXpEarned(xp);
      addXP(xp);
      arcadeService.recordXP(session?.user.id, xp, `${game.title} round`).catch(() => {});
      if (deckId) arcadeService.markStudied(deckId).catch(() => {});
      setStage('results');
    },
    [gameId, deckId, addXP, session?.user.id, game.title],
  );

  useEffect(() => {
    if (!deckId) return;
    const timer = setTimeout(() => void load(), 0);
    return () => clearTimeout(timer);
  }, [deckId, load]);

  return (
    <View style={{ flex: 1, backgroundColor: palette.deep }}>
      <View className="flex-1 px-5" style={{ paddingTop: insets.top + 8, paddingBottom: insets.bottom + 16 }}>
        <View className="mb-4 flex-row items-center justify-between">
          <Pressable onPress={() => navigation.goBack()} hitSlop={10} className="h-10 w-10 items-center justify-center rounded-full bg-white/10">
            <Ionicons name="close" size={22} color="#FFFFFF" />
          </Pressable>
          <Text variant="label" tone="inverse" className="font-semibold">
            {game.title}
          </Text>
          <View className="w-10" />
        </View>

        {stage === 'intro' && (
          <View className="flex-1 justify-center">
            <Ionicons name={game.icon as never} size={32} color="rgba(255,255,255,0.7)" style={{ alignSelf: 'center', marginBottom: 20 }} />
            <Text variant="display" tone="inverse" className="text-center" style={{ fontSize: 48, lineHeight: 52 }}>
              {game.title}
            </Text>
            <Text variant="body" className="mt-4 text-center text-white/70">
              {game.description}
            </Text>
            <View className="mt-8 flex-row justify-center gap-3">
              <Stat label="Best" value={String(game.bestScore)} />
              <Stat label="Reward" value={`+${game.xpPerRound} XP`} />
              <Stat label="Time" value={game.durationLabel} />
            </View>
            <Button label="Start round" variant="inverse" size="lg" icon="play" onPress={load} className="mt-10" />
          </View>
        )}

        {stage === 'loading' && (
          <View className="flex-1 items-center justify-center">
            <ActivityIndicator color="#FFFFFF" size="large" />
            <Text variant="caption" className="mt-3 text-white/80">
              Building questions from your decks…
            </Text>
          </View>
        )}

        {stage === 'playing' && (gameId === 'flashcard_match' ? cards.length < 2 : questions.length === 0) && (
          <View className="flex-1 items-center justify-center px-6">
            <Text variant="heading" tone="inverse" className="text-center">
              Not enough cards
            </Text>
            <Text variant="body" className="mt-2 text-center text-white/70">
              Add at least two cards to this deck, then play again.
            </Text>
            <Button
              label="Edit deck"
              variant="inverse"
              className="mt-8"
              onPress={() => (deckId ? navigation.replace('DeckEditor', { deckId }) : navigation.goBack())}
            />
          </View>
        )}

        {stage === 'playing' && (gameId === 'flashcard_match' ? cards.length >= 2 : questions.length > 0) && (
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ flexGrow: 1 }}>
            {gameId === 'flashcard_match' ? (
              <MatchGrid cards={cards} onFinish={onFinish} />
            ) : (
              <QuizRound gameId={gameId} questions={questions} onFinish={onFinish} />
            )}
          </ScrollView>
        )}

        {stage === 'results' && result && (
          <View className="flex-1 justify-center">
            <Text variant="overline" className="text-center text-white/70">
              Round complete
            </Text>
            <Text variant="display" tone="inverse" className="mt-2 text-center" style={{ fontSize: 80, lineHeight: 84 }}>
              {result.score}
            </Text>
            <Text variant="body" className="text-center text-white/60">
              points
            </Text>

            <View className="mt-8 flex-row justify-center gap-3">
              <Stat label="Correct" value={`${result.correct}/${result.total}`} />
              {gameId !== 'flashcard_match' && <Stat label="Best streak" value={`×${result.bestStreak}`} />}
              <Stat label="XP earned" value={`+${xpEarned}`} highlight />
            </View>

            {result.score > game.bestScore && (
              <View className="mt-6 flex-row items-center justify-center gap-2 self-center">
                <Ionicons name="trophy-outline" size={15} color="#FDE68A" />
                <Text variant="heading" italic tone="inverse" style={{ fontSize: 18 }}>
                  New personal best
                </Text>
              </View>
            )}

            <View className="mt-10 gap-3">
              <Button label="Play again" variant="inverse" size="lg" icon="refresh" onPress={load} />
              <Pressable onPress={() => navigation.goBack()} className="h-11 items-center justify-center active:opacity-70">
                <Text variant="label" tone="inverseMuted">
                  Back to arcade
                </Text>
              </Pressable>
            </View>
          </View>
        )}
      </View>
    </View>
  );
}

function Stat({ label, value, highlight = false }: { label: string; value: string; highlight?: boolean }) {
  return (
    <View className="min-w-[96px] items-center border-t border-white/20 px-3 pt-3">
      <Text variant="heading" style={{ fontSize: 24, lineHeight: 28, color: highlight ? '#FDE68A' : '#FFFFFF' }}>
        {value}
      </Text>
      <Text variant="caption" className="mt-0.5 text-white/60">
        {label}
      </Text>
    </View>
  );
}
