import { Ionicons } from '@expo/vector-icons';
import React, { useEffect, useState } from 'react';
import { Pressable, View } from 'react-native';

import { Button, Chip, EmptyState, Input, Screen, SectionHeader, Skeleton, Text } from '@/components/ui';
import { mockSubjects } from '@/data';
import { useAuth } from '@/hooks';
import { useDeckCards, useDecks } from '@/hooks/useDecks';
import type { RootStackScreenProps } from '@/navigation/types';
import { useTheme } from '@/providers/ThemeProvider';
import type { Flashcard } from '@/types';
import { cn } from '@/utils/cn';
import { confirmChoice, copyOrShareText } from '@/utils/shareText';

export function DeckEditorScreen({ navigation, route }: RootStackScreenProps<'DeckEditor'>) {
  const { deckId } = route.params;
  const { colors } = useTheme();
  const { profile } = useAuth();
  const {
    decks,
    loading: decksLoading,
    updateDeck,
    deleteDeck,
    refresh,
    publishDeck,
    unpublishDeck,
    exportShareCode,
  } = useDecks();
  const { cards, loading: cardsLoading, refresh: refreshCards, addCard, updateCard, deleteCard } = useDeckCards(deckId);
  const deck = decks.find((d) => d.id === deckId);

  const [title, setTitle] = useState('');
  const [subjectId, setSubjectId] = useState(mockSubjects[0]!.id);
  const [front, setFront] = useState('');
  const [back, setBack] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [cardError, setCardError] = useState<string | null>(null);
  const [shareCode, setShareCode] = useState('');
  const [shareNote, setShareNote] = useState<string | null>(null);
  const [sharing, setSharing] = useState(false);

  useEffect(() => {
    if (!deck) return;
    setTitle(deck.title);
    setSubjectId(deck.subjectId);
  }, [deck?.id, deck?.title, deck?.subjectId]);

  useEffect(() => {
    if (!deck?.shared) {
      setShareCode('');
      return;
    }
    void exportShareCode(deck.id).then((code) => {
      if (code) setShareCode(code);
    });
  }, [deck?.id, deck?.shared, cards.length, exportShareCode]);

  if ((decksLoading || cardsLoading) && !deck) {
    return (
      <Screen safeTop={false} contentClassName="pt-4 gap-3">
        <Skeleton height={48} rounded={16} />
        <Skeleton height={120} rounded={16} />
      </Screen>
    );
  }

  if (!deck) {
    return (
      <Screen safeTop={false}>
        <EmptyState icon="albums-outline" title="Deck not found" actionLabel="Back" onAction={() => navigation.goBack()} />
      </Screen>
    );
  }

  if (!deck.custom) {
    return (
      <Screen safeTop={false}>
        <EmptyState
          icon="lock-closed-outline"
          title="Starter deck"
          description="This one ships with Viantis. Create your own deck to add cards."
          actionLabel="Play it"
          onAction={() => navigation.navigate('Game', { gameId: 'flashcard_match', deckId: deck.id })}
        />
      </Screen>
    );
  }

  const persistMeta = async () => {
    setSaving(true);
    try {
      await updateDeck(deck.id, { title, subjectId });
    } finally {
      setSaving(false);
    }
  };

  const saveCard = async () => {
    const nextFront = front.trim();
    const nextBack = back.trim();
    if (!nextFront || !nextBack) {
      setCardError('Type something on both sides, then add the card.');
      return;
    }
    setCardError(null);
    setSaving(true);
    try {
      if (editingId) {
        const updated = await updateCard({ id: editingId, deckId: deck.id, front: nextFront, back: nextBack });
        if (!updated) {
          setCardError('Could not update that card. Try again.');
          return;
        }
      } else {
        const created = await addCard({ front: nextFront, back: nextBack, title, subjectId });
        if (!created) {
          setCardError('Could not save that card. Try again.');
          return;
        }
      }
      setFront('');
      setBack('');
      setEditingId(null);
      await refreshCards();
      void refresh();
    } finally {
      setSaving(false);
    }
  };

  const startEdit = (card: Flashcard) => {
    setEditingId(card.id);
    setFront(card.front);
    setBack(card.back);
  };

  const confirmDeleteDeck = async () => {
    const ok = await confirmChoice(
      'Delete this deck?',
      'Cards in it will be removed from this device.',
      'Delete',
    );
    if (!ok) return;
    await deleteDeck(deck.id);
    navigation.goBack();
  };

  const onShareEveryone = async () => {
    if (cards.length < 2) {
      setShareNote('Add at least two cards before sharing.');
      return;
    }
    setSharing(true);
    setShareNote(null);
    try {
      await persistMeta();
      const published = await publishDeck(deck.id, profile?.displayName || undefined);
      if (!published) {
        setShareNote('Could not share this set. Try again.');
        return;
      }
      const code = await exportShareCode(deck.id);
      if (code) {
        setShareCode(code);
        const result = await copyOrShareText(code);
            setShareNote(
          result === 'copied'
            ? 'Share code copied. Send it to a friend — they do not need a link.'
            : 'This set is marked shared. Copy the code to send it.',
        );
      } else {
        setShareNote('This set is marked shared. Copy the code to send it.');
      }
    } finally {
      setSharing(false);
    }
  };

  const onStopSharing = async () => {
    const ok = await confirmChoice(
      'Stop sharing this set?',
      'The share code will stop working for new imports. Your copy stays on this device.',
      'Stop sharing',
    );
    if (!ok) return;
    setSharing(true);
    try {
      await unpublishDeck(deck.id);
      setShareCode('');
      setShareNote('This set is private again.');
    } finally {
      setSharing(false);
    }
  };

  const onCopyShareCode = async () => {
    const code = shareCode || (await exportShareCode(deck.id));
    if (!code) {
      setShareNote('Add at least two cards to make a share code.');
      return;
    }
    setShareCode(code);
    const result = await copyOrShareText(code);
    setShareNote(result === 'copied' ? 'Share code copied.' : result === 'shared' ? 'Share sheet opened.' : 'Could not copy the code.');
  };

  return (
    <Screen safeTop={false} contentClassName="pt-2 pb-10">
      <Input
        label="Deck name"
        value={title}
        onChangeText={setTitle}
        onBlur={() => void persistMeta()}
        placeholder="e.g. Spanish · Unit 4"
        autoCapitalize="sentences"
        selectTextOnFocus
      />

      <Text variant="label" tone="muted" className="mb-2 mt-5">
        Subject
      </Text>
      <View className="mb-6 flex-row flex-wrap gap-2">
        {mockSubjects.map((s) => (
          <Chip
            key={s.id}
            label={s.name}
            color={s.color}
            selected={subjectId === s.id}
            onPress={() => {
              setSubjectId(s.id);
              void updateDeck(deck.id, { title, subjectId: s.id });
            }}
          />
        ))}
      </View>

      <SectionHeader
        title={editingId ? 'Edit card' : 'Add a card'}
        subtitle={editingId ? 'Change the term or definition, then save' : 'Term on the front, definition on the back'}
      />
      <Input
        label="Front"
        placeholder="Term, prompt, or question"
        value={front}
        onChangeText={(value) => {
          setFront(value);
          if (cardError) setCardError(null);
        }}
        autoCapitalize="sentences"
      />
      <Input
        label="Back"
        placeholder="Definition or answer"
        value={back}
        onChangeText={(value) => {
          setBack(value);
          if (cardError) setCardError(null);
        }}
        multiline
        containerClassName="mt-3"
      />
      {cardError && (
        <Text variant="caption" tone="danger" className="mt-2">
          {cardError}
        </Text>
      )}
      <View className="mt-3 flex-row gap-2">
        <Button
          label={editingId ? 'Save card' : 'Add card'}
          variant="ink"
          icon={editingId ? 'checkmark' : 'add'}
          onPress={() => void saveCard()}
          loading={saving}
          className="flex-1"
        />
        {editingId && (
          <Button
            label="Cancel"
            variant="outline"
            onPress={() => {
              setEditingId(null);
              setFront('');
              setBack('');
            }}
          />
        )}
      </View>

      <SectionHeader title={`${cards.length} ${cards.length === 1 ? 'card' : 'cards'}`} className="mt-8" />
      {cards.length === 0 ? (
        <EmptyState
          icon="layers-outline"
          title="Empty deck"
          description="Add a few cards and you can play them in the arcade."
          className="py-4"
        />
      ) : (
        <View className="mb-6">
          {cards.map((card, i) => (
            <Pressable
              key={card.id}
              onPress={() => startEdit(card)}
              className={cn(
                'flex-row items-start gap-3 py-3.5 active:opacity-80',
                i < cards.length - 1 && 'border-b border-line dark:border-line-dark',
              )}
            >
              <View className="flex-1">
                <Text variant="body" weight="medium">
                  {card.front}
                </Text>
                <Text variant="caption" tone="muted" className="mt-0.5">
                  {card.back}
                </Text>
              </View>
              <Pressable
                onPress={() => void deleteCard(card.id).then(() => refresh())}
                hitSlop={8}
                accessibilityLabel={`Delete ${card.front}`}
                className="h-8 w-8 items-center justify-center"
              >
                <Ionicons name="trash-outline" size={16} color={colors.inkSubtle} />
              </Pressable>
            </Pressable>
          ))}
        </View>
      )}

      <SectionHeader
        title="Share with everyone"
        subtitle="Copy a share code. Friends paste it on their phone — no live link or account."
        className="mt-2"
      />
      <View className="mb-8 rounded-[8px] border border-line bg-surface p-4 dark:border-line-dark dark:bg-surface-dark">
        {deck.shared ? (
          <>
            <Text variant="body" weight="medium">
              Shared with everyone
            </Text>
            <Text variant="caption" tone="muted" className="mt-1">
              Send the VNT1. code. They paste it under Arcade → Manage decks. Nothing stays online.
            </Text>
            {!!shareCode && (
              <Input
                label="Share code"
                value={shareCode}
                editable={false}
                selectTextOnFocus
                containerClassName="mt-3"
              />
            )}
            <View className="mt-3 flex-row gap-2">
              <Button
                label="Copy code"
                variant="outline"
                icon="copy-outline"
                onPress={() => void onCopyShareCode()}
                className="flex-1"
              />
              <Button
                label="Stop sharing"
                variant="ghost"
                loading={sharing}
                onPress={() => void onStopSharing()}
                className="flex-1"
              />
            </View>
          </>
        ) : (
          <>
            <Text variant="body" weight="medium">
              Keep this set private, or share it
            </Text>
            <Text variant="caption" tone="muted" className="mt-1">
              Sharing makes a code you can send. Nothing is uploaded. You can stop anytime.
            </Text>
            <Button
              label="Share with everyone"
              variant="ink"
              icon="people-outline"
              loading={sharing}
              disabled={cards.length < 2}
              onPress={() => void onShareEveryone()}
              className="mt-3"
              fullWidth
            />
            {cards.length < 2 && (
              <Text variant="caption" tone="muted" className="mt-2">
                Add at least two cards first.
              </Text>
            )}
          </>
        )}
        {shareNote && (
          <Text variant="caption" className="mt-2" tone={shareNote.startsWith('Could') ? 'danger' : 'muted'}>
            {shareNote}
          </Text>
        )}
      </View>

      <View className="gap-3">
        <Button
          label="Play this deck"
          variant="ink"
          icon="play"
          size="lg"
          fullWidth
          disabled={cards.length < 2}
          onPress={() => {
            void persistMeta();
            navigation.navigate('Game', { gameId: 'flashcard_match', deckId: deck.id });
          }}
        />
        {cards.length > 0 && cards.length < 2 && (
          <Text variant="caption" tone="muted" className="text-center">
            Add at least two cards to play a match round.
          </Text>
        )}
        <Button label={saving ? 'Saving…' : 'Delete deck'} variant="ghost" fullWidth onPress={confirmDeleteDeck} />
      </View>
    </Screen>
  );
}
