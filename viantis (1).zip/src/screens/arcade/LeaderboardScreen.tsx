import React, { useMemo, useState } from 'react';
import { View } from 'react-native';

import { LeaderboardRow } from '@/components/arcade/LeaderboardRow';
import { Screen, SegmentedControl, Skeleton, Text } from '@/components/ui';
import { leaderboardWithGuest } from '@/data';
import { useAsync, useAuth } from '@/hooks';
import { arcadeService, type LeaderboardScope } from '@/services';
import { formatCompact } from '@/utils/format';

export function LeaderboardScreen() {
  const [scope, setScope] = useState<LeaderboardScope>('global');
  const { profile } = useAuth();
  const { data: raw, loading } = useAsync(() => arcadeService.leaderboard(scope), [scope]);
  const data = useMemo(() => (raw ? leaderboardWithGuest(raw, profile) : undefined), [raw, profile]);

  const me = data?.find((e) => e.isCurrentUser || e.user.id === profile?.id);

  return (
    <Screen safeTop={false} contentClassName="pt-3">
      <SegmentedControl<LeaderboardScope>
        options={[
          { value: 'global', label: 'Global' },
          { value: 'friends', label: 'Friends' },
        ]}
        value={scope}
        onChange={setScope}
        className="mb-4"
      />

      {me && (
        <View className="mb-6 flex-row items-end justify-between border-b border-line pb-5 dark:border-line-dark">
          <View>
            <Text variant="caption" tone="muted">
              Your rank
            </Text>
            <Text variant="display" style={{ fontSize: 56, lineHeight: 60 }}>
              #{me.rank}
            </Text>
          </View>
          <View className="items-end pb-1">
            <Text variant="caption" tone="muted">
              {formatCompact(me.xp)} XP · Level {me.user.level}
            </Text>
            {data && me.rank > 1 && (
              <Text variant="caption" tone="muted">
                {formatCompact(data[me.rank - 2]!.xp - me.xp)} XP to #{me.rank - 1}
              </Text>
            )}
          </View>
        </View>
      )}

      <View>
        {loading && !data
          ? Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} height={56} rounded={8} className="mb-2" />)
          : data?.map((entry, i) => <LeaderboardRow key={entry.user.id} entry={entry} last={i === data.length - 1} />)}
      </View>

      <Text variant="caption" tone="subtle" className="mt-6 text-center">
        Resets every Monday · XP from games, focus sessions and completed tasks
      </Text>
    </Screen>
  );
}
