import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import React, { useCallback, useState } from 'react';
import { Pressable, View } from 'react-native';

import { SharedDeckCard } from '@/components/arcade/SharedDeckCard';
import { Button, EmptyState, Input, Screen, SectionHeader, Skeleton, Text } from '@/components/ui';
import { useDecks } from '@/hooks/useDecks';
import type { RootStackScreenProps } from '@/navigation/types';
import { useTheme } from '@/providers/ThemeProvider';
import type { Deck } from '@/types';
import { cn } from '@/utils/cn';
import { timeAgo } from '@/utils/date';

export function DeckLibraryScreen({ navigation }: RootStackScreenProps<'DeckLibrary'>) {
  const { colors } = useTheme();
  const {
    customDecks,
    sampleDecks,
    sharedDecks,
    ownedBySource,
    loading,
    refresh,
    createDeck,
    addSharedToLibrary,
    importShareCode,
    subjectsById,
  } = useDecks();
  const [code, setCode] = useState('');
  const [codeNote, setCodeNote] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);
  const [addingId, setAddingId] = useState<string | null>(null);

  useFocusEffect(
    useCallback(() => {
      void refresh();
    }, [refresh]),
  );

  const onCreate = async () => {
    const deck = await createDeck({ title: 'Untitled deck', subjectId: 's_eng' });
    navigation.navigate('DeckEditor', { deckId: deck.id });
  };

  const onImport = async () => {
    const trimmed = code.trim();
    if (!trimmed) {
      setCodeNote('Paste a VNT1. share code.');
      return;
    }
    setImporting(true);
    setCodeNote(null);
    try {
      const created = await importShareCode(trimmed);
      if (!created) {
        setCodeNote('That code did not work. Check it and try again.');
        return;
      }
      setCode('');
      setCodeNote(`Added “${created.title}” to your decks.`);
      navigation.navigate('DeckEditor', { deckId: created.id });
    } finally {
      setImporting(false);
    }
  };

  const onAddShared = async (deck: Deck) => {
    setAddingId(deck.id);
    try {
      const created = await addSharedToLibrary(deck.id);
      if (created) navigation.navigate('DeckEditor', { deckId: created.id });
    } finally {
      setAddingId(null);
    }
  };

  return (
    <Screen safeTop={false} contentClassName="pt-2">
      <Text variant="body" tone="muted" className="mb-5">
        Build your own cards, grab a set someone already shared, or play the starters.
      </Text>

      <Button label="New deck" variant="ink" icon="add" fullWidth size="lg" onPress={onCreate} className="mb-8" />

      <SectionHeader
        title="Community library"
        subtitle="Built-in sets like Hiragana, plus anything you import from a share code"
      />
      {loading && !sharedDecks.length ? (
        <View className="mb-8 gap-3">
          <Skeleton height={88} rounded={8} />
          <Skeleton height={88} rounded={8} />
        </View>
      ) : (
        <View className="mb-8 gap-3">
          {sharedDecks.map((deck) => {
            const mineId = ownedBySource.get(deck.id);
            return (
              <SharedDeckCard
                key={deck.id}
                deck={deck}
                subjectName={subjectsById.get(deck.subjectId)?.name}
                subjectColor={subjectsById.get(deck.subjectId)?.color ?? colors.inkSubtle}
                alreadyAdded={Boolean(mineId)}
                busy={addingId === deck.id}
                onPlay={() => navigation.navigate('Game', { gameId: 'flashcard_match', deckId: deck.id })}
                onAdd={() => void onAddShared(deck)}
                onOpenMine={mineId ? () => navigation.navigate('DeckEditor', { deckId: mineId }) : undefined}
              />
            );
          })}
        </View>
      )}

      <SectionHeader title="Have a share code?" subtitle="Paste a VNT1. code. No website or account." />
      <Input
        label="Share code"
        value={code}
        onChangeText={(value) => {
          setCode(value);
          if (codeNote) setCodeNote(null);
        }}
        placeholder="VNT1."
        autoCapitalize="none"
        autoCorrect={false}
      />
      <Button
        label="Add from code"
        variant="outline"
        icon="download-outline"
        loading={importing}
        onPress={() => void onImport()}
        className="mt-3"
        fullWidth
      />
      {codeNote ? (
        <Text variant="caption" tone={codeNote.startsWith('That') || codeNote.startsWith('Paste') ? 'danger' : 'muted'} className="mt-2 mb-8">
          {codeNote}
        </Text>
      ) : (
        <View className="mb-8" />
      )}

      <SectionHeader title="Your decks" subtitle={customDecks.length ? `${customDecks.length} saved on this device` : undefined} />
      {loading && !customDecks.length && !sampleDecks.length ? (
        <View className="gap-3">
          <Skeleton height={64} rounded={16} />
          <Skeleton height={64} rounded={16} />
        </View>
      ) : customDecks.length === 0 ? (
        <EmptyState
          icon="albums-outline"
          title="Nothing of yours yet"
          description="Start a deck, or add Hiragana from the community library above."
          className="py-4"
        />
      ) : (
        <View className="mb-8">
          {customDecks.map((deck, i) => (
            <DeckRow
              key={deck.id}
              deck={deck}
              subjectColor={subjectsById.get(deck.subjectId)?.color ?? colors.inkSubtle}
              subjectName={subjectsById.get(deck.subjectId)?.name}
              last={i === customDecks.length - 1}
              onPress={() => navigation.navigate('DeckEditor', { deckId: deck.id })}
            />
          ))}
        </View>
      )}

      <SectionHeader title="Starter decks" subtitle="Included examples — play them or copy the idea" />
      <View>
        {sampleDecks.map((deck, i) => (
          <DeckRow
            key={deck.id}
            deck={deck}
            subjectColor={subjectsById.get(deck.subjectId)?.color ?? colors.inkSubtle}
            subjectName={subjectsById.get(deck.subjectId)?.name}
            last={i === sampleDecks.length - 1}
            onPress={() => navigation.navigate('Game', { gameId: 'flashcard_match', deckId: deck.id })}
          />
        ))}
      </View>
    </Screen>
  );
}

function DeckRow({
  deck,
  subjectColor,
  subjectName,
  last,
  onPress,
}: {
  deck: Deck;
  subjectColor: string;
  subjectName?: string;
  last: boolean;
  onPress: () => void;
}) {
  const { colors } = useTheme();
  return (
    <Pressable
      onPress={onPress}
      className={cn('flex-row items-center gap-3.5 py-3.5 active:opacity-80', !last && 'border-b border-line dark:border-line-dark')}
    >
      <View className="h-2 w-2 rounded-full" style={{ backgroundColor: subjectColor }} />
      <View className="flex-1">
        <Text variant="body" weight="medium" numberOfLines={1}>
          {deck.title}
        </Text>
        <Text variant="caption" tone="muted">
          {deck.cardCount} {deck.cardCount === 1 ? 'card' : 'cards'}
          {subjectName ? ` · ${subjectName}` : ''}
          {deck.shared ? ' · shared' : ''}
          {deck.lastStudied ? ` · ${timeAgo(deck.lastStudied)}` : ''}
        </Text>
      </View>
      <Ionicons name="chevron-forward" size={16} color={colors.inkSubtle} />
    </Pressable>
  );
}
