import { Ionicons } from '@expo/vector-icons';
import React, { useState } from 'react';
import { Pressable, View } from 'react-native';

import { LegalLinks } from '@/components/legal/LegalLinks';
import { Avatar, Button, Card, Input, Screen, SectionHeader, Text } from '@/components/ui';
import { isSupabaseConfigured } from '@/constants/config';
import { aiService } from '@/services';
import { useAuth } from '@/hooks';
import type { RootStackScreenProps } from '@/navigation/types';
import { useTheme, type ThemePreference } from '@/providers/ThemeProvider';
import { cn } from '@/utils/cn';
import { formatCompact } from '@/utils/format';

const themeOptions: { value: ThemePreference; label: string; icon: React.ComponentProps<typeof Ionicons>['name'] }[] = [
  { value: 'light', label: 'Light', icon: 'sunny-outline' },
  { value: 'dark', label: 'Dark', icon: 'moon-outline' },
  { value: 'system', label: 'System', icon: 'phone-portrait-outline' },
];

const backgroundChoices = ['#E0E7FF', '#FEE2E2', '#FEF3C7', '#DCFCE7', '#E0F2FE', '#F3E8FF', '#FCE7F3', '#F1F5F9'];

export function SettingsScreen({ navigation }: RootStackScreenProps<'Settings'>) {
  const { preference, setPreference, colors } = useTheme();
  const { profile, isGuest, signOut, updateProfile } = useAuth();

  return (
    <Screen safeTop={false} contentClassName="pt-4">
      {profile && (
        <View className="mb-8 flex-row items-center gap-4">
          <Avatar avatar={profile.avatar} name={profile.displayName} size={64} />
          <View className="flex-1">
            <Text variant="title">{profile.displayName || 'New student'}</Text>
            <Text variant="caption" tone="muted" className="mt-0.5">
              {profile.username ? `@${profile.username}` : 'Add a name to get started'}
              {profile.school ? ` · ${profile.school}` : ''}
            </Text>
            <Text variant="caption" tone="muted" className="mt-1">
              Level {profile.level} · {formatCompact(profile.xp)} XP · {profile.streakDays}-day streak
            </Text>
          </View>
        </View>
      )}

      {profile && <NameForm key={`${profile.displayName}:${profile.username}`} profile={profile} onSave={updateProfile} />}

      <SectionHeader title="Appearance" />
      <View className="mb-8 flex-row gap-2">
        {themeOptions.map((opt) => {
          const active = preference === opt.value;
          return (
            <Pressable
              key={opt.value}
              onPress={() => setPreference(opt.value)}
              className={cn(
                'flex-1 flex-row items-center justify-center gap-2 rounded-full border py-3',
                active ? 'border-primary-600 bg-primary-600 dark:border-primary-500 dark:bg-primary-500' : 'border-line dark:border-line-dark',
              )}
            >
              <Ionicons name={opt.icon} size={16} color={active ? colors.canvas : colors.inkMuted} />
              <Text variant="label" className={cn(active ? 'text-white dark:text-ink' : 'text-ink-muted dark:text-ink-muted-dark')}>
                {opt.label}
              </Text>
            </Pressable>
          );
        })}
      </View>

      {profile && (
        <>
          <SectionHeader title="Avatar colour" subtitle="Frames unlock as your streak grows" />
          <View className="mb-8 flex-row flex-wrap gap-3">
            {backgroundChoices.map((bg) => (
              <Pressable
                key={bg}
                onPress={() => updateProfile({ avatar: { ...profile.avatar, background: bg } })}
                className={cn(
                  'h-10 w-10 items-center justify-center rounded-full border-[1.5px]',
                  profile.avatar.background === bg ? 'border-ink dark:border-ink-dark' : 'border-transparent',
                )}
                style={{ backgroundColor: bg }}
                accessibilityLabel={`Background ${bg}`}
              >
                <Text variant="heading" style={{ fontSize: 18, lineHeight: 22, color: '#1F2937' }}>
                  {profile.displayName.trim().charAt(0).toUpperCase() || '·'}
                </Text>
              </Pressable>
            ))}
          </View>
        </>
      )}

      <SectionHeader title="Integrations" />
      <Card className="mb-8 gap-4">
        <Row icon="server-outline" label="Supabase" value={isSupabaseConfigured ? 'Connected' : 'Not configured · using mock data'} ok={isSupabaseConfigured} />
        <Row
          icon="sparkles-outline"
          label="AI Helper backend"
          value={aiService.isLive ? 'Local IDE gateway' : 'Demo responses'}
          ok={aiService.isLive}
        />
      </Card>

      <SectionHeader title="Account" />
      <Card className="gap-3">
        {isGuest ? (
          <>
            <Text variant="body" tone="muted">
              You&apos;re browsing as a guest. Sign in to sync your schedule, XP and posts across devices.
            </Text>
            <Button label="Sign in or create account" variant="ink" onPress={() => navigation.navigate('Auth')} disabled={!isSupabaseConfigured} />
            {!isSupabaseConfigured && (
              <Text variant="caption" tone="subtle">
                Add EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_ANON_KEY to enable authentication.
              </Text>
            )}
          </>
        ) : (
          <Button label="Sign out" variant="outline" icon="log-out-outline" onPress={signOut} />
        )}
      </Card>

      <SectionHeader title="Legal & accessibility" className="mt-8" />
      <LegalLinks />

      <Text variant="caption" tone="subtle" className="mt-8 text-center">
        Viantis v1.0.0
      </Text>
    </Screen>
  );
}

const handleFromName = (name: string) =>
  name
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '.')
    .replace(/^\.+|\.+$/g, '')
    .slice(0, 24) || 'student';

function NameForm({
  profile,
  onSave,
}: {
  profile: { displayName: string; username: string };
  onSave: (patch: { displayName: string; username: string }) => void;
}) {
  const [displayName, setDisplayName] = useState(profile.displayName);
  const [username, setUsername] = useState(profile.username);
  const [handleEdited, setHandleEdited] = useState(false);
  const [saved, setSaved] = useState(false);
  const cleanName = displayName.trim();
  const cleanHandle = username
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9._]/g, '')
    .slice(0, 24);
  const dirty = cleanName !== profile.displayName || cleanHandle !== profile.username;
  const valid = cleanName.length >= 1 && cleanHandle.length >= 2;

  return (
    <>
      <SectionHeader title="Your name" subtitle="Shown on the dashboard, posts and the leaderboard" />
      <Input
        label="Display name"
        placeholder="Your name"
        value={displayName}
        onChangeText={(value) => {
          setDisplayName(value);
          setSaved(false);
          if (!handleEdited) setUsername(handleFromName(value));
        }}
        autoCapitalize="words"
        maxLength={40}
        containerClassName="mb-3"
      />
      <Input
        label="Username"
        placeholder="username"
        value={username}
        onChangeText={(value) => {
          setHandleEdited(true);
          setUsername(value.replace(/[^a-zA-Z0-9._]/g, ''));
          setSaved(false);
        }}
        autoCapitalize="none"
        autoCorrect={false}
        maxLength={24}
        containerClassName="mb-3"
      />
      <Button
        label={saved ? 'Saved' : 'Save name'}
        variant="ink"
        disabled={!dirty || !valid}
        onPress={() => {
          onSave({ displayName: cleanName, username: cleanHandle || handleFromName(cleanName) });
          setSaved(true);
        }}
        className="mb-8"
      />
    </>
  );
}

function Row({ icon, label, value, ok }: { icon: React.ComponentProps<typeof Ionicons>['name']; label: string; value: string; ok: boolean }) {
  const { colors } = useTheme();
  return (
    <View className="flex-row items-center gap-3">
      <Ionicons name={icon} size={20} color={colors.inkMuted} />
      <View className="flex-1">
        <Text variant="body" weight="medium">
          {label}
        </Text>
        <Text variant="caption" tone="muted">
          {value}
        </Text>
      </View>
      <View className={cn('h-2 w-2 rounded-full', ok ? 'bg-success' : 'bg-ink-subtle')} />
    </View>
  );
}
