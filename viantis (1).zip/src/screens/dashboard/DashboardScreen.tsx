import { Ionicons } from '@expo/vector-icons';
import React, { useMemo } from 'react';
import { Pressable, View } from 'react-native';

import { BrandHeader, ChatFab } from '@/components/brand';
import { gameMark } from '@/components/icons';
import { FocusPanel, StatsStrip, WeeklyActivity } from '@/components/dashboard';
import { LegalLinks } from '@/components/legal/LegalLinks';
import { TaskItem } from '@/components/schedule/TaskItem';
import { CampusPhoto, EmptyState, Screen, SectionHeader, Skeleton, Text } from '@/components/ui';
import { palette } from '@/constants/theme';
import { mockGames, mockPosts } from '@/data';
import { useAuth, useStudyStats, useTasks } from '@/hooks';
import type { ScheduleScreenProps } from '@/navigation/types';
import { useTheme } from '@/providers/ThemeProvider';
import { timeAgo } from '@/utils/date';
import { formatCompact, formatMinutes } from '@/utils/format';

/**
 * Editorial landing: architectural hero, admission manifesto,
 * then the student’s schedule on the same canvas.
 */
export function DashboardScreen({ navigation }: ScheduleScreenProps<'Dashboard'>) {
  const { profile } = useAuth();
  const { colors } = useTheme();
  const { todayTasks, upcoming, overdue, loading, refresh, toggleDone, subjectsById } = useTasks();
  const stats = useStudyStats();

  const openTasks = useMemo(() => todayTasks.filter((t) => t.status !== 'done'), [todayTasks]);
  const doneCount = todayTasks.length - openTasks.length;
  const nextTask = openTasks[0] ?? upcoming[0];
  const laterThisWeek = useMemo(
    () => upcoming.filter((t) => !todayTasks.some((tt) => tt.id === t.id)).slice(0, 3),
    [upcoming, todayTasks],
  );
  const featuredGame = mockGames[2]!;
  const trendingPost = mockPosts[0]!;
  const firstName = profile?.displayName?.split(' ')[0];

  return (
    <View className="flex-1" style={{ backgroundColor: colors.canvas }}>
      <BrandHeader />
      <Screen
        refreshing={loading}
        onRefresh={refresh}
        safeTop={false}
        padded={false}
        contentClassName="pb-28"
      >
        <CampusPhoto photo="columbia" height={320} dim={0.42} caption={false} rounded={false} grayscale>
          <View className="flex-1 justify-end px-5 pb-6">
            <Text
              variant="overline"
              tone="inverse"
              style={{ letterSpacing: 1.8, fontSize: 11, lineHeight: 16 }}
            >
              System online: 4,800+ institutions indexed
            </Text>
          </View>
        </CampusPhoto>

        <View className="px-5 pt-10 pb-2" style={{ backgroundColor: palette.cream[50] }}>
          <Text variant="overline" style={{ color: palette.coral[500], letterSpacing: 1.6 }}>
            Autonomous academic intelligence
          </Text>
          <Text
            variant="display"
            style={{
              color: '#111111',
              fontSize: 40,
              lineHeight: 42,
              letterSpacing: -0.8,
              marginTop: 14,
              textTransform: 'uppercase',
            }}
          >
            Demystifying admission.
          </Text>
          <View style={{ height: 1, backgroundColor: '#E4DDD2', marginTop: 22, marginBottom: 22 }} />
          <Text variant="body" style={{ color: '#4A4844', lineHeight: 24 }}>
            {firstName ? `${firstName}, ` : ''}
            Viantis reads a plain-language brief and maps institutions, SAT bands, and placement
            paths in seconds — diagnostic first, then predictive, then direct.
          </Text>
          <Text variant="overline" className="mt-5" style={{ color: '#8A8780', letterSpacing: 1.1 }}>
            [ Phase I: Diagnostic / Phase II: Predictive mapping / Phase III: Direct match ]
          </Text>
          <Pressable
            onPress={() => navigation.navigate('FinderTab')}
            className="mt-8 mb-10 flex-row items-center active:opacity-70"
          >
            <Text variant="heading" style={{ color: '#111111', fontSize: 16, lineHeight: 20, letterSpacing: 0.6 }}>
              INITIATE ACADEMIC SEARCH
            </Text>
            <View
              className="ml-3 h-9 w-9 items-center justify-center"
              style={{ borderRadius: 999, borderWidth: 1, borderColor: '#111111' }}
            >
              <Ionicons name="arrow-forward" size={16} color="#111111" />
            </View>
          </Pressable>
        </View>

        <View className="px-5 pt-8">
          {profile ? (
            <StatsStrip
              className="mb-7"
              stats={[
                { key: 'streak', value: `${profile.streakDays}`, label: 'day streak' },
                { key: 'today', value: formatMinutes(stats.todayMinutes), label: 'focused today' },
                {
                  key: 'xp',
                  value: formatCompact(profile.xp),
                  label: `XP · level ${profile.level}`,
                  onPress: () => navigation.navigate('Leaderboard'),
                },
              ]}
            />
          ) : (
            <Skeleton height={72} rounded={0} className="mb-7" />
          )}

          <FocusPanel
            nextTask={nextTask}
            subject={nextTask ? subjectsById.get(nextTask.subjectId) : undefined}
            focusMinutes={25}
            onStart={(taskId) => navigation.navigate('Pomodoro', { taskId })}
            onChooseTask={() => navigation.navigate('Planner')}
          />

          <SectionHeader
            title="Today"
            subtitle={
              todayTasks.length
                ? `${doneCount} of ${todayTasks.length} done${overdue.length ? ` · ${overdue.length} overdue` : ''}`
                : undefined
            }
            actionLabel="Planner"
            onAction={() => navigation.navigate('Planner')}
            className="mb-1"
          />
          <View className="mb-8">
            {loading && !todayTasks.length ? (
              <View className="gap-3 py-3">
                <Skeleton height={44} rounded={8} />
                <Skeleton height={44} rounded={8} />
              </View>
            ) : todayTasks.length ? (
              todayTasks.map((task, i) => (
                <TaskItem
                  key={task.id}
                  task={task}
                  subject={subjectsById.get(task.subjectId)}
                  onToggle={toggleDone}
                  onPress={(t) => navigation.navigate('TaskEditor', { taskId: t.id })}
                  last={i === todayTasks.length - 1}
                />
              ))
            ) : (
              <EmptyState
                icon="calendar-clear-outline"
                title="A clear day"
                description="Add a task or pull one forward from later in the week."
                actionLabel="Add task"
                onAction={() => navigation.navigate('TaskEditor')}
                className="py-6"
              />
            )}
          </View>

          <WeeklyActivity week={stats.week} weekMinutes={stats.weekMinutes} maxMinutes={stats.maxMinutes} />

          {laterThisWeek.length > 0 && (
            <>
              <SectionHeader title="Later this week" actionLabel="See all" onAction={() => navigation.navigate('Planner')} className="mb-1" />
              <View className="mb-8">
                {laterThisWeek.map((task, i) => (
                  <TaskItem
                    key={task.id}
                    task={task}
                    subject={subjectsById.get(task.subjectId)}
                    onToggle={toggleDone}
                    onPress={(t) => navigation.navigate('TaskEditor', { taskId: t.id })}
                    last={i === laterThisWeek.length - 1}
                    showDate
                  />
                ))}
              </View>
            </>
          )}

          <SectionHeader title="Elsewhere" />
          <View className="mb-2 flex-row gap-3">
            <Pressable
              className="flex-1 justify-between p-4 active:opacity-90"
              style={{ minHeight: 168, backgroundColor: colors.deep }}
              onPress={() => navigation.navigate('Game', { gameId: featuredGame.id })}
            >
              {(() => {
                const Mark = gameMark(featuredGame.icon);
                return <Mark color="#F6F1E8" size={26} />;
              })()}
              <View>
                <Text variant="caption" style={{ color: 'rgba(246,241,232,0.65)' }}>
                  Daily challenge
                </Text>
                <Text variant="heading" style={{ color: '#F6F1E8' }}>
                  {featuredGame.title}
                </Text>
                <Text variant="caption" className="mt-1" style={{ color: 'rgba(246,241,232,0.65)' }}>
                  +{featuredGame.xpPerRound} XP · {featuredGame.durationLabel}
                </Text>
              </View>
            </Pressable>

            <Pressable
              className="flex-1 overflow-hidden active:opacity-90"
              onPress={() => navigation.navigate('PostDetail', { postId: trendingPost.id })}
            >
              <CampusPhoto photo="yale" height={168} dim={0.4} caption={false} rounded={false}>
                <View className="flex-1 justify-between p-4">
                  <Text variant="caption" tone="inverseMuted">
                    From the community
                  </Text>
                  <View>
                    <Text variant="heading" tone="inverse" numberOfLines={3} style={{ fontSize: 18, lineHeight: 22 }}>
                      {trendingPost.title}
                    </Text>
                    <Text variant="caption" tone="inverseMuted" className="mt-1">
                      {trendingPost.upvotes} upvotes · {timeAgo(trendingPost.createdAt)}
                    </Text>
                  </View>
                </View>
              </CampusPhoto>
            </Pressable>
          </View>

          <LegalLinks compact className="mt-10 mb-2" />
        </View>
      </Screen>
      <ChatFab prompt="Help me refine my target-school brief." />
    </View>
  );
}
