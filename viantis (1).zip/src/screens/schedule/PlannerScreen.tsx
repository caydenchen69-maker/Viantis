import { Ionicons } from '@expo/vector-icons';
import React, { useMemo, useState } from 'react';
import { Pressable, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { BrandHeader } from '@/components/brand';
import { CalendarStrip, dayKey } from '@/components/schedule/CalendarStrip';
import { TaskItem } from '@/components/schedule/TaskItem';
import { EmptyState, IconButton, Screen, SectionHeader, Text } from '@/components/ui';
import { useTasks } from '@/hooks';
import type { ScheduleScreenProps } from '@/navigation/types';
import { useTheme } from '@/providers/ThemeProvider';
import { formatMinutes } from '@/utils/format';

export function PlannerScreen({ navigation, route }: ScheduleScreenProps<'Planner'>) {
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const initial = route.params?.date ? new Date(route.params.date) : new Date();
  const [selected, setSelected] = useState(initial);
  const { tasks, tasksForDay, toggleDone, subjectsById, overdue, loading, refresh } = useTasks();

  const dayTasks = useMemo(() => tasksForDay(selected), [tasksForDay, selected]);
  const taskCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const t of tasks) {
      const key = dayKey(new Date(t.dueAt));
      counts[key] = (counts[key] ?? 0) + 1;
    }
    return counts;
  }, [tasks]);

  const plannedMinutes = dayTasks.reduce((acc, t) => acc + t.estimatedMinutes, 0);
  const open = dayTasks.filter((t) => t.status !== 'done');
  const done = dayTasks.filter((t) => t.status === 'done');

  return (
    <View className="flex-1 bg-canvas dark:bg-canvas-dark">
      <BrandHeader />
      <Screen refreshing={loading} onRefresh={refresh} safeTop={false} contentClassName="pb-28">
        <View className="mb-4 flex-row items-center gap-3">
          <IconButton name="chevron-back" onPress={() => navigation.goBack()} accessibilityLabel="Back" />
          <Text variant="title">Planner</Text>
        </View>

        <CalendarStrip selected={selected} onSelect={setSelected} taskCounts={taskCounts} />

        {overdue.length > 0 && (
          <View className="mb-5 flex-row items-center gap-2">
            <View className="h-1.5 w-1.5 rounded-full bg-danger" />
            <Text variant="caption" tone="danger">
              {overdue.length} overdue {overdue.length === 1 ? 'task' : 'tasks'} — reschedule or mark them done.
            </Text>
          </View>
        )}

        <SectionHeader
          title={open.length ? `${open.length} to do` : 'All clear'}
          subtitle={dayTasks.length ? `${formatMinutes(plannedMinutes)} planned` : undefined}
          actionLabel="Focus"
          onAction={() => navigation.navigate('Pomodoro', { taskId: open[0]?.id })}
        />

        <View>
          {dayTasks.length === 0 ? (
            <EmptyState
              icon="sunny-outline"
              title="Nothing planned"
              description="Use the + button to schedule a task for this day."
              className="py-8"
            />
          ) : (
            <>
              {open.map((task, i) => (
                <TaskItem
                  key={task.id}
                  task={task}
                  subject={subjectsById.get(task.subjectId)}
                  onToggle={toggleDone}
                  onPress={(t) => navigation.navigate('TaskEditor', { taskId: t.id })}
                  last={i === open.length - 1 && done.length === 0}
                />
              ))}
              {done.length > 0 && (
                <>
                  <Text variant="overline" tone="subtle" className="mt-6 mb-1">
                    Completed
                  </Text>
                  {done.map((task, i) => (
                    <TaskItem
                      key={task.id}
                      task={task}
                      subject={subjectsById.get(task.subjectId)}
                      onToggle={toggleDone}
                      onPress={(t) => navigation.navigate('TaskEditor', { taskId: t.id })}
                      last={i === done.length - 1}
                    />
                  ))}
                </>
              )}
            </>
          )}
        </View>
      </Screen>

      <Pressable
        onPress={() => navigation.navigate('TaskEditor', { date: selected.toISOString() })}
        accessibilityRole="button"
        accessibilityLabel="Add task"
        className="absolute right-5 h-14 w-14 items-center justify-center rounded-full bg-primary-600 dark:bg-primary-500 active:opacity-90"
        style={{ bottom: insets.bottom + 20 }}
      >
        <Ionicons name="add" size={28} color="#FFFFFF" />
      </Pressable>
    </View>
  );
}
