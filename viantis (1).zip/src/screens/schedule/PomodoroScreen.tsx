import { Ionicons } from '@expo/vector-icons';
import React, { useState } from 'react';
import { Pressable, Switch, View } from 'react-native';

import { TimerRing } from '@/components/schedule/TimerRing';
import { Button, Card, Chip, IconButton, Screen, SegmentedControl, Text } from '@/components/ui';
import { palette } from '@/constants/theme';
import { ambientSounds, pomodoroPresets } from '@/data';
import { usePomodoro, useTasks, type PomodoroPhase } from '@/hooks';
import type { RootStackScreenProps } from '@/navigation/types';
import { useTheme } from '@/providers/ThemeProvider';
import { soundService } from '@/services';
import { formatCountdown } from '@/utils/date';

const phaseMeta: Record<PomodoroPhase, { label: string; color: string; hint: string }> = {
  focus: { label: 'Focus', color: palette.coral[500], hint: 'Deep work. Phone down.' },
  short_break: { label: 'Short break', color: palette.success, hint: 'Stretch, hydrate, look away.' },
  long_break: { label: 'Long break', color: palette.info, hint: 'You earned it. Step outside.' },
};

export function PomodoroScreen({ route, navigation }: RootStackScreenProps<'Pomodoro'>) {
  const taskId = route.params?.taskId;
  const { colors } = useTheme();
  const { tasks, subjectsById } = useTasks();
  const timer = usePomodoro(taskId);
  const [showSettings, setShowSettings] = useState(false);

  const task = tasks.find((t) => t.id === taskId);
  const meta = phaseMeta[timer.phase];
  const running = timer.status === 'running';
  const roundsPerCycle = timer.settings.roundsBeforeLongBreak;
  // Show a full row right after the cycle completes instead of snapping back to zero.
  const filledRounds =
    timer.completedRounds > 0 && timer.completedRounds % roundsPerCycle === 0
      ? roundsPerCycle
      : timer.completedRounds % roundsPerCycle;

  return (
    <Screen safeTop={false} contentClassName="pt-2 pb-10">
      <SegmentedControl<PomodoroPhase>
        options={[
          { value: 'focus', label: 'Focus' },
          { value: 'short_break', label: 'Short' },
          { value: 'long_break', label: 'Long' },
        ]}
        value={timer.phase}
        onChange={(p) => timer.setPhase(p)}
        className="mb-6"
      />

      {task && (
        <View className="mb-6 flex-row items-center justify-center gap-2 px-4">
          <View className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: subjectsById.get(task.subjectId)?.color }} />
          <Text variant="caption" tone="muted" numberOfLines={1}>
            {task.title} · {subjectsById.get(task.subjectId)?.name}
          </Text>
        </View>
      )}

      <View className="items-center">
        <TimerRing progress={timer.progress} color={meta.color}>
          <Text variant="heading" italic tone="muted" style={{ fontSize: 18, lineHeight: 22 }}>
            {meta.label}
          </Text>
          <Text
            variant="display"
            className="mt-1"
            style={{ fontSize: 84, lineHeight: 92, fontVariant: ['tabular-nums'], letterSpacing: -1 }}
          >
            {formatCountdown(timer.secondsLeft)}
          </Text>
          <Text variant="caption" tone="muted" className="mt-1">
            {running ? meta.hint : timer.status === 'paused' ? 'Paused' : 'Ready when you are'}
          </Text>
        </TimerRing>

        <View className="mt-4 flex-row gap-2">
          {Array.from({ length: timer.settings.roundsBeforeLongBreak }).map((_, i) => (
            <View
              key={i}
              className="h-1.5 w-1.5 rounded-full"
              style={{ backgroundColor: i < filledRounds ? colors.ink : colors.line }}
            />
          ))}
        </View>
        <Text variant="caption" tone="subtle" className="mt-2">
          {timer.completedRounds} {timer.completedRounds === 1 ? 'round' : 'rounds'} completed
        </Text>
      </View>

      <View className="mt-8 flex-row items-center justify-center gap-5">
        <IconButton name="refresh-outline" size={20} onPress={timer.reset} accessibilityLabel="Reset timer" variant="soft" className="h-12 w-12" />
        <Pressable
          onPress={running ? timer.pause : timer.start}
          accessibilityRole="button"
          accessibilityLabel={running ? 'Pause' : 'Start'}
          className="h-[72px] w-[72px] items-center justify-center rounded-full bg-primary-600 dark:bg-primary-500 active:opacity-90"
        >
          <Ionicons name={running ? 'pause' : 'play'} size={30} color={colors.canvas} style={{ marginLeft: running ? 0 : 4 }} />
        </Pressable>
        <IconButton name="play-skip-forward-outline" size={20} onPress={timer.skip} accessibilityLabel="Skip phase" variant="soft" className="h-12 w-12" />
      </View>

      {/* Ambient sounds */}
      <Text variant="heading" className="mt-10 mb-3">
        Ambient sound
      </Text>
      <View className="flex-row flex-wrap gap-2">
        <Chip label="Off" icon="volume-mute-outline" selected={timer.settings.ambientSound === null} onPress={() => timer.updateSettings({ ambientSound: null })} />
        {ambientSounds.map((s) => {
          const available = soundService.isAmbientAvailable(s.id);
          return (
            <Chip
              key={s.id}
              label={available ? s.label : `${s.label} · soon`}
              icon={s.icon as never}
              selected={timer.settings.ambientSound === s.id}
              onPress={available ? () => timer.updateSettings({ ambientSound: s.id }) : undefined}
              className={available ? undefined : 'opacity-50'}
            />
          );
        })}
      </View>

      {/* Settings */}
      <Pressable onPress={() => setShowSettings((v) => !v)} className="mt-8 flex-row items-center justify-between border-t border-line py-4 dark:border-line-dark">
        <Text variant="heading">Timer settings</Text>
        <Ionicons name={showSettings ? 'chevron-up' : 'chevron-down'} size={18} color={colors.inkMuted} />
      </Pressable>

      {showSettings && (
        <Card className="mt-2 gap-5">
          <View>
            <Text variant="label" tone="muted" className="mb-2">
              Presets
            </Text>
            <View className="flex-row gap-2">
              {pomodoroPresets.map((p) => (
                <Chip
                  key={p.label}
                  label={`${p.label} · ${p.focus}/${p.short}`}
                  selected={timer.settings.focusMinutes === p.focus && timer.settings.shortBreakMinutes === p.short}
                  onPress={() =>
                    timer.updateSettings({ focusMinutes: p.focus, shortBreakMinutes: p.short, longBreakMinutes: p.long })
                  }
                />
              ))}
            </View>
          </View>

          <Stepper label="Focus" value={timer.settings.focusMinutes} unit="min" min={5} max={120} step={5} onChange={(v) => timer.updateSettings({ focusMinutes: v })} />
          <Stepper label="Short break" value={timer.settings.shortBreakMinutes} unit="min" min={1} max={30} step={1} onChange={(v) => timer.updateSettings({ shortBreakMinutes: v })} />
          <Stepper label="Long break" value={timer.settings.longBreakMinutes} unit="min" min={5} max={60} step={5} onChange={(v) => timer.updateSettings({ longBreakMinutes: v })} />
          <Stepper label="Rounds before long break" value={timer.settings.roundsBeforeLongBreak} unit="" min={2} max={8} step={1} onChange={(v) => timer.updateSettings({ roundsBeforeLongBreak: v })} />

          <ToggleRow label="Auto-start breaks" value={timer.settings.autoStartBreaks} onChange={(v) => timer.updateSettings({ autoStartBreaks: v })} />
          <ToggleRow label="Chime when a phase ends" value={timer.settings.soundEnabled} onChange={(v) => timer.updateSettings({ soundEnabled: v })} />

          <Button label="Preview chime" variant="outline" size="sm" icon="notifications-outline" onPress={() => soundService.playChime()} />
        </Card>
      )}

      {!task && (
        <Button
          label="Attach a task"
          variant="ghost"
          icon="link-outline"
          className="mt-4"
          onPress={() => navigation.navigate('Tabs', { screen: 'ScheduleTab', params: { screen: 'Planner' } })}
        />
      )}
    </Screen>
  );
}

function Stepper({
  label,
  value,
  unit,
  min,
  max,
  step,
  onChange,
}: {
  label: string;
  value: number;
  unit: string;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
}) {
  return (
    <View className="flex-row items-center justify-between">
      <Text variant="body">{label}</Text>
      <View className="flex-row items-center gap-3">
        <IconButton name="remove" size={16} variant="soft" onPress={() => onChange(Math.max(min, value - step))} accessibilityLabel={`Decrease ${label}`} className="h-8 w-8" />
        <Text variant="label" className="w-14 text-center font-semibold">
          {value}
          {unit ? ` ${unit}` : ''}
        </Text>
        <IconButton name="add" size={16} variant="soft" onPress={() => onChange(Math.min(max, value + step))} accessibilityLabel={`Increase ${label}`} className="h-8 w-8" />
      </View>
    </View>
  );
}

function ToggleRow({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  const { colors } = useTheme();
  return (
    <View className="flex-row items-center justify-between">
      <Text variant="body">{label}</Text>
      <Switch value={value} onValueChange={onChange} trackColor={{ true: colors.primary, false: colors.line }} thumbColor="#FFFFFF" />
    </View>
  );
}
