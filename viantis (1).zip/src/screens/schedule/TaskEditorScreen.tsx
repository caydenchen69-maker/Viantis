import React, { useState } from 'react';
import { Alert, Pressable, View } from 'react-native';

import { Button, Chip, Input, Screen, Skeleton, Text } from '@/components/ui';
import { mockSubjects } from '@/data';
import { useTasks } from '@/hooks';
import type { RootStackScreenProps } from '@/navigation/types';
import type { StudyTask, TaskPriority } from '@/types';
import { cn } from '@/utils/cn';
import { formatShortDate, formatTime } from '@/utils/date';

const durations = [15, 25, 30, 45, 60, 90, 120];
const priorities: { value: TaskPriority; label: string }[] = [
  { value: 'low', label: 'Low' },
  { value: 'medium', label: 'Medium' },
  { value: 'high', label: 'High' },
];

export function TaskEditorScreen({ navigation, route }: RootStackScreenProps<'TaskEditor'>) {
  const { tasks, loading, createTask, deleteTask, toggleDone } = useTasks();
  const taskId = route.params?.taskId;
  const existing = taskId ? tasks.find((t) => t.id === taskId) : undefined;

  if (taskId && loading && !existing) {
    return (
      <Screen safeTop={false} contentClassName="pt-4 gap-4">
        <Skeleton height={48} rounded={12} />
        <Skeleton height={36} width="60%" />
        <Skeleton height={120} rounded={12} />
      </Screen>
    );
  }

  const defaultDue = (() => {
    const d = route.params?.date ? new Date(route.params.date) : new Date();
    d.setHours(17, 0, 0, 0);
    return d;
  })();

  return (
    <TaskForm
      key={existing?.id ?? 'new'}
      existing={existing}
      defaultDue={defaultDue}
      onCreate={async (input) => {
        await createTask(input);
        navigation.goBack();
      }}
      onToggleDone={(task) => {
        toggleDone(task);
        navigation.goBack();
      }}
      onDelete={async (task) => {
        await deleteTask(task.id);
        navigation.goBack();
      }}
      onFocus={(task) => navigation.replace('Pomodoro', { taskId: task.id })}
    />
  );
}

interface TaskFormProps {
  existing?: StudyTask;
  defaultDue: Date;
  onCreate: (input: Omit<StudyTask, 'id' | 'completedMinutes' | 'status'>) => Promise<void>;
  onToggleDone: (task: StudyTask) => void;
  onDelete: (task: StudyTask) => Promise<void>;
  onFocus: (task: StudyTask) => void;
}

function TaskForm({ existing, defaultDue, onCreate, onToggleDone, onDelete, onFocus }: TaskFormProps) {
  const readOnly = Boolean(existing);
  const [title, setTitle] = useState(existing?.title ?? '');
  const [subjectId, setSubjectId] = useState(existing?.subjectId ?? mockSubjects[0]!.id);
  const [minutes, setMinutes] = useState(existing?.estimatedMinutes ?? 25);
  const [priority, setPriority] = useState<TaskPriority>(existing?.priority ?? 'medium');
  const [notes, setNotes] = useState(existing?.notes ?? '');
  const [saving, setSaving] = useState(false);

  const dueAt = existing ? new Date(existing.dueAt) : defaultDue;

  const save = async () => {
    if (!title.trim()) return;
    setSaving(true);
    try {
      await onCreate({
        title: title.trim(),
        subjectId,
        dueAt: dueAt.toISOString(),
        estimatedMinutes: minutes,
        priority,
        notes: notes.trim() || undefined,
      });
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = () => {
    if (!existing) return;
    Alert.alert('Delete task?', 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => void onDelete(existing) },
    ]);
  };

  return (
    <Screen safeTop={false} contentClassName="pt-4">
      <Input
        label="Task"
        placeholder="e.g. Finish chapter 7 reading"
        value={title}
        onChangeText={setTitle}
        autoFocus={!readOnly}
        editable={!readOnly}
        containerClassName="mb-5"
      />

      <Text variant="label" tone="muted" className="mb-2">
        Subject
      </Text>
      <View className="mb-5 flex-row flex-wrap gap-2">
        {mockSubjects.map((s) => (
          <Chip
            key={s.id}
            label={s.name}
            color={s.color}
            selected={s.id === subjectId}
            onPress={readOnly ? undefined : () => setSubjectId(s.id)}
          />
        ))}
      </View>

      <Text variant="label" tone="muted" className="mb-2">
        Due
      </Text>
      <View className="mb-5 h-12 flex-row items-center gap-2 rounded-full border border-line bg-surface px-4 dark:border-line-dark dark:bg-surface-dark">
        <Text variant="body">
          {formatShortDate(dueAt)} · {formatTime(dueAt)}
        </Text>
      </View>

      <Text variant="label" tone="muted" className="mb-2">
        Estimated time
      </Text>
      <View className="mb-5 flex-row flex-wrap gap-2">
        {durations.map((d) => (
          <Chip
            key={d}
            label={d >= 60 ? `${Math.floor(d / 60)}h${d % 60 ? ` ${d % 60}m` : ''}` : `${d}m`}
            selected={d === minutes}
            onPress={readOnly ? undefined : () => setMinutes(d)}
          />
        ))}
      </View>

      <Text variant="label" tone="muted" className="mb-2">
        Priority
      </Text>
      <View className="mb-5 flex-row gap-2">
        {priorities.map((p) => (
          <Pressable
            key={p.value}
            onPress={readOnly ? undefined : () => setPriority(p.value)}
            className={cn(
              'flex-1 items-center rounded-full border py-2.5',
              priority === p.value
                ? 'border-primary-600 bg-primary-600 dark:border-primary-500 dark:bg-primary-500'
                : 'border-line dark:border-line-dark',
            )}
          >
            <Text
              variant="label"
              className={cn(priority === p.value ? 'text-white dark:text-ink' : 'text-ink-muted dark:text-ink-muted-dark')}
            >
              {p.label}
            </Text>
          </Pressable>
        ))}
      </View>

      <Input
        label="Notes"
        placeholder="Optional details"
        value={notes}
        onChangeText={setNotes}
        multiline
        editable={!readOnly}
        containerClassName="mb-6"
        className="min-h-[60px] py-2"
      />

      {existing ? (
        <View className="gap-3">
          <Button
            label={existing.status === 'done' ? 'Mark as not done' : 'Mark as done'}
            variant="ink"
            onPress={() => onToggleDone(existing)}
            fullWidth
            size="lg"
          />
          <Button
            label="Start focus session"
            variant="outline"
            fullWidth
            size="lg"
            onPress={() => onFocus(existing)}
          />
          <Button label="Delete task" variant="ghost" fullWidth onPress={confirmDelete} className="text-danger" />
        </View>
      ) : (
        <Button label="Add task" variant="ink" size="lg" fullWidth onPress={save} loading={saving} disabled={!title.trim()} />
      )}
    </Screen>
  );
}
