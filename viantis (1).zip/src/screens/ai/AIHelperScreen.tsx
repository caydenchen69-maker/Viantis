import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, Pressable, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { ChatBubble } from '@/components/ai/ChatBubble';
import { ChatComposer } from '@/components/ai/ChatComposer';
import { ComposerPane } from '@/components/ai/ComposerPane';
import { BrandHeader } from '@/components/brand';
import { IconButton, SegmentedControl, Text } from '@/components/ui';
import { STORAGE_KEYS } from '@/constants/config';
import { aiSuggestedPrompts, aiWelcomeMessage } from '@/data';
import { useImagePicker } from '@/hooks';
import type { TabScreenProps } from '@/navigation/types';
import { useTheme } from '@/providers/ThemeProvider';
import { aiService } from '@/services';
import type { ChatAttachment, ChatMessage } from '@/types';
import { cn } from '@/utils/cn';
import { uid } from '@/utils/format';

type HelperMode = 'composer' | 'chat';

export function AIHelperScreen({ route }: TabScreenProps<'AIHelperTab'>) {
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { fromCamera, fromLibrary } = useImagePicker();
  const listRef = useRef<FlatList<ChatMessage>>(null);
  const abortRef = useRef<AbortController | null>(null);

  const [mode, setMode] = useState<HelperMode>('composer');
  const [draftTitle, setDraftTitle] = useState('');
  const [draft, setDraft] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([aiWelcomeMessage]);
  const [attachment, setAttachment] = useState<ChatAttachment | null>(null);
  const [busy, setBusy] = useState(false);
  const [scanning, setScanning] = useState(false);

  useEffect(() => {
    AsyncStorage.multiGet([STORAGE_KEYS.helperMode, STORAGE_KEYS.helperDraft])
      .then((entries) => {
        const stored: Record<string, string | null> = Object.fromEntries(entries);
        const savedMode = stored[STORAGE_KEYS.helperMode];
        if (savedMode === 'chat' || savedMode === 'composer') setMode(savedMode);
        if (stored[STORAGE_KEYS.helperDraft]) {
          try {
            const parsed = JSON.parse(stored[STORAGE_KEYS.helperDraft]!) as { title?: string; body?: string };
            if (parsed.title) setDraftTitle(parsed.title);
            if (parsed.body) setDraft(parsed.body);
          } catch {
            // ignore a corrupt draft
          }
        }
      })
      .catch(() => {});
  }, []);

  const persistMode = (next: HelperMode) => {
    setMode(next);
    AsyncStorage.setItem(STORAGE_KEYS.helperMode, next).catch(() => {});
  };

  const persistDraft = (title: string, body: string) => {
    AsyncStorage.setItem(STORAGE_KEYS.helperDraft, JSON.stringify({ title, body })).catch(() => {});
  };

  const scrollToEnd = () => setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 50);

  const sendChat = useCallback(
    async (prompt: string) => {
      if (busy) return;
      const userMessage: ChatMessage = {
        id: uid('m'),
        role: 'user',
        content: prompt,
        createdAt: new Date().toISOString(),
        attachments: attachment ? [attachment] : undefined,
        status: 'complete',
      };
      const assistantId = uid('m');
      const placeholder: ChatMessage = {
        id: assistantId,
        role: 'assistant',
        content: '',
        createdAt: new Date().toISOString(),
        status: 'streaming',
      };

      const history = messages.filter((m) => m.id !== aiWelcomeMessage.id);
      setMessages((prev) => [...prev, userMessage, placeholder]);
      setAttachment(null);
      setBusy(true);
      scrollToEnd();

      const controller = new AbortController();
      abortRef.current = controller;

      try {
        const fullPrompt = attachment?.ocrText ? `${prompt}\n\nProblem from photo: ${attachment.ocrText}` : prompt;
        await aiService.ask({
          history,
          prompt: fullPrompt,
          attachments: userMessage.attachments,
          signal: controller.signal,
          onToken: (partial) => {
            setMessages((prev) => prev.map((m) => (m.id === assistantId ? { ...m, content: partial } : m)));
          },
        });
        setMessages((prev) => prev.map((m) => (m.id === assistantId ? { ...m, status: 'complete' } : m)));
      } catch (e) {
        const aborted = e instanceof Error && e.name === 'AbortError';
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantId
              ? aborted
                ? { ...m, status: 'complete', content: m.content || 'Stopped.' }
                : { ...m, status: 'error', content: 'Something went wrong reaching the helper. Try again.' }
              : m,
          ),
        );
      } finally {
        setBusy(false);
        abortRef.current = null;
        scrollToEnd();
      }
    },
    [busy, attachment, messages],
  );

  const applyToDraft = useCallback(
    async (instruction: string) => {
      if (busy) return;
      setBusy(true);
      const controller = new AbortController();
      abortRef.current = controller;
      const prompt = [
        'You are editing a student draft in Composer mode.',
        'Return the full revised document only — no preamble, no markdown fences.',
        draftTitle.trim() ? `Title: ${draftTitle.trim()}` : '',
        `Current draft:\n${draft.trim() || '(empty)'}`,
        `Instruction:\n${instruction}`,
      ]
        .filter(Boolean)
        .join('\n\n');

      try {
        const result = await aiService.ask({
          history: [],
          prompt,
          signal: controller.signal,
          onToken: (partial) => {
            setDraft(partial);
            persistDraft(draftTitle, partial);
          },
        });
        setDraft(result);
        persistDraft(draftTitle, result);
      } catch (e) {
        const aborted = e instanceof Error && e.name === 'AbortError';
        if (!aborted) {
          setDraft((prev) => (prev.trim() ? prev : instruction));
        }
      } finally {
        setBusy(false);
        abortRef.current = null;
      }
    },
    [busy, draft, draftTitle],
  );

  const attach = async (picker: () => Promise<ChatAttachment | null>) => {
    const picked = await picker();
    if (!picked) return;
    setAttachment(picked);
    setScanning(true);
    try {
      const text = await aiService.extractText(picked.uri);
      setAttachment((cur) => (cur?.id === picked.id ? { ...cur, ocrText: text } : cur));
    } catch {
      // OCR is best-effort; the image is still sent to the model.
    } finally {
      setScanning(false);
    }
  };

  const stop = () => abortRef.current?.abort();

  const reset = () => {
    stop();
    if (mode === 'composer') {
      setDraftTitle('');
      setDraft('');
      persistDraft('', '');
    } else {
      setMessages([aiWelcomeMessage]);
      setAttachment(null);
    }
  };

  const initialPrompt = route.params?.prompt;
  const handledPrompt = useRef<string | undefined>(undefined);
  useEffect(() => {
    if (!initialPrompt || handledPrompt.current === initialPrompt) return;
    handledPrompt.current = initialPrompt;
    persistMode('chat');
    const timer = setTimeout(() => void sendChat(initialPrompt), 0);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialPrompt]);

  const showSuggestions = mode === 'chat' && messages.length === 1;

  return (
    <View className="flex-1 bg-canvas dark:bg-canvas-dark">
      <BrandHeader />
      <View className="flex-row items-end justify-between px-5 pb-3 pt-4">
        <View className="flex-1 pr-3">
          <Text variant="display">{mode === 'composer' ? 'Composer' : 'Helper'}</Text>
          <Text variant="caption" tone="muted" className="mt-1">
            {mode === 'composer'
              ? 'Write a draft. The helper edits this page.'
              : `Step-by-step chat${aiService.isLive ? '' : ' · demo responses'}`}
          </Text>
        </View>
        <IconButton
          name={mode === 'composer' ? 'trash-outline' : 'create-outline'}
          size={19}
          onPress={reset}
          accessibilityLabel={mode === 'composer' ? 'Clear draft' : 'New conversation'}
        />
      </View>

      <SegmentedControl<HelperMode>
        options={[
          { value: 'composer', label: 'Composer' },
          { value: 'chat', label: 'Chat' },
        ]}
        value={mode}
        onChange={persistMode}
        className="mx-5 mb-3"
      />

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={insets.top}
        className="flex-1"
      >
        {mode === 'composer' ? (
          <ComposerPane
            title={draftTitle}
            draft={draft}
            onChangeTitle={(value) => {
              setDraftTitle(value);
              persistDraft(value, draft);
            }}
            onChangeDraft={(value) => {
              setDraft(value);
              persistDraft(draftTitle, value);
            }}
            onUseStarter={(starter) => void applyToDraft(starter)}
            onClear={reset}
            busy={busy}
          />
        ) : (
          <FlatList
            ref={listRef}
            data={messages}
            keyExtractor={(m) => m.id}
            renderItem={({ item }) => <ChatBubble message={item} />}
            contentContainerClassName="px-5 pt-2 pb-4"
            onContentSizeChange={scrollToEnd}
            keyboardDismissMode="interactive"
            ListFooterComponent={
              showSuggestions ? (
                <View className="mt-8">
                  <Text variant="heading" className="mb-1">
                    Try asking
                  </Text>
                  {aiSuggestedPrompts.map((s, i) => (
                    <Pressable
                      key={s.label}
                      onPress={() => sendChat(s.label)}
                      className={cn(
                        'flex-row items-center gap-3 py-3.5 active:opacity-70',
                        i < aiSuggestedPrompts.length - 1 && 'border-b border-line dark:border-line-dark',
                      )}
                    >
                      <Text variant="body" className="flex-1">
                        {s.label}
                      </Text>
                      <Ionicons name="arrow-forward" size={15} color={colors.inkSubtle} />
                    </Pressable>
                  ))}
                  <Text variant="caption" tone="muted" className="mt-6">
                    Or photograph a textbook problem or handwritten equation — the helper reads it for you.
                  </Text>
                </View>
              ) : null
            }
          />
        )}

        <View style={{ paddingBottom: Math.max(insets.bottom - 8, 0) }} className="bg-canvas dark:bg-canvas-dark">
          <ChatComposer
            attachment={attachment}
            onRemoveAttachment={() => setAttachment(null)}
            onPickImage={() => attach(fromLibrary)}
            onTakePhoto={() => attach(fromCamera)}
            onSend={mode === 'composer' ? applyToDraft : sendChat}
            onStop={stop}
            busy={busy}
            scanning={scanning}
            placeholder={mode === 'composer' ? 'Tell the helper what to change…' : 'Ask anything…'}
          />
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}
