import { Ionicons } from '@expo/vector-icons';
import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Button, CampusPhoto, Input, SegmentedControl, Text } from '@/components/ui';
import { campusCaptions } from '@/constants/campus';
import { useAuth } from '@/hooks';
import type { RootStackScreenProps } from '@/navigation/types';

type Mode = 'signin' | 'signup';

export function AuthScreen({ navigation }: RootStackScreenProps<'Auth'>) {
  const insets = useSafeAreaInsets();
  const { signIn, signUp, continueAsGuest } = useAuth();
  const [mode, setMode] = useState<Mode>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    setError(null);
    setLoading(true);
    try {
      if (mode === 'signin') await signIn(email.trim(), password);
      else await signUp(email.trim(), password, name.trim());
      navigation.goBack();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} className="flex-1 bg-canvas dark:bg-canvas-dark">
      <ScrollView
        contentContainerStyle={{ paddingBottom: insets.bottom + 24 }}
        keyboardShouldPersistTaps="handled"
      >
        <CampusPhoto photo="princeton" height={260 + insets.top} dim={0.3} rounded={false} caption={false}>
          <View className="flex-1 justify-between px-6" style={{ paddingTop: insets.top + 8, paddingBottom: 20 }}>
            <Pressable
              onPress={() => navigation.goBack()}
              hitSlop={10}
              accessibilityLabel="Close"
              className="h-10 w-10 -ml-2 items-center justify-center rounded-full active:opacity-70"
            >
              <Ionicons name="close" size={20} color="#F4F0E8" />
            </Pressable>
            <View>
              <Text variant="caption" tone="inverseMuted">
                {campusCaptions.princeton}
              </Text>
              <Text variant="heading" tone="inverseMuted" className="mt-3">
                Viantis
              </Text>
              <Text variant="display" tone="inverse" className="mt-1">
                {mode === 'signin' ? 'Welcome back' : 'Join Viantis'}
              </Text>
            </View>
          </View>
        </CampusPhoto>

        <View className="px-6">
          <Text variant="body" tone="muted" className="mt-6">
            Sync your schedule, XP and community activity across devices.
          </Text>

          <SegmentedControl<Mode>
            options={[
              { value: 'signin', label: 'Sign in' },
              { value: 'signup', label: 'Create account' },
            ]}
            value={mode}
            onChange={setMode}
            className="mt-8"
          />

          <View className="mt-6 gap-4">
            {mode === 'signup' && <Input label="Display name" icon="person-outline" placeholder="Maya" value={name} onChangeText={setName} autoCapitalize="words" />}
            <Input label="Email" icon="mail-outline" placeholder="you@school.edu" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" autoComplete="email" />
            <Input label="Password" icon="lock-closed-outline" placeholder="••••••••" value={password} onChangeText={setPassword} secureTextEntry autoComplete={mode === 'signin' ? 'password' : 'new-password'} error={error ?? undefined} />
          </View>

          <Button
            label={mode === 'signin' ? 'Sign in' : 'Create account'}
            variant="ink"
            size="lg"
            fullWidth
            className="mt-6"
            onPress={submit}
            loading={loading}
            disabled={!email.trim() || password.length < 6 || (mode === 'signup' && !name.trim())}
          />

          <Button
            label="Continue as guest"
            variant="ghost"
            fullWidth
            className="mt-3"
            onPress={async () => {
              await continueAsGuest();
              navigation.goBack();
            }}
          />

          <Text variant="caption" tone="subtle" className="mt-8 text-center">
            By continuing you agree to the{' '}
            <Text
              variant="caption"
              tone="muted"
              onPress={() => navigation.navigate('Legal', { doc: 'terms' })}
              accessibilityRole="link"
            >
              Terms of use
            </Text>
            {' '}and{' '}
            <Text
              variant="caption"
              tone="muted"
              onPress={() => navigation.navigate('Legal', { doc: 'privacy' })}
              accessibilityRole="link"
            >
              Privacy policy
            </Text>
            , and you will follow the{' '}
            <Text
              variant="caption"
              tone="muted"
              onPress={() => navigation.navigate('Legal', { doc: 'community' })}
              accessibilityRole="link"
            >
              Community guidelines
            </Text>
            .
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
