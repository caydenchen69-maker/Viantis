import React from 'react';
import { View } from 'react-native';

import { Screen, Text } from '@/components/ui';
import { LEGAL_UPDATED, legalDocs, type LegalDocId } from '@/content/legal';
import type { RootStackScreenProps } from '@/navigation/types';

export function LegalDocumentScreen({ route }: RootStackScreenProps<'Legal'>) {
  const doc = legalDocs[route.params?.doc] ?? legalDocs.accessibility;

  return (
    <Screen safeTop={false} contentClassName="pt-2 pb-12">
      <Text variant="display" accessibilityRole="header" style={{ fontSize: 34, lineHeight: 38 }}>
        {doc.title}
      </Text>
      <Text variant="caption" tone="muted" className="mt-2">
        Last updated {doc.updated}
      </Text>
      <Text variant="body" className="mt-5">
        {doc.intro}
      </Text>

      {doc.sections.map((section) => (
        <View key={section.heading} className="mt-8">
          <Text variant="heading" accessibilityRole="header">
            {section.heading}
          </Text>
          {section.paragraphs.map((p) => (
            <Text key={p.slice(0, 48)} variant="body" className="mt-2">
              {p}
            </Text>
          ))}
          {section.bullets?.map((item) => (
            <View key={item} className="mt-2 flex-row gap-2 pr-2">
              <Text variant="body" style={{ lineHeight: 22 }}>
                •
              </Text>
              <Text variant="body" className="flex-1">
                {item}
              </Text>
            </View>
          ))}
        </View>
      ))}

      <Text variant="caption" tone="subtle" className="mt-10">
        These pages describe how this version of Viantis works as of {LEGAL_UPDATED}. They are product
        policies, not a substitute for advice from a lawyer or your school.
      </Text>
    </Screen>
  );
}

export const legalTitle = (doc: LegalDocId) => legalDocs[doc]?.title ?? 'Legal';
