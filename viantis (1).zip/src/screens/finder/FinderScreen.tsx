import { Ionicons } from '@expo/vector-icons';
import React, { useMemo, useState } from 'react';
import { Pressable, TextInput, View } from 'react-native';

import { BrandHeader, ChatFab } from '@/components/brand';
import { FilterSheet } from '@/components/finder/FilterSheet';
import { SchoolCard } from '@/components/finder/SchoolCard';
import { EmptyState, Screen, Skeleton, Text } from '@/components/ui';
import { palette } from '@/constants/theme';
import { fonts } from '@/constants/typography';
import { useAsync, useLocation } from '@/hooks';
import type { TabScreenProps } from '@/navigation/types';
import { defaultSchoolFilters, schoolsService } from '@/services';
import type { SchoolFilters } from '@/types';
import { schoolCompatibility } from '@/utils/schoolMeta';

const SAMPLE_QUERY =
  'I need a co-ed boarding school in California with an average SAT above 1400, high placement in Stanford, and an active robotics program.';

export function FinderScreen({ navigation }: TabScreenProps<'FinderTab'>) {
  const { coords, status: locationStatus, usingFallback, request } = useLocation();
  const [filters, setFilters] = useState<SchoolFilters>(defaultSchoolFilters);
  const [showFilters, setShowFilters] = useState(false);
  const [committed, setCommitted] = useState('');
  const [elapsed] = useState(() => (Math.random() * 0.08 + 0.03).toFixed(2));

  const filtersKey = JSON.stringify(filters);
  const { data: schools, loading } = useAsync(
    () => schoolsService.search(filters, coords),
    [filtersKey, coords?.latitude, coords?.longitude],
  );

  const results = useMemo(
    () => [...(schools ?? [])].sort((a, b) => schoolCompatibility(b) - schoolCompatibility(a)),
    [schools],
  );
  const quote = committed || filters.query.trim() || SAMPLE_QUERY;
  const synthesizing = Boolean(committed || filters.query.trim() || results.length);

  const submit = () => {
    const next = filters.query.trim() || SAMPLE_QUERY;
    setCommitted(next);
    if (!filters.query.trim()) setFilters((f) => ({ ...f, query: '' }));
  };

  const activeFilterCount = useMemo(
    () =>
      filters.types.length +
      filters.majors.length +
      (filters.maxAcceptanceRate !== null ? 1 : 0) +
      (filters.minRating !== null ? 1 : 0) +
      (filters.radiusKm !== defaultSchoolFilters.radiusKm ? 1 : 0),
    [filters],
  );

  return (
    <View className="flex-1" style={{ backgroundColor: palette.charcoal[900] }}>
      <BrandHeader />
      <Screen
        safeTop={false}
        className="bg-transparent"
        contentClassName="pb-28"
        style={{ backgroundColor: palette.charcoal[900] }}
      >
        <Text variant="overline" style={{ color: palette.coral[400], letterSpacing: 1.6, marginTop: 28 }}>
          Instant synthesis engine
        </Text>
        <Text
          variant="display"
          style={{
            color: '#F6F1E8',
            fontSize: 34,
            lineHeight: 38,
            letterSpacing: -0.4,
            marginTop: 12,
            textTransform: 'uppercase',
          }}
        >
          Describe your target school. Get instant paths.
        </Text>
        <Text variant="body" style={{ color: '#B8B3A8', marginTop: 14, lineHeight: 22 }}>
          {locationStatus === 'granted'
            ? 'Matches are ranked against your query and distance from you.'
            : usingFallback
              ? 'Indexed against 4,800+ institutions. Boston area used until location is on.'
              : 'Natural-language matching across the indexed institution set.'}
        </Text>
        {locationStatus !== 'granted' && locationStatus !== 'requesting' && (
          <Pressable onPress={request} hitSlop={6} className="mt-2 self-start active:opacity-70">
            <Text variant="overline" style={{ color: palette.coral[400] }}>
              Use my location
            </Text>
          </Pressable>
        )}

        <View
          className="mt-8 px-5 py-5"
          style={{
            backgroundColor: palette.charcoal[800],
            borderWidth: 1,
            borderColor: '#2A3532',
          }}
        >
          <Text variant="overline" style={{ color: '#7A766E', letterSpacing: 1.4 }}>
            User query input
          </Text>
          <Text
            italic
            style={{
              fontFamily: fonts.serifItalic,
              fontSize: 22,
              lineHeight: 28,
              color: '#F6F1E8',
              marginTop: 12,
            }}
          >
            “{quote}”
          </Text>
          <View className="mt-6 flex-row items-end justify-between">
            <Text style={{ fontFamily: fonts.sans.regular, fontSize: 11, color: palette.coral[400] }}>
              {synthesizing ? `Processing query... ${elapsed}s` : 'Awaiting query…'}
            </Text>
            <Pressable onPress={() => setShowFilters(true)} className="items-end active:opacity-70">
              <Text variant="overline" style={{ color: '#F6F1E8', letterSpacing: 1.3 }}>
                Customize query
              </Text>
              <Ionicons name="arrow-forward" size={14} color="#F6F1E8" style={{ marginTop: 4 }} />
            </Pressable>
          </View>
        </View>

        <View
          className="mt-4 px-4 py-3"
          style={{ backgroundColor: palette.charcoal[800], borderWidth: 1, borderColor: '#2A3532' }}
        >
          <TextInput
            value={filters.query}
            onChangeText={(query) => setFilters((f) => ({ ...f, query }))}
            placeholder="Type a brief, then synthesize"
            placeholderTextColor="#7A766E"
            returnKeyType="search"
            onSubmitEditing={submit}
            style={{
              fontFamily: fonts.serifItalic,
              fontSize: 16,
              lineHeight: 22,
              color: '#F6F1E8',
              padding: 0,
              caretColor: '#F6F1E8',
              WebkitTextFillColor: '#F6F1E8',
            } as never}
          />
        </View>

        <View className="mt-10 mb-4 flex-row items-center justify-between">
          <Text variant="overline" style={{ color: '#8A8780', letterSpacing: 1.6 }}>
            Synthesized matches ({loading ? '—' : results.length})
          </Text>
          {activeFilterCount > 0 && (
            <Pressable onPress={() => setShowFilters(true)} className="active:opacity-70">
              <Text variant="overline" style={{ color: palette.coral[400] }}>
                {activeFilterCount} filters
              </Text>
            </Pressable>
          )}
        </View>

        <View className="gap-4">
          {loading && !schools ? (
            Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} height={188} rounded={8} />)
          ) : results.length === 0 ? (
            <EmptyState
              icon="school-outline"
              title="No institutions matched"
              description="Widen distance or clear a constraint."
              actionLabel="Clear filters"
              onAction={() => {
                setFilters({ ...defaultSchoolFilters, query: '' });
                setCommitted('');
              }}
            />
          ) : (
            results.map((s) => (
              <SchoolCard
                key={s.id}
                school={s}
                onPress={(school) => navigation.navigate('SchoolDetail', { schoolId: school.id })}
              />
            ))
          )}
        </View>
      </Screen>
      <ChatFab prompt={quote} />
      <FilterSheet
        visible={showFilters}
        filters={filters}
        onChange={setFilters}
        onClose={() => setShowFilters(false)}
        resultCount={results.length}
      />
    </View>
  );
}
