import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Linking, View } from 'react-native';

import { schoolTypeLabel } from '@/components/finder/SchoolCard';
import { SchoolMap } from '@/components/finder/SchoolMap';
import { Avatar, Button, CampusPhoto, Card, Screen, SectionHeader, Skeleton, Text } from '@/components/ui';
import { campusCaptions, photoForSchool } from '@/constants/campus';
import { useAsync } from '@/hooks';
import type { RootStackScreenProps } from '@/navigation/types';
import { useTheme } from '@/providers/ThemeProvider';
import { schoolsService } from '@/services';
import { timeAgo } from '@/utils/date';
import { formatCompact, formatPercent } from '@/utils/format';

export function SchoolDetailScreen({ route, navigation }: RootStackScreenProps<'SchoolDetail'>) {
  const { schoolId } = route.params;
  const { colors } = useTheme();
  const { data: school } = useAsync(() => schoolsService.getById(schoolId), [schoolId]);
  const { data: reviews } = useAsync(() => schoolsService.listReviews(schoolId), [schoolId]);

  if (!school) {
    return (
      <Screen safeTop={false} contentClassName="pt-3">
        <Skeleton height={28} width="70%" />
        <Skeleton height={16} width="40%" className="mt-2" />
        <Skeleton height={220} rounded={20} className="mt-5" />
      </Screen>
    );
  }

  return (
    <Screen safeTop={false} contentClassName="pt-2">
      <CampusPhoto photo={photoForSchool(school.id)} height={200} dim={0.2} className="mb-5">
        <View className="flex-1 justify-end p-4">
          <Text variant="caption" tone="inverseMuted">
            {campusCaptions[photoForSchool(school.id)]}
          </Text>
        </View>
      </CampusPhoto>
      <Text variant="overline" tone="primary" className="mb-2" style={{ letterSpacing: 1.3 }}>
        Institution ID: {school.institutionId ?? school.region}
      </Text>
      <Text variant="caption" tone="muted" className="mb-2">
        {schoolTypeLabel[school.type]} · {school.city}, {school.region}
      </Text>
      <Text variant="display" style={{ fontSize: 34, lineHeight: 38 }}>
        {school.name}
      </Text>
      <View className="mt-2 flex-row items-center gap-1.5">
        <Ionicons name="star" size={13} color={colors.ink} />
        <Text variant="label">{school.rating.toFixed(1)}</Text>
        <Text variant="caption" tone="muted">
          · {formatCompact(school.reviewCount)} reviews
        </Text>
      </View>

      <View className="mt-6 flex-row border-y border-line py-4 dark:border-line-dark">
        <Stat label="Avg SAT" value={school.satAverage != null ? String(school.satAverage) : '—'} />
        <Stat label="Acceptance" value={formatPercent(school.acceptanceRate, 1)} divider />
        <Stat label="Students" value={formatCompact(school.studentCount)} divider />
      </View>

      <View className="mt-5">
        <SchoolMap schools={[school]} origin={null} onSelect={() => {}} height={180} />
      </View>

      <SectionHeader title="Highlights" className="mt-8" />
      <View className="gap-2.5">
        {school.highlights.map((h) => (
          <View key={h} className="flex-row items-start gap-3">
            <View className="mt-2.5 h-1 w-1 rounded-full bg-primary-600 dark:bg-primary-500" />
            <Text variant="body" className="flex-1">
              {h}
            </Text>
          </View>
        ))}
      </View>

      <SectionHeader title="Majors & programs" className="mt-8" />
      <View className="flex-row flex-wrap gap-2">
        {school.majors.map((m) => (
          <View key={m} className="rounded-full border border-line px-3 py-1.5 dark:border-line-dark">
            <Text variant="caption">{m}</Text>
          </View>
        ))}
      </View>

      <SectionHeader
        title="Student reviews"
        subtitle={reviews ? `${reviews.length} on Viantis` : undefined}
        actionLabel="Write one"
        onAction={() => navigation.navigate('CreatePost')}
        className="mt-8"
      />
      <View className="gap-3">
        {reviews?.length ? (
          reviews.map((r) => (
            <Card key={r.id} padding="lg">
              <View className="flex-row items-center gap-2.5">
                <Avatar avatar={r.author.avatar} name={r.author.displayName} size={28} />
                <Text variant="caption" tone="muted" className="flex-1">
                  <Text variant="caption" weight="medium">
                    {r.author.displayName}
                  </Text>
                  {' · '}
                  {timeAgo(r.createdAt)}
                </Text>
                <View className="flex-row gap-0.5">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Ionicons key={i} name={i < r.rating ? 'star' : 'star-outline'} size={12} color={colors.ink} />
                  ))}
                </View>
              </View>
              <Text variant="heading" className="mt-3" style={{ fontSize: 20, lineHeight: 24 }}>
                {r.title}
              </Text>
              <Text variant="body" tone="muted" className="mt-1">
                {r.body}
              </Text>
              <View className="mt-3 flex-row items-center gap-1.5">
                <Ionicons name="thumbs-up-outline" size={14} color={colors.inkMuted} />
                <Text variant="caption" tone="muted">
                  {r.helpfulCount} found this helpful
                </Text>
              </View>
            </Card>
          ))
        ) : (
          <Card>
            <Text variant="body" tone="muted">
              No reviews yet. Be the first to share your experience.
            </Text>
          </Card>
        )}
      </View>

      {school.website && (
        <Button label="Visit website" variant="outline" icon="open-outline" className="mt-8" onPress={() => Linking.openURL(school.website!)} />
      )}
      <Button
        label="Ask the Helper about this school"
        variant="ink"
        className="mt-3"
        onPress={() =>
          navigation.navigate('Tabs', {
            screen: 'AIHelperTab',
            params: { prompt: `What should I know about applying to ${school.name}?` },
          })
        }
      />
    </Screen>
  );
}

function Stat({ label, value, divider = false }: { label: string; value: string; divider?: boolean }) {
  return (
    <View className={divider ? 'flex-1 border-l border-line pl-4 dark:border-line-dark' : 'flex-1'}>
      <Text variant="heading" style={{ fontSize: 24, lineHeight: 28 }}>
        {value}
      </Text>
      <Text variant="caption" tone="muted" className="mt-0.5">
        {label}
      </Text>
    </View>
  );
}
