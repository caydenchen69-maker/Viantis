import type { Session } from '@supabase/supabase-js';
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

import { levelForXP } from '@/constants/config';
import { authService } from '@/services';
import type { UserProfile } from '@/types';

interface AuthContextValue {
  session: Session | null;
  profile: UserProfile | null;
  /** True while restoring the persisted session on launch. */
  loading: boolean;
  /** True when running without Supabase or before sign-in. */
  isGuest: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, displayName: string) => Promise<void>;
  signOut: () => Promise<void>;
  continueAsGuest: () => Promise<void>;
  /** Local-first XP update; persisted to Supabase when live. */
  addXP: (amount: number) => void;
  updateProfile: (patch: Partial<UserProfile>) => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [guest, setGuest] = useState(false);

  useEffect(() => {
    let cancelled = false;

    const bootstrap = async () => {
      if (!authService.isLive) {
        // No backend configured: restore the local guest (empty on first visit).
        const guestProfile = await authService.loadGuestProfile();
        if (!cancelled) {
          setProfile(guestProfile);
          setGuest(true);
          setLoading(false);
        }
        return;
      }
      const existing = await authService.getSession();
      if (cancelled) return;
      setSession(existing);
      if (existing?.user) setProfile(await authService.fetchProfile(existing.user));
      setLoading(false);
    };

    bootstrap().catch(() => setLoading(false));

    const unsubscribe = authService.onAuthStateChange(async (next) => {
      setSession(next);
      if (next?.user) {
        setProfile(await authService.fetchProfile(next.user));
        setGuest(false);
      } else if (!guest) {
        setProfile(null);
      }
    });

    return () => {
      cancelled = true;
      unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const signIn = useCallback(async (email: string, password: string) => {
    await authService.signInWithEmail(email, password);
  }, []);

  const signUp = useCallback(async (email: string, password: string, displayName: string) => {
    await authService.signUpWithEmail(email, password, displayName);
  }, []);

  const signOut = useCallback(async () => {
    await authService.signOut();
    setSession(null);
    setProfile(null);
    setGuest(false);
  }, []);

  const continueAsGuest = useCallback(async () => {
    setProfile(await authService.loadGuestProfile());
    setGuest(true);
  }, []);

  const updateProfile = useCallback(
    (patch: Partial<UserProfile>) => {
      setProfile((prev) => {
        if (!prev) return prev;
        const next = { ...prev, ...patch };
        authService.persistProfile(next, session?.user.id).catch(() => {
          if (guest) authService.saveGuestProfile(next).catch(() => {});
        });
        return next;
      });
    },
    [guest, session?.user.id],
  );

  const addXP = useCallback(
    (amount: number) => {
      setProfile((prev) => {
        if (!prev) return prev;
        const xp = prev.xp + amount;
        const next = { ...prev, xp, level: levelForXP(xp) };
        if (guest) authService.saveGuestProfile(next).catch(() => {});
        return next;
      });
    },
    [guest],
  );

  const value = useMemo<AuthContextValue>(
    () => ({
      session,
      profile,
      loading,
      isGuest: guest || !session,
      signIn,
      signUp,
      signOut,
      continueAsGuest,
      addXP,
      updateProfile,
    }),
    [session, profile, loading, guest, signIn, signUp, signOut, continueAsGuest, addXP, updateProfile],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
