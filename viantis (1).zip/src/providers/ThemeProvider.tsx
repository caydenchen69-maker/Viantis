import AsyncStorage from '@react-native-async-storage/async-storage';
import { colorScheme as nwColorScheme, useColorScheme as useNWColorScheme } from 'nativewind';
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { Appearance } from 'react-native';

import { STORAGE_KEYS } from '@/constants/config';
import { darkColors, lightColors, type ThemeColors } from '@/constants/theme';

export type ThemePreference = 'light' | 'dark' | 'system';

interface ThemeContextValue {
  preference: ThemePreference;
  /** Resolved scheme after applying `system`. */
  scheme: 'light' | 'dark';
  isDark: boolean;
  colors: ThemeColors;
  setPreference: (pref: ThemePreference) => void;
  toggle: () => void;
  ready: boolean;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [preference, setPreferenceState] = useState<ThemePreference>('system');
  const [ready, setReady] = useState(false);
  const { colorScheme } = useNWColorScheme();

  useEffect(() => {
    let settled = false;
    const finish = () => {
      if (settled) return;
      settled = true;
      setReady(true);
    };

    const timeout = setTimeout(finish, 1500);
    AsyncStorage.getItem(STORAGE_KEYS.themePreference)
      .then((stored) => {
        const pref = (stored as ThemePreference | null) ?? 'system';
        setPreferenceState(pref);
        nwColorScheme.set(pref);
      })
      .catch(() => {})
      .finally(() => {
        clearTimeout(timeout);
        finish();
      });

    return () => clearTimeout(timeout);
  }, []);

  const setPreference = useCallback((pref: ThemePreference) => {
    setPreferenceState(pref);
    nwColorScheme.set(pref);
    AsyncStorage.setItem(STORAGE_KEYS.themePreference, pref).catch(() => {});
  }, []);

  const systemScheme = colorScheme ?? Appearance.getColorScheme();
  const scheme: 'light' | 'dark' =
    preference === 'system' ? (systemScheme === 'dark' ? 'dark' : 'light') : preference;

  const toggle = useCallback(() => {
    setPreference(scheme === 'dark' ? 'light' : 'dark');
  }, [scheme, setPreference]);

  const value = useMemo<ThemeContextValue>(
    () => ({
      preference,
      scheme,
      isDark: scheme === 'dark',
      colors: scheme === 'dark' ? darkColors : lightColors,
      setPreference,
      toggle,
      ready,
    }),
    [preference, scheme, setPreference, toggle, ready],
  );

  useEffect(() => {
    if (typeof document === 'undefined') return;
    document.documentElement.classList.toggle('dark', scheme === 'dark');
  }, [scheme]);

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export const useTheme = () => {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
};
