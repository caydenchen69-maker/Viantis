// Shared domain models used across screens, services and mock data.

export type ID = string;

export interface UserProfile {
  id: ID;
  username: string;
  displayName: string;
  avatar: AvatarConfig;
  xp: number;
  level: number;
  streakDays: number;
  longestStreak: number;
  school?: string;
  gradeLevel?: string;
  joinedAt: string;
}

export interface AvatarConfig {
  /** Tinted disc colour behind the monogram. */
  background: string;
  /** Monogram colour; defaults to ink. */
  foreground?: string;
  frame?: 'none' | 'bronze' | 'silver' | 'gold';
}

// ---------- Schedule ----------

export type TaskPriority = 'low' | 'medium' | 'high';
export type TaskStatus = 'todo' | 'in_progress' | 'done';

export interface Subject {
  id: ID;
  name: string;
  color: string;
  icon: string;
}

export interface StudyTask {
  id: ID;
  title: string;
  subjectId: ID;
  dueAt: string;
  estimatedMinutes: number;
  completedMinutes: number;
  priority: TaskPriority;
  status: TaskStatus;
  notes?: string;
}

export interface StudySession {
  id: ID;
  taskId?: ID;
  startedAt: string;
  durationMinutes: number;
  kind: 'focus' | 'break';
}

export interface PomodoroSettings {
  focusMinutes: number;
  shortBreakMinutes: number;
  longBreakMinutes: number;
  roundsBeforeLongBreak: number;
  autoStartBreaks: boolean;
  soundEnabled: boolean;
  ambientSound: AmbientSoundId | null;
}

export type AmbientSoundId = 'rain' | 'cafe' | 'forest' | 'white_noise' | 'lofi';

export interface AmbientSound {
  id: AmbientSoundId;
  label: string;
  icon: string;
}

// ---------- Arcade ----------

export type GameId = 'space_shooter' | 'flashcard_match' | 'trivia_tower';

export interface ArcadeGame {
  id: GameId;
  title: string;
  tagline: string;
  description: string;
  icon: string;
  tint: 'indigo' | 'amber' | 'mint' | 'rose' | 'sky';
  bestScore: number;
  xpPerRound: number;
  durationLabel: string;
}

export interface Flashcard {
  id: ID;
  deckId: ID;
  front: string;
  back: string;
}

export interface Deck {
  id: ID;
  title: string;
  subjectId: ID;
  cardCount: number;
  lastStudied?: string;
  /** True for decks the user created. Sample decks stay read-only. */
  custom?: boolean;
  /** Marked shared so a share code can be copied. No backend. */
  shared?: boolean;
  /** Display name of the person who published it. */
  authorName?: string;
  /** Original shared-deck id when this is a personal copy. */
  sourceId?: string;
  sharedAt?: string;
}

export interface QuizQuestion {
  id: ID;
  prompt: string;
  choices: string[];
  answerIndex: number;
  explanation?: string;
}

export interface LeaderboardEntry {
  rank: number;
  user: Pick<UserProfile, 'id' | 'username' | 'displayName' | 'avatar' | 'level'>;
  xp: number;
  isCurrentUser?: boolean;
  isFriend?: boolean;
}

export interface XPEvent {
  id: ID;
  amount: number;
  reason: string;
  createdAt: string;
}

// ---------- AI Helper ----------

export type ChatRole = 'user' | 'assistant' | 'system';

export interface ChatAttachment {
  id: ID;
  uri: string;
  width?: number;
  height?: number;
  ocrText?: string;
}

export interface ChatMessage {
  id: ID;
  role: ChatRole;
  content: string;
  createdAt: string;
  attachments?: ChatAttachment[];
  status?: 'sending' | 'streaming' | 'complete' | 'error';
}

export interface ChatThread {
  id: ID;
  title: string;
  messages: ChatMessage[];
  updatedAt: string;
}

// ---------- School Finder ----------

export type SchoolType = 'high_school' | 'university' | 'community_college';

export interface School {
  id: ID;
  name: string;
  type: SchoolType;
  city: string;
  region: string;
  country: string;
  coordinates: { latitude: number; longitude: number };
  distanceKm?: number;
  acceptanceRate: number | null;
  rating: number;
  reviewCount: number;
  studentCount: number;
  tuitionPerYear: number | null;
  majors: string[];
  highlights: string[];
  imageUrl?: string;
  website?: string;
  /** Dossier-style identifier, e.g. CA-94025. */
  institutionId?: string;
  /** Mid-50 SAT composite when published. */
  satAverage?: number | null;
}

export interface SchoolReview {
  id: ID;
  schoolId: ID;
  author: Pick<UserProfile, 'id' | 'displayName' | 'avatar'>;
  rating: number;
  title: string;
  body: string;
  createdAt: string;
  helpfulCount: number;
}

export interface SchoolFilters {
  query: string;
  types: SchoolType[];
  majors: string[];
  maxAcceptanceRate: number | null;
  minRating: number | null;
  radiusKm: number;
}

// ---------- Community ----------

export type PostKind = 'discussion' | 'tip' | 'review' | 'question';

export interface Post {
  id: ID;
  kind: PostKind;
  title: string;
  body: string;
  author: Pick<UserProfile, 'id' | 'username' | 'displayName' | 'avatar' | 'level'>;
  tags: string[];
  upvotes: number;
  commentCount: number;
  createdAt: string;
  userVote: 1 | -1 | 0;
  isPinned?: boolean;
  isFlagged?: boolean;
  schoolId?: ID;
}

export interface Comment {
  id: ID;
  postId: ID;
  parentId?: ID;
  author: Pick<UserProfile, 'id' | 'username' | 'displayName' | 'avatar'>;
  body: string;
  upvotes: number;
  createdAt: string;
  userVote: 1 | -1 | 0;
  isRemoved?: boolean;
  replies?: Comment[];
}

export interface Tag {
  id: ID;
  label: string;
  postCount: number;
  color: string;
}

export interface ChatRoomMessage {
  id: ID;
  roomId: ID;
  authorId: ID;
  authorName: string;
  body: string;
  createdAt: string;
}
