declare module '*.css';
declare module '*.wav' {
  const source: number;
  export default source;
}
declare module '*.jpg' {
  const source: number;
  export default source;
}
declare module '*.png' {
  const source: number;
  export default source;
}
