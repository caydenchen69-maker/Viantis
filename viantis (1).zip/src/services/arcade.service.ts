import AsyncStorage from '@react-native-async-storage/async-storage';

import { STORAGE_KEYS, XP_RULES } from '@/constants/config';
import {
  catalogSharedCards,
  catalogSharedDecks,
  mockDecks,
  mockFlashcards,
  mockFriendsLeaderboard,
  mockGames,
  mockGlobalLeaderboard,
  mockQuizQuestions,
} from '@/data';
import type { ArcadeGame, Deck, Flashcard, GameId, LeaderboardEntry, QuizQuestion } from '@/types';
import { uid } from '@/utils/format';

import { supabase, TABLES } from './supabase';

export type LeaderboardScope = 'global' | 'friends';

interface UserStore {
  decks: Deck[];
  cards: Flashcard[];
}

const emptyStore = (): UserStore => ({ decks: [], cards: [] });

let cache: UserStore | null = null;
let sharedCache: UserStore | null = null;

const loadStore = async (): Promise<UserStore> => {
  if (cache) return cache;
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEYS.userDecks);
    if (raw) {
      const parsed = JSON.parse(raw) as UserStore;
      cache = { decks: parsed.decks ?? [], cards: parsed.cards ?? [] };
    } else {
      cache = emptyStore();
    }
  } catch {
    cache = emptyStore();
  }
  return cache;
};

const saveStore = async (store: UserStore) => {
  cache = store;
  await AsyncStorage.setItem(STORAGE_KEYS.userDecks, JSON.stringify(store));
};

const loadSharedStore = async (): Promise<UserStore> => {
  if (sharedCache) return sharedCache;
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEYS.sharedLibrary);
    if (raw) {
      const parsed = JSON.parse(raw) as UserStore;
      sharedCache = { decks: parsed.decks ?? [], cards: parsed.cards ?? [] };
    } else {
      sharedCache = emptyStore();
    }
  } catch {
    sharedCache = emptyStore();
  }
  return sharedCache;
};

const saveSharedStore = async (store: UserStore) => {
  sharedCache = store;
  await AsyncStorage.setItem(STORAGE_KEYS.sharedLibrary, JSON.stringify(store));
};

const withCount = (deck: Deck, cards: Flashcard[]): Deck => ({
  ...deck,
  cardCount: cards.filter((c) => c.deckId === deck.id).length,
});

const shuffle = <T>(list: T[]) => {
  const out = [...list];
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [out[i], out[j]] = [out[j]!, out[i]!];
  }
  return out;
};

export const arcadeService = {
  async listGames(): Promise<ArcadeGame[]> {
    return mockGames;
  },

  async listDecks(): Promise<Deck[]> {
    const store = await loadStore();
    const custom = store.decks.map((d) => withCount({ ...d, custom: true }, store.cards));
    const samples = mockDecks.map((d) => withCount({ ...d, custom: false }, mockFlashcards));
    return [...custom, ...samples];
  },

  async getDeck(deckId: string): Promise<Deck | undefined> {
    const decks = await this.listDecks();
    const local = decks.find((d) => d.id === deckId);
    if (local) return local;
    return (await this.listSharedDecks()).find((d) => d.id === deckId);
  },

  async listFlashcards(deckId: string): Promise<Flashcard[]> {
    const store = await loadStore();
    if (store.decks.some((d) => d.id === deckId)) {
      return store.cards.filter((c) => c.deckId === deckId);
    }
    const shared = await loadSharedStore();
    if (shared.decks.some((d) => d.id === deckId)) {
      return shared.cards.filter((c) => c.deckId === deckId);
    }
    const catalog = catalogSharedCards.filter((c) => c.deckId === deckId);
    if (catalog.length) return catalog;
    return mockFlashcards.filter((c) => c.deckId === deckId);
  },

  async createDeck(input: { title: string; subjectId: string }): Promise<Deck> {
    const store = await loadStore();
    const deck: Deck = {
      id: uid('d'),
      title: input.title.trim() || 'Untitled deck',
      subjectId: input.subjectId,
      cardCount: 0,
      custom: true,
    };
    await saveStore({ ...store, decks: [deck, ...store.decks] });
    return deck;
  },

  async listSharedDecks(): Promise<Deck[]> {
    const published = await loadSharedStore();
    const community = published.decks.map((d) => withCount({ ...d, shared: true }, published.cards));
    return [...catalogSharedDecks, ...community];
  },

  /** Keep the community copy in sync after the owner edits a published deck. */
  async syncPublishedIfShared(deckId: string): Promise<void> {
    const store = await loadStore();
    const deck = store.decks.find((d) => d.id === deckId);
    if (!deck?.shared) return;
    const cards = store.cards.filter((c) => c.deckId === deckId);
    if (cards.length < 2) return;
    const shared = await loadSharedStore();
    const published: Deck = {
      ...deck,
      shared: true,
      sharedAt: deck.sharedAt ?? new Date().toISOString(),
      authorName: deck.authorName?.trim() || 'A student',
      cardCount: cards.length,
    };
    await saveSharedStore({
      decks: [published, ...shared.decks.filter((d) => d.id !== deckId)],
      cards: [...shared.cards.filter((c) => c.deckId !== deckId), ...cards],
    });
  },

  async publishDeck(deckId: string, authorName?: string): Promise<Deck | null> {
    const store = await loadStore();
    const deck = store.decks.find((d) => d.id === deckId);
    if (!deck) return null;
    const cards = store.cards.filter((c) => c.deckId === deckId);
    if (cards.length < 2) return null;

    const published: Deck = {
      ...deck,
      shared: true,
      sharedAt: new Date().toISOString(),
      authorName: authorName?.trim() || 'A student',
      cardCount: cards.length,
    };
    const nextUser = {
      ...store,
      decks: store.decks.map((d) => (d.id === deckId ? { ...d, shared: true, sharedAt: published.sharedAt, authorName: published.authorName } : d)),
    };
    await saveStore(nextUser);

    const shared = await loadSharedStore();
    await saveSharedStore({
      decks: [published, ...shared.decks.filter((d) => d.id !== deckId)],
      cards: [...shared.cards.filter((c) => c.deckId !== deckId), ...cards],
    });
    return published;
  },

  async unpublishDeck(deckId: string): Promise<Deck | null> {
    const store = await loadStore();
    const current = store.decks.find((d) => d.id === deckId);
    const shared = await loadSharedStore();
    await saveSharedStore({
      decks: shared.decks.filter((d) => d.id !== deckId),
      cards: shared.cards.filter((c) => c.deckId !== deckId),
    });
    if (!current) return null;
    const next: Deck = { ...current, shared: false, sharedAt: undefined };
    await saveStore({
      ...store,
      decks: store.decks.map((d) => (d.id === deckId ? next : d)),
    });
    return withCount(next, store.cards);
  },

  async addSharedToLibrary(sharedDeckId: string): Promise<Deck | null> {
    const store = await loadStore();
    const already = store.decks.find((d) => d.sourceId === sharedDeckId || d.id === sharedDeckId);
    if (already) return withCount(already, store.cards);

    const cards = await this.listFlashcards(sharedDeckId);
    const sharedDecks = await this.listSharedDecks();
    const source = sharedDecks.find((d) => d.id === sharedDeckId);
    if (!source || cards.length < 2) return null;

    const deckId = uid('d');
    const copy: Deck = {
      id: deckId,
      title: source.title,
      subjectId: source.subjectId,
      cardCount: cards.length,
      custom: true,
      sourceId: source.id,
      authorName: source.authorName,
    };
    const copiedCards: Flashcard[] = cards.map((c) => ({
      id: uid('f'),
      deckId,
      front: c.front,
      back: c.back,
    }));
    await saveStore({
      decks: [copy, ...store.decks],
      cards: [...store.cards, ...copiedCards],
    });
    return copy;
  },

  isShareCode(value: string): boolean {
    return /^VNT1\./i.test(value.trim());
  },

  encodeShareCode(deck: Deck, cards: Flashcard[]): string {
    const payload = {
      v: 1,
      t: deck.title,
      s: deck.subjectId,
      a: deck.authorName ?? '',
      c: cards.map((c) => [c.front, c.back] as [string, string]),
    };
    const json = JSON.stringify(payload);
    const b64 = btoa(unescape(encodeURIComponent(json)));
    return `VNT1.${b64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '')}`;
  },

  async importShareCode(code: string): Promise<Deck | null> {
    const trimmed = code.trim();
    const match = trimmed.match(/^VNT1\.(.+)$/i);
    if (!match?.[1]) return null;
    try {
      const b64 = match[1]
        .replace(/-/g, '+')
        .replace(/_/g, '/');
      const padded = b64 + '='.repeat((4 - (b64.length % 4)) % 4);
      const json = decodeURIComponent(escape(atob(padded)));
      const payload = JSON.parse(json) as { t?: string; s?: string; a?: string; c?: [string, string][] };
      const pairs = (payload.c ?? []).filter((p) => p[0]?.trim() && p[1]?.trim());
      if (pairs.length < 2) return null;
      const store = await loadStore();
      const deckId = uid('d');
      const deck: Deck = {
        id: deckId,
        title: payload.t?.trim() || 'Imported deck',
        subjectId: payload.s || 's_lang',
        cardCount: pairs.length,
        custom: true,
        authorName: payload.a || undefined,
      };
      const cards: Flashcard[] = pairs.map(([front, back]) => ({
        id: uid('f'),
        deckId,
        front: front.trim(),
        back: back.trim(),
      }));
      await saveStore({ decks: [deck, ...store.decks], cards: [...store.cards, ...cards] });
      return deck;
    } catch {
      return null;
    }
  },

  async updateDeck(deckId: string, patch: Partial<Pick<Deck, 'title' | 'subjectId' | 'lastStudied' | 'shared' | 'authorName' | 'sharedAt'>>): Promise<Deck | null> {
    const store = await loadStore();
    const current = store.decks.find((d) => d.id === deckId);
    if (!current) return null;
    const next: Deck = {
      ...current,
      ...patch,
      title: patch.title !== undefined ? patch.title.trim() || current.title : current.title,
      custom: true,
    };
    await saveStore({
      ...store,
      decks: store.decks.map((d) => (d.id === deckId ? next : d)),
    });
    await this.syncPublishedIfShared(deckId);
    return withCount(next, store.cards);
  },

  async deleteDeck(deckId: string): Promise<void> {
    const store = await loadStore();
    await saveStore({
      decks: store.decks.filter((d) => d.id !== deckId),
      cards: store.cards.filter((c) => c.deckId !== deckId),
    });
    await this.unpublishDeck(deckId);
  },

  async addCard(
    deckId: string,
    input: { front: string; back: string; title?: string; subjectId?: string },
  ): Promise<Flashcard> {
    const store = await loadStore();
    let decks = store.decks;
    if (!decks.some((d) => d.id === deckId)) {
      decks = [
        {
          id: deckId,
          title: input.title?.trim() || 'Untitled deck',
          subjectId: input.subjectId || 's_eng',
          cardCount: 0,
          custom: true,
        },
        ...decks,
      ];
    }
    const card: Flashcard = {
      id: uid('f'),
      deckId,
      front: input.front.trim(),
      back: input.back.trim(),
    };
    await saveStore({ decks, cards: [...store.cards, card] });
    await this.syncPublishedIfShared(deckId);
    return card;
  },

  async updateCard(card: Flashcard): Promise<Flashcard | null> {
    const store = await loadStore();
    if (!store.cards.some((c) => c.id === card.id)) return null;
    const next: Flashcard = { ...card, front: card.front.trim(), back: card.back.trim() };
    await saveStore({
      ...store,
      cards: store.cards.map((c) => (c.id === card.id ? next : c)),
    });
    await this.syncPublishedIfShared(card.deckId);
    return next;
  },

  async deleteCard(cardId: string): Promise<void> {
    const store = await loadStore();
    const card = store.cards.find((c) => c.id === cardId);
    await saveStore({ ...store, cards: store.cards.filter((c) => c.id !== cardId) });
    if (card) await this.syncPublishedIfShared(card.deckId);
  },

  async markStudied(deckId: string): Promise<void> {
    await this.updateDeck(deckId, { lastStudied: new Date().toISOString() });
  },

  /**
   * Builds a quiz round. Flashcards are turned into multiple-choice questions by
   * using other cards' backs as distractors; curated questions fill the rest.
   */
  async buildRound(opts: { deckId?: string; count?: number } = {}): Promise<QuizQuestion[]> {
    const { deckId, count = 8 } = opts;
    const cards = deckId
      ? await this.listFlashcards(deckId)
      : (await Promise.all((await this.listDecks()).map((d) => this.listFlashcards(d.id)))).flat();
    const fromCards: QuizQuestion[] = shuffle(cards).map((card) => {
      const others = cards.filter((c) => c.id !== card.id);
      const distractors = shuffle(others)
        .slice(0, 3)
        .map((c) => c.back);
      while (distractors.length < 3) distractors.push('—');
      const choices = shuffle([card.back, ...distractors.slice(0, 3)]);
      return {
        id: `fc_${card.id}`,
        prompt: card.front,
        choices,
        answerIndex: Math.max(0, choices.indexOf(card.back)),
      };
    });
    const pool = deckId ? fromCards : shuffle([...fromCards, ...mockQuizQuestions]);
    return pool.slice(0, count);
  },

  async leaderboard(scope: LeaderboardScope): Promise<LeaderboardEntry[]> {
    if (supabase) {
      const { data, error } = await supabase
        .from(TABLES.profiles)
        .select('id, username, display_name, avatar, level, xp')
        .order('xp', { ascending: false })
        .limit(50);
      if (error) throw error;

      return data.map((row: any, i: number) => ({
        rank: i + 1,
        xp: row.xp,
        user: {
          id: row.id,
          username: row.username,
          displayName: row.display_name,
          avatar: row.avatar,
          level: row.level,
        },
      }));
    }
    return scope === 'global' ? mockGlobalLeaderboard : mockFriendsLeaderboard;
  },

  /** XP awarded for a round: base + accuracy bonus. */
  scoreRound(gameId: GameId, correct: number, total: number) {
    const game = mockGames.find((g) => g.id === gameId);
    const base = game?.xpPerRound ?? XP_RULES.gameRound;
    const accuracy = total === 0 ? 0 : correct / total;
    const bonus = accuracy === 1 ? 10 : Math.round(accuracy * 6);
    return base + bonus;
  },

  async recordXP(userId: string | undefined, amount: number, reason: string) {
    if (supabase && userId) {
      await supabase.from(TABLES.xpEvents).insert({ user_id: userId, amount, reason });
      await supabase.rpc('increment_xp', { user_id: userId, amount });
    }
  },
};
