/** Production stub. Metro swaps this in for ai.live so no gateway origin ships. */
export async function askLive(): Promise<string> {
  throw new Error('unavailable');
}

export async function extractLive(): Promise<string> {
  throw new Error('unavailable');
}
