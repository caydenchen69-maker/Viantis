import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Session, User } from '@supabase/supabase-js';

import { STORAGE_KEYS } from '@/constants/config';
import { freshGuestProfile, isSeededDemoProfile, mockUser } from '@/data';
import type { UserProfile } from '@/types';

import { supabase, TABLES } from './supabase';

export type AuthListener = (session: Session | null) => void;

/**
 * Thin wrapper over Supabase Auth. When Supabase is not configured the app
 * runs in guest mode with a locally persisted profile. First visit starts
 * empty; later visits restore whatever the person saved.
 */
export const authService = {
  isLive: Boolean(supabase),

  async getSession(): Promise<Session | null> {
    if (!supabase) return null;
    const { data } = await supabase.auth.getSession();
    return data.session;
  },

  onAuthStateChange(listener: AuthListener) {
    if (!supabase) return () => {};
    const { data } = supabase.auth.onAuthStateChange((_event, session) => listener(session));
    return () => data.subscription.unsubscribe();
  },

  async signInWithEmail(email: string, password: string) {
    if (!supabase) throw new Error('Supabase not configured');
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return data.session;
  },

  async signUpWithEmail(email: string, password: string, displayName: string) {
    if (!supabase) throw new Error('Supabase not configured');
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { display_name: displayName } },
    });
    if (error) throw error;
    return data.session;
  },

  async sendMagicLink(email: string) {
    if (!supabase) throw new Error('Supabase not configured');
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: 'viantis://auth/callback' },
    });
    if (error) throw error;
  },

  async signOut() {
    if (supabase) await supabase.auth.signOut();
  },

  /** Loads the `profiles` row for a user, creating it on first login. */
  async fetchProfile(user: User): Promise<UserProfile> {
    if (!supabase) return mockUser;
    const { data, error } = await supabase
      .from(TABLES.profiles)
      .select('*')
      .eq('id', user.id)
      .maybeSingle();
    if (error) throw error;

    if (!data) {
      const fresh = {
        id: user.id,
        username: user.email?.split('@')[0] ?? `student_${user.id.slice(0, 6)}`,
        display_name: (user.user_metadata?.display_name as string | undefined) ?? 'Student',
        avatar: { background: '#E0E7FF' },
        xp: 0,
        level: 1,
        streak_days: 0,
        longest_streak: 0,
      };
      const { data: created, error: insertError } = await supabase
        .from(TABLES.profiles)
        .insert(fresh)
        .select()
        .single();
      if (insertError) throw insertError;
      return mapProfile(created);
    }
    return mapProfile(data);
  },

  async loadGuestProfile(): Promise<UserProfile> {
    const raw = await Promise.race([
      AsyncStorage.getItem(STORAGE_KEYS.guestProfile),
      new Promise<null>((resolve) => setTimeout(() => resolve(null), 1500)),
    ]);
    if (raw) {
      try {
        const stored = JSON.parse(raw) as Partial<UserProfile>;
        if (!isSeededDemoProfile(stored)) {
          const { school: _school, gradeLevel: _grade, ...safe } = stored;
          return { ...freshGuestProfile(), ...safe, school: undefined, gradeLevel: undefined };
        }
      } catch {
        // fall through to a new guest
      }
    }
    const fresh = freshGuestProfile();
    AsyncStorage.setItem(STORAGE_KEYS.guestProfile, JSON.stringify(fresh)).catch(() => {});
    return fresh;
  },

  async saveGuestProfile(profile: UserProfile) {
    await AsyncStorage.setItem(STORAGE_KEYS.guestProfile, JSON.stringify(profile));
  },

  /** Persist name / handle to Supabase when signed in. Guest saves stay local. */
  async persistProfile(profile: UserProfile, userId?: string) {
    if (supabase && userId) {
      const { error } = await supabase
        .from(TABLES.profiles)
        .update({ display_name: profile.displayName, username: profile.username })
        .eq('id', userId);
      if (error) throw error;
      return;
    }
    await this.saveGuestProfile(profile);
  },
};

 
const mapProfile = (row: any): UserProfile => ({
  id: row.id,
  username: row.username,
  displayName: row.display_name,
  avatar: row.avatar ?? { background: '#E0E7FF' },
  xp: row.xp ?? 0,
  level: row.level ?? 1,
  streakDays: row.streak_days ?? 0,
  longestStreak: row.longest_streak ?? 0,
  school: row.school ?? undefined,
  gradeLevel: row.grade_level ?? undefined,
  joinedAt: row.created_at ?? new Date().toISOString(),
});
