import AsyncStorage from '@react-native-async-storage/async-storage';

import { STORAGE_KEYS } from '@/constants/config';
import { mockSubjects } from '@/data';
import type { StudySession, StudyTask, Subject } from '@/types';
import { uid } from '@/utils/format';

import { supabase, TABLES } from './supabase';

interface LocalStore {
  tasks: StudyTask[];
  sessions: StudySession[];
}

const emptyStore = (): LocalStore => ({ tasks: [], sessions: [] });

let cache: LocalStore | null = null;
let loadPromise: Promise<LocalStore> | null = null;

const isDemoSeed = (tasks: StudyTask[]) =>
  tasks.some((t) => t.id === 't1' && t.title === 'Integration by parts problem set');

const loadLocal = async (): Promise<LocalStore> => {
  if (cache) return cache;
  if (!loadPromise) {
    loadPromise = (async () => {
      try {
        const [tasksRaw, sessionsRaw] = await Promise.all([
          AsyncStorage.getItem(STORAGE_KEYS.userTasks),
          AsyncStorage.getItem(STORAGE_KEYS.userSessions),
        ]);
        const tasks = tasksRaw ? (JSON.parse(tasksRaw) as StudyTask[]) : [];
        const sessions = sessionsRaw ? (JSON.parse(sessionsRaw) as StudySession[]) : [];
        cache = isDemoSeed(tasks) ? emptyStore() : { tasks: tasks ?? [], sessions: sessions ?? [] };
      } catch {
        cache = emptyStore();
      }
      return cache;
    })();
  }
  return loadPromise;
};

const persist = async (store: LocalStore) => {
  cache = store;
  await Promise.all([
    AsyncStorage.setItem(STORAGE_KEYS.userTasks, JSON.stringify(store.tasks)),
    AsyncStorage.setItem(STORAGE_KEYS.userSessions, JSON.stringify(store.sessions)),
  ]);
};

export const tasksService = {
  async listSubjects(): Promise<Subject[]> {
    return mockSubjects;
  },

  async listTasks(userId?: string): Promise<StudyTask[]> {
    if (supabase && userId) {
      const { data, error } = await supabase
        .from(TABLES.tasks)
        .select('*')
        .eq('user_id', userId)
        .order('due_at', { ascending: true });
      if (error) throw error;
      return data.map(mapTask);
    }
    const { tasks } = await loadLocal();
    return [...tasks].sort((a, b) => a.dueAt.localeCompare(b.dueAt));
  },

  async createTask(input: Omit<StudyTask, 'id' | 'completedMinutes' | 'status'>, userId?: string) {
    const task: StudyTask = { ...input, id: uid('t'), completedMinutes: 0, status: 'todo' };
    if (supabase && userId) {
      const { data, error } = await supabase
        .from(TABLES.tasks)
        .insert(toRow(task, userId))
        .select()
        .single();
      if (error) throw error;
      return mapTask(data);
    }
    const store = await loadLocal();
    await persist({ ...store, tasks: [...store.tasks, task] });
    return task;
  },

  async updateTask(task: StudyTask, userId?: string) {
    if (supabase && userId) {
      const { error } = await supabase
        .from(TABLES.tasks)
        .update(toRow(task, userId))
        .eq('id', task.id);
      if (error) throw error;
      return task;
    }
    const store = await loadLocal();
    await persist({ ...store, tasks: store.tasks.map((t) => (t.id === task.id ? task : t)) });
    return task;
  },

  async toggleTaskDone(taskId: string, userId?: string) {
    const tasks = await this.listTasks(userId);
    const existing = tasks.find((t) => t.id === taskId);
    if (!existing) return null;
    const done = existing.status !== 'done';
    const updated: StudyTask = {
      ...existing,
      status: done ? 'done' : 'todo',
      completedMinutes: done ? existing.estimatedMinutes : existing.completedMinutes,
    };
    return this.updateTask(updated, userId);
  },

  async deleteTask(taskId: string, userId?: string) {
    if (supabase && userId) {
      const { error } = await supabase.from(TABLES.tasks).delete().eq('id', taskId);
      if (error) throw error;
    }
    const store = await loadLocal();
    await persist({ ...store, tasks: store.tasks.filter((t) => t.id !== taskId) });
  },

  async listSessions(userId?: string): Promise<StudySession[]> {
    if (supabase && userId) {
      const { data, error } = await supabase
        .from(TABLES.sessions)
        .select('*')
        .eq('user_id', userId)
        .order('started_at', { ascending: false })
        .limit(60);
      if (error) throw error;
      return data.map((row) => ({
        id: row.id,
        taskId: row.task_id ?? undefined,
        startedAt: row.started_at,
        durationMinutes: row.duration_minutes,
        kind: row.kind,
      }));
    }
    const { sessions } = await loadLocal();
    return sessions;
  },

  async logSession(session: Omit<StudySession, 'id'>, userId?: string) {
    const full: StudySession = { ...session, id: uid('ss') };
    if (supabase && userId) {
      const { error } = await supabase.from(TABLES.sessions).insert({
        id: full.id,
        user_id: userId,
        task_id: full.taskId ?? null,
        started_at: full.startedAt,
        duration_minutes: full.durationMinutes,
        kind: full.kind,
      });
      if (error) throw error;
    }
    const store = await loadLocal();
    await persist({ ...store, sessions: [full, ...store.sessions] });
    return full;
  },
};

const mapTask = (row: any): StudyTask => ({
  id: row.id,
  title: row.title,
  subjectId: row.subject_id,
  dueAt: row.due_at,
  estimatedMinutes: row.estimated_minutes,
  completedMinutes: row.completed_minutes ?? 0,
  priority: row.priority,
  status: row.status,
  notes: row.notes ?? undefined,
});

const toRow = (task: StudyTask, userId: string) => ({
  id: task.id,
  user_id: userId,
  title: task.title,
  subject_id: task.subjectId,
  due_at: task.dueAt,
  estimated_minutes: task.estimatedMinutes,
  completed_minutes: task.completedMinutes,
  priority: task.priority,
  status: task.status,
  notes: task.notes ?? null,
});
