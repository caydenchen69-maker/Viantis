import { createAudioPlayer, setAudioModeAsync, type AudioPlayer, type AudioSource } from 'expo-audio';
import * as Haptics from 'expo-haptics';
import { Platform } from 'react-native';

import type { AmbientSoundId } from '@/types';

// Procedurally generated, royalty-free loops bundled with the app.
// Add cafe/forest/lofi files to assets/sounds and wire them here.
const AMBIENT_SOURCES: Record<AmbientSoundId, AudioSource | null> = {
  rain: require('../../assets/sounds/rain.wav'),
  white_noise: require('../../assets/sounds/white_noise.wav'),
  cafe: null,
  forest: null,
  lofi: null,
};

const CHIME_SOURCE: AudioSource = require('../../assets/sounds/chime.wav');

let ambientPlayer: AudioPlayer | null = null;
let currentAmbient: AmbientSoundId | null = null;
let audioModeReady = false;

const ensureAudioMode = async () => {
  if (audioModeReady) return;
  audioModeReady = true;
  try {
    await setAudioModeAsync({
      playsInSilentMode: true,
      shouldPlayInBackground: true,
      interruptionMode: 'mixWithOthers',
    });
  } catch {
    // Non-fatal: audio still works in the foreground.
  }
};

export const soundService = {
  isAmbientAvailable: (id: AmbientSoundId) => AMBIENT_SOURCES[id] !== null,

  /** Plays the interval-complete chime plus a haptic so it registers on mute. */
  async playChime() {
    await ensureAudioMode();
    if (Platform.OS !== 'web') {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
    }
    try {
      const player = createAudioPlayer(CHIME_SOURCE);
      player.volume = 0.9;
      player.play();
      setTimeout(() => player.remove(), 2500);
    } catch {
      // Ignore playback failures (e.g. web autoplay policy).
    }
  },

  async playAmbient(id: AmbientSoundId, volume = 0.5) {
    const source = AMBIENT_SOURCES[id];
    if (!source) return false;
    await ensureAudioMode();
    if (currentAmbient === id && ambientPlayer) {
      ambientPlayer.play();
      return true;
    }
    this.stopAmbient();
    try {
      ambientPlayer = createAudioPlayer(source);
      ambientPlayer.loop = true;
      ambientPlayer.volume = volume;
      ambientPlayer.play();
      currentAmbient = id;
      return true;
    } catch {
      return false;
    }
  },

  pauseAmbient() {
    ambientPlayer?.pause();
  },

  stopAmbient() {
    if (ambientPlayer) {
      try {
        ambientPlayer.pause();
        ambientPlayer.remove();
      } catch {
        // already released
      }
    }
    ambientPlayer = null;
    currentAmbient = null;
  },

  setAmbientVolume(volume: number) {
    if (ambientPlayer) ambientPlayer.volume = Math.min(1, Math.max(0, volume));
  },

  get activeAmbient() {
    return currentAmbient;
  },
};
