import { mockRegionCenter, mockSchoolReviews, mockSchools } from '@/data';
import type { School, SchoolFilters, SchoolReview } from '@/types';

import { supabase, TABLES } from './supabase';

export interface LatLng {
  latitude: number;
  longitude: number;
}

export const defaultSchoolFilters: SchoolFilters = {
  query: '',
  types: [],
  majors: [],
  maxAcceptanceRate: null,
  minRating: null,
  radiusKm: 50,
};

/** Haversine distance in kilometres. */
export const distanceKm = (a: LatLng, b: LatLng) => {
  const R = 6371;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(b.latitude - a.latitude);
  const dLon = toRad(b.longitude - a.longitude);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.latitude)) * Math.cos(toRad(b.latitude)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
};

export const applySchoolFilters = (
  schools: School[],
  filters: SchoolFilters,
  origin?: LatLng | null,
): School[] => {
  const q = filters.query.trim().toLowerCase();
  return schools
    .map((s) => ({
      ...s,
      distanceKm: origin ? distanceKm(origin, s.coordinates) : undefined,
    }))
    .filter((s) => {
      if (q && !`${s.name} ${s.city} ${s.majors.join(' ')}`.toLowerCase().includes(q)) return false;
      if (filters.types.length && !filters.types.includes(s.type)) return false;
      if (filters.majors.length && !filters.majors.some((m) => s.majors.includes(m))) return false;
      if (
        filters.maxAcceptanceRate !== null &&
        s.acceptanceRate !== null &&
        s.acceptanceRate > filters.maxAcceptanceRate
      )
        return false;
      if (filters.minRating !== null && s.rating < filters.minRating) return false;
      if (origin && s.distanceKm !== undefined && s.distanceKm > filters.radiusKm) return false;
      return true;
    })
    .sort((a, b) => {
      if (a.distanceKm !== undefined && b.distanceKm !== undefined) return a.distanceKm - b.distanceKm;
      return b.rating - a.rating;
    });
};

export const schoolsService = {
  /** Fallback origin used when location permission is denied. */
  defaultOrigin: mockRegionCenter,

  async search(filters: SchoolFilters, origin?: LatLng | null): Promise<School[]> {
    if (supabase) {
      let query = supabase.from(TABLES.schools).select('*');
      if (filters.types.length) query = query.in('type', filters.types);
      if (filters.minRating !== null) query = query.gte('rating', filters.minRating);
      if (filters.maxAcceptanceRate !== null)
        query = query.lte('acceptance_rate', filters.maxAcceptanceRate);
      if (filters.query.trim()) query = query.ilike('name', `%${filters.query.trim()}%`);
      const { data, error } = await query.limit(100);
      if (error) throw error;
      return applySchoolFilters(data.map(mapSchool), filters, origin);
    }
    await new Promise((r) => setTimeout(r, 250));
    return applySchoolFilters(mockSchools, filters, origin);
  },

  async getById(id: string): Promise<School | undefined> {
    if (supabase) {
      const { data, error } = await supabase.from(TABLES.schools).select('*').eq('id', id).maybeSingle();
      if (error) throw error;
      return data ? mapSchool(data) : undefined;
    }
    return mockSchools.find((s) => s.id === id);
  },

  async listReviews(schoolId: string): Promise<SchoolReview[]> {
    if (supabase) {
      const { data, error } = await supabase
        .from(TABLES.schoolReviews)
        .select('*, author:profiles(id, display_name, avatar)')
        .eq('school_id', schoolId)
        .order('helpful_count', { ascending: false });
      if (error) throw error;
       
      return data.map((row: any) => ({
        id: row.id,
        schoolId: row.school_id,
        author: {
          id: row.author.id,
          displayName: row.author.display_name,
          avatar: row.author.avatar,
        },
        rating: row.rating,
        title: row.title,
        body: row.body,
        createdAt: row.created_at,
        helpfulCount: row.helpful_count,
      }));
    }
    return mockSchoolReviews.filter((r) => r.schoolId === schoolId);
  },
};

 
const mapSchool = (row: any): School => ({
  id: row.id,
  name: row.name,
  type: row.type,
  city: row.city,
  region: row.region,
  country: row.country,
  coordinates: { latitude: row.latitude, longitude: row.longitude },
  acceptanceRate: row.acceptance_rate,
  rating: row.rating,
  reviewCount: row.review_count ?? 0,
  studentCount: row.student_count ?? 0,
  tuitionPerYear: row.tuition_per_year,
  majors: row.majors ?? [],
  highlights: row.highlights ?? [],
  imageUrl: row.image_url ?? undefined,
  website: row.website ?? undefined,
  institutionId: row.institution_id ?? undefined,
  satAverage: row.sat_average ?? undefined,
});
