import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { AppState, Platform } from 'react-native';

import { config, isSupabaseConfigured } from '@/constants/config';

/**
 * Supabase client. `null` when env vars are missing so the app can run fully
 * on mock data. Every service checks `supabase` before hitting the network.
 */
export const supabase: SupabaseClient | null = isSupabaseConfigured
  ? createClient(config.supabaseUrl!, config.supabaseAnonKey!, {
      auth: {
        storage: AsyncStorage,
        autoRefreshToken: true,
        persistSession: true,
        // Deep-link based auth is handled manually in auth.service.ts
        detectSessionInUrl: Platform.OS === 'web',
      },
    })
  : null;

// Keep tokens fresh only while the app is foregrounded (recommended by Supabase).
if (supabase && Platform.OS !== 'web') {
  AppState.addEventListener('change', (state) => {
    if (state === 'active') supabase.auth.startAutoRefresh();
    else supabase.auth.stopAutoRefresh();
  });
}

export const requireSupabase = (): SupabaseClient => {
  if (!supabase) {
    throw new Error(
      'Supabase is not configured. Set EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_ANON_KEY.',
    );
  }
  return supabase;
};

/** Table names centralised so schema renames are one-line changes. */
export const TABLES = {
  profiles: 'profiles',
  tasks: 'tasks',
  sessions: 'study_sessions',
  decks: 'decks',
  flashcards: 'flashcards',
  xpEvents: 'xp_events',
  posts: 'posts',
  comments: 'comments',
  votes: 'votes',
  schools: 'schools',
  schoolReviews: 'school_reviews',
  messages: 'messages',
} as const;
