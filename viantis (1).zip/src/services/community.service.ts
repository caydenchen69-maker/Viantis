import { mockComments, mockPosts, mockTags } from '@/data';
import type { Comment, Post, Tag } from '@/types';
import { uid } from '@/utils/format';

import { supabase, TABLES } from './supabase';

export type FeedSort = 'hot' | 'new' | 'top';

let localPosts: Post[] = [...mockPosts];
let localComments: Comment[] = [...mockComments];

const hotScore = (post: Post) => {
  const ageHours = (Date.now() - new Date(post.createdAt).getTime()) / 3.6e6;
  return (post.upvotes + post.commentCount * 2) / Math.pow(ageHours + 2, 1.4);
};

export const communityService = {
  async listTags(): Promise<Tag[]> {
    return mockTags;
  },

  async listPosts(opts: { sort?: FeedSort; tag?: string | null } = {}): Promise<Post[]> {
    const { sort = 'hot', tag = null } = opts;
    let posts: Post[];

    if (supabase) {
      let query = supabase
        .from(TABLES.posts)
        .select('*, author:profiles(id, username, display_name, avatar, level)')
        .eq('is_removed', false);
      if (tag) query = query.contains('tags', [tag]);
      const { data, error } = await query.limit(50);
      if (error) throw error;
      posts = data.map(mapPost);
    } else {
      posts = tag ? localPosts.filter((p) => p.tags.includes(tag)) : [...localPosts];
    }

    const pinned = posts.filter((p) => p.isPinned);
    const rest = posts.filter((p) => !p.isPinned);
    rest.sort((a, b) => {
      if (sort === 'new') return b.createdAt.localeCompare(a.createdAt);
      if (sort === 'top') return b.upvotes - a.upvotes;
      return hotScore(b) - hotScore(a);
    });
    return [...pinned, ...rest];
  },

  async getPost(id: string): Promise<Post | undefined> {
    return localPosts.find((p) => p.id === id);
  },

  async listComments(postId: string): Promise<Comment[]> {
    if (supabase) {
      const { data, error } = await supabase
        .from(TABLES.comments)
        .select('*, author:profiles(id, username, display_name, avatar)')
        .eq('post_id', postId)
        .order('created_at', { ascending: true });
      if (error) throw error;
      return nestComments(data.map(mapComment));
    }
    return localComments.filter((c) => c.postId === postId);
  },

  /**
   * Optimistic vote toggle. Passing the same direction twice clears the vote.
   * Returns the updated post so callers can update local state immediately.
   */
  async votePost(post: Post, direction: 1 | -1, userId?: string): Promise<Post> {
    const nextVote = post.userVote === direction ? 0 : direction;
    const updated: Post = {
      ...post,
      userVote: nextVote,
      upvotes: post.upvotes - post.userVote + nextVote,
    };
    localPosts = localPosts.map((p) => (p.id === post.id ? updated : p));

    if (supabase && userId) {
      if (nextVote === 0) {
        await supabase.from(TABLES.votes).delete().match({ user_id: userId, post_id: post.id });
      } else {
        await supabase
          .from(TABLES.votes)
          .upsert({ user_id: userId, post_id: post.id, value: nextVote }, { onConflict: 'user_id,post_id' });
      }
    }
    return updated;
  },

  async createPost(
    input: Pick<Post, 'title' | 'body' | 'tags' | 'kind'>,
    author: Post['author'],
  ): Promise<Post> {
    const post: Post = {
      ...input,
      id: uid('p'),
      author,
      upvotes: 1,
      commentCount: 0,
      createdAt: new Date().toISOString(),
      userVote: 1,
    };
    if (supabase) {
      const { error } = await supabase.from(TABLES.posts).insert({
        id: post.id,
        author_id: author.id,
        kind: post.kind,
        title: post.title,
        body: post.body,
        tags: post.tags,
      });
      if (error) throw error;
    }
    localPosts = [post, ...localPosts];
    return post;
  },

  async addComment(postId: string, body: string, author: Comment['author'], parentId?: string) {
    const comment: Comment = {
      id: uid('c'),
      postId,
      parentId,
      author,
      body,
      upvotes: 0,
      createdAt: new Date().toISOString(),
      userVote: 0,
    };
    if (supabase) {
      const { error } = await supabase.from(TABLES.comments).insert({
        id: comment.id,
        post_id: postId,
        parent_id: parentId ?? null,
        author_id: author.id,
        body,
      });
      if (error) throw error;
    }
    if (parentId) {
      localComments = localComments.map((c) =>
        c.id === parentId ? { ...c, replies: [...(c.replies ?? []), comment] } : c,
      );
    } else {
      localComments = [...localComments, comment];
    }
    localPosts = localPosts.map((p) =>
      p.id === postId ? { ...p, commentCount: p.commentCount + 1 } : p,
    );
    return comment;
  },

  // ---------- Moderation ----------

  async reportPost(postId: string, reason: string, reporterId?: string) {
    if (supabase) {
      await supabase.from('reports').insert({
        post_id: postId,
        reason,
        reporter_id: reporterId ?? null,
      });
    }
    localPosts = localPosts.map((p) => (p.id === postId ? { ...p, isFlagged: true } : p));
  },

  async removeComment(commentId: string) {
    if (supabase) {
      await supabase.from(TABLES.comments).update({ is_removed: true }).eq('id', commentId);
    }
    const strip = (list: Comment[]): Comment[] =>
      list.map((c) =>
        c.id === commentId
          ? { ...c, isRemoved: true, body: '[removed by moderator]' }
          : { ...c, replies: c.replies ? strip(c.replies) : undefined },
      );
    localComments = strip(localComments);
  },
};

 
const mapPost = (row: any): Post => ({
  id: row.id,
  kind: row.kind,
  title: row.title,
  body: row.body,
  author: {
    id: row.author.id,
    username: row.author.username,
    displayName: row.author.display_name,
    avatar: row.author.avatar,
    level: row.author.level,
  },
  tags: row.tags ?? [],
  upvotes: row.upvotes ?? 0,
  commentCount: row.comment_count ?? 0,
  createdAt: row.created_at,
  userVote: row.user_vote ?? 0,
  isPinned: row.is_pinned ?? false,
  isFlagged: row.is_flagged ?? false,
  schoolId: row.school_id ?? undefined,
});

 
const mapComment = (row: any): Comment => ({
  id: row.id,
  postId: row.post_id,
  parentId: row.parent_id ?? undefined,
  author: {
    id: row.author.id,
    username: row.author.username,
    displayName: row.author.display_name,
    avatar: row.author.avatar,
  },
  body: row.is_removed ? '[removed by moderator]' : row.body,
  upvotes: row.upvotes ?? 0,
  createdAt: row.created_at,
  userVote: row.user_vote ?? 0,
  isRemoved: row.is_removed ?? false,
});

const nestComments = (flat: Comment[]): Comment[] => {
  const byId = new Map(flat.map((c) => [c.id, { ...c, replies: [] as Comment[] }]));
  const roots: Comment[] = [];
  for (const c of byId.values()) {
    if (c.parentId && byId.has(c.parentId)) byId.get(c.parentId)!.replies!.push(c);
    else roots.push(c);
  }
  return roots;
};
