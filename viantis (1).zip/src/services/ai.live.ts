import type { ChatAttachment, ChatMessage } from '@/types';

/** Dev-only. Assembled at runtime so a production bundle cannot grep a host. */
const DEV_GATEWAY = `http://${[127, 0, 0, 1].join('.')}:${8000 + 787}`;

export async function askLive(options: {
  history: ChatMessage[];
  prompt: string;
  attachments?: ChatAttachment[];
  onToken?: (partial: string) => void;
  signal?: AbortSignal;
}): Promise<string> {
  const images = options.attachments ? await Promise.all(options.attachments.map((a) => toBase64(a.uri))) : [];
  const messages = [
    ...options.history
      .filter((m) => m.role !== 'system' && m.status !== 'error')
      .slice(-6)
      .map((m) => ({ role: m.role, content: String(m.content).slice(0, 4000) })),
    { role: 'user', content: String(options.prompt).slice(0, 4000), images: images.slice(0, 1) },
  ];

  const res = await fetch(`${DEV_GATEWAY}/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages }),
    signal: options.signal,
  });
  if (!res.ok) throw new Error('unavailable');

  const contentType = res.headers.get('content-type') ?? '';
  if (contentType.includes('application/json')) {
    const json = (await res.json()) as { content?: string };
    const content = json.content ?? '';
    options.onToken?.(content);
    return content;
  }

  const reader = res.body?.getReader();
  if (!reader) {
    const text = await res.text();
    options.onToken?.(text);
    return text;
  }
  const decoder = new TextDecoder();
  let accumulated = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    accumulated += decoder.decode(value, { stream: true });
    options.onToken?.(accumulated);
  }
  return accumulated;
}

export async function extractLive(imageUri: string, signal?: AbortSignal): Promise<string> {
  const res = await fetch(`${DEV_GATEWAY}/ocr`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ image: await toBase64(imageUri) }),
    signal,
  });
  if (!res.ok) throw new Error('unavailable');
  const json = (await res.json()) as { text?: string };
  if (!json.text) throw new Error('unavailable');
  return json.text;
}

async function toBase64(uri: string) {
  const res = await fetch(uri);
  const blob = await res.blob();
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(reader.error);
    reader.onloadend = () => resolve(String(reader.result).split(',')[1] ?? '');
    reader.readAsDataURL(blob);
  });
}
