import type { ChatAttachment, ChatMessage } from '@/types';
import { mockAIFallbackResponse, mockAIResponses, mockOCRText } from '@/data';

export interface AskOptions {
  history: ChatMessage[];
  prompt: string;
  attachments?: ChatAttachment[];
  onToken?: (partial: string) => void;
  signal?: AbortSignal;
}

const CLIENT_WINDOW_MS = 5 * 60 * 1000;
const CLIENT_MAX_ASKS = 6;
const askTimes: number[] = [];

const liveEnabled = () => typeof __DEV__ !== 'undefined' && __DEV__;

type LiveModule = typeof import('./ai.live');

let live: LiveModule | null = null;
if (liveEnabled()) {
  // Dev-only require so the gateway origin is not in production / exported JS.
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  live = require('./ai.live') as LiveModule;
}

const assertClientBudget = () => {
  const now = Date.now();
  while (askTimes.length && askTimes[0]! < now - CLIENT_WINDOW_MS) askTimes.shift();
  if (askTimes.length >= CLIENT_MAX_ASKS) {
    throw new Error('Give the helper a few minutes — too many requests just now.');
  }
  askTimes.push(now);
};

/**
 * Homework helper. Production / exported web builds stay on local demo
 * answers so no provider URL or key exists in the public bundle.
 * `npm start` plus `npm run ai-gateway` is the only live path.
 */
export const aiService = {
  isLive: Boolean(live),

  async ask({ history, prompt, attachments, onToken, signal }: AskOptions): Promise<string> {
    if (live) {
      try {
        assertClientBudget();
        return await live.askLive({ history, prompt, attachments, onToken, signal });
      } catch (error) {
        if (error instanceof Error && error.message.startsWith('Give the helper')) throw error;
      }
    }
    return askMock({ prompt, attachments, onToken, signal });
  },

  async extractText(imageUri: string, signal?: AbortSignal): Promise<string> {
    if (live) {
      try {
        assertClientBudget();
        return await live.extractLive(imageUri, signal);
      } catch {
        // fall through
      }
    }
    await delay(900, signal);
    return mockOCRText;
  },
};

function composeMockDraft(prompt: string): string | null {
  if (!/Current draft:/i.test(prompt) || !/Instruction:/i.test(prompt)) return null;
  const instruction = prompt.split(/Instruction:\s*/i)[1]?.trim() ?? '';
  const draft = prompt.split(/Current draft:\s*/i)[1]?.split(/Instruction:/i)[0]?.trim() ?? '';
  const title = prompt.match(/Title:\s*(.+)/)?.[1]?.trim();
  const heading = title && title !== '(empty)' ? title : 'Draft';

  if (!draft || draft === '(empty)') {
    return `${heading}

${instruction}

1. Open with the claim in one sentence.
2. Give two pieces of evidence, each with a short explanation.
3. Address the obvious counterargument.
4. Close by restating the claim in new words.

Next: add your own examples in the blanks, then ask the helper to tighten the language.`;
  }

  return `${heading}

${draft}

—
Revised for: ${instruction.replace(/\s+/g, ' ').slice(0, 120)}

The argument is clearer if the first sentence states the claim, each paragraph starts with a topic sentence, and the close returns to the opening idea without repeating it.`;
}

async function askMock({
  prompt,
  attachments,
  onToken,
  signal,
}: Pick<AskOptions, 'prompt' | 'attachments' | 'onToken' | 'signal'>) {
  const composed = composeMockDraft(prompt);
  const haystack = attachments?.length ? `${prompt} photo` : prompt;
  const matched = mockAIResponses.find((r) => r.match.test(haystack));
  const full = composed ?? matched?.response ?? mockAIFallbackResponse;

  await delay(700, signal);
  const words = full.split(/(\s+)/);
  let partial = '';
  for (const word of words) {
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
    partial += word;
    onToken?.(partial);
    if (word.trim()) await delay(18 + Math.random() * 30, signal);
  }
  return full;
}

const delay = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((resolve, reject) => {
    const t = setTimeout(resolve, ms);
    signal?.addEventListener('abort', () => {
      clearTimeout(t);
      reject(new DOMException('Aborted', 'AbortError'));
    });
  });
