import type { RealtimeChannel } from '@supabase/supabase-js';

import { mockChatMessages } from '@/data';
import type { ChatRoomMessage } from '@/types';
import { uid } from '@/utils/format';

import { supabase, TABLES } from './supabase';

export type MessageListener = (message: ChatRoomMessage) => void;

/**
 * Real-time community chat backed by Supabase Realtime (postgres_changes on the
 * `messages` table). In mock mode a local emitter simulates incoming messages
 * so the UI can be exercised without a backend.
 */
export const chatService = {
  async listMessages(roomId: string, limit = 50): Promise<ChatRoomMessage[]> {
    if (supabase) {
      const { data, error } = await supabase
        .from(TABLES.messages)
        .select('*')
        .eq('room_id', roomId)
        .order('created_at', { ascending: false })
        .limit(limit);
      if (error) throw error;
      return data.map(mapMessage).reverse();
    }
    return mockChatMessages.filter((m) => m.roomId === roomId);
  },

  async sendMessage(roomId: string, body: string, author: { id: string; name: string }) {
    const message: ChatRoomMessage = {
      id: uid('cm'),
      roomId,
      authorId: author.id,
      authorName: author.name,
      body,
      createdAt: new Date().toISOString(),
    };
    if (supabase) {
      const { error } = await supabase.from(TABLES.messages).insert({
        id: message.id,
        room_id: roomId,
        author_id: author.id,
        author_name: author.name,
        body,
      });
      if (error) throw error;
    } else {
      localEmitter.emit(roomId, message);
    }
    return message;
  },

  /** Subscribe to new messages in a room. Returns an unsubscribe function. */
  subscribe(roomId: string, listener: MessageListener): () => void {
    if (supabase) {
      const client = supabase;
      const channel: RealtimeChannel = client
        .channel(`room:${roomId}`)
        .on(
          'postgres_changes',
          { event: 'INSERT', schema: 'public', table: TABLES.messages, filter: `room_id=eq.${roomId}` },
          (payload) => listener(mapMessage(payload.new)),
        )
        .subscribe();
      return () => {
        client.removeChannel(channel);
      };
    }
    return localEmitter.on(roomId, listener);
  },
};

 
const mapMessage = (row: any): ChatRoomMessage => ({
  id: row.id,
  roomId: row.room_id,
  authorId: row.author_id,
  authorName: row.author_name,
  body: row.body,
  createdAt: row.created_at,
});

const localEmitter = (() => {
  const listeners = new Map<string, Set<MessageListener>>();
  return {
    on(roomId: string, fn: MessageListener) {
      if (!listeners.has(roomId)) listeners.set(roomId, new Set());
      listeners.get(roomId)!.add(fn);
      return () => {
        listeners.get(roomId)?.delete(fn);
      };
    },
    emit(roomId: string, message: ChatRoomMessage) {
      listeners.get(roomId)?.forEach((fn) => fn(message));
    },
  };
})();
