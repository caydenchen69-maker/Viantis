import { useMemo } from 'react';

import { useAuth } from '@/providers/AuthProvider';
import { tasksService } from '@/services';
import { addDays, isSameDay, startOfDay } from '@/utils/date';

import { useAsync } from './useAsync';

export interface DayStat {
  date: Date;
  minutes: number;
  label: string;
}

/** Aggregates focus sessions into the weekly chart + today's totals. */
export function useStudyStats() {
  const { session } = useAuth();
  const userId = session?.user.id;
  const { data: sessions = [], loading } = useAsync(() => tasksService.listSessions(userId), [userId]);

  return useMemo(() => {
    const today = startOfDay(new Date());
    const week: DayStat[] = Array.from({ length: 7 }, (_, i) => {
      const date = addDays(today, i - 6);
      const minutes = sessions
        .filter((s) => s.kind === 'focus' && isSameDay(new Date(s.startedAt), date))
        .reduce((acc, s) => acc + s.durationMinutes, 0);
      return { date, minutes, label: ['S', 'M', 'T', 'W', 'T', 'F', 'S'][date.getDay()]! };
    });
    const todayMinutes = week[6]?.minutes ?? 0;
    const weekMinutes = week.reduce((acc, d) => acc + d.minutes, 0);
    const maxMinutes = Math.max(30, ...week.map((d) => d.minutes));
    return { week, todayMinutes, weekMinutes, maxMinutes, loading, sessions };
  }, [sessions, loading]);
}
