import * as Location from 'expo-location';
import { useCallback, useEffect, useState } from 'react';

import { schoolsService, type LatLng } from '@/services';

export type LocationStatus = 'idle' | 'requesting' | 'granted' | 'denied' | 'error';

interface LocationResult {
  coords: LatLng;
  status: Exclude<LocationStatus, 'idle' | 'requesting'>;
}

/** Resolves permission + position, falling back to the mock region centre. */
async function resolveLocation(): Promise<LocationResult> {
  try {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') return { coords: schoolsService.defaultOrigin, status: 'denied' };
    const position = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
    return {
      coords: { latitude: position.coords.latitude, longitude: position.coords.longitude },
      status: 'granted',
    };
  } catch {
    return { coords: schoolsService.defaultOrigin, status: 'error' };
  }
}

/**
 * Resolves the user's coarse location for the School Finder. When permission is
 * denied the mock region centre is used so results still render.
 */
export function useLocation(auto = true) {
  const [coords, setCoords] = useState<LatLng | null>(null);
  const [status, setStatus] = useState<LocationStatus>(auto ? 'requesting' : 'idle');
  const [attempt, setAttempt] = useState(auto ? 1 : 0);

  useEffect(() => {
    if (attempt === 0) return;
    let cancelled = false;
    resolveLocation().then((result) => {
      if (cancelled) return;
      setCoords(result.coords);
      setStatus(result.status);
    });
    return () => {
      cancelled = true;
    };
  }, [attempt]);

  const request = useCallback(() => {
    setStatus('requesting');
    setAttempt((n) => n + 1);
  }, []);

  return { coords, status, request, usingFallback: status === 'denied' || status === 'error' };
}
