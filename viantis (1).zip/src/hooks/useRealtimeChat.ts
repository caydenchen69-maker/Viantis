import { useCallback, useEffect, useState } from 'react';

import { useAuth } from '@/providers/AuthProvider';
import { chatService } from '@/services';
import type { ChatRoomMessage } from '@/types';

export function useRealtimeChat(roomId: string) {
  const { profile } = useAuth();
  const [messages, setMessages] = useState<ChatRoomMessage[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    chatService
      .listMessages(roomId)
      .then((list) => {
        if (active) setMessages(list);
      })
      .finally(() => active && setLoading(false));

    const unsubscribe = chatService.subscribe(roomId, (incoming) => {
      setMessages((prev) => (prev.some((m) => m.id === incoming.id) ? prev : [...prev, incoming]));
    });

    return () => {
      active = false;
      unsubscribe();
    };
  }, [roomId]);

  const send = useCallback(
    async (body: string) => {
      const trimmed = body.trim();
      if (!trimmed || !profile) return;
      await chatService.sendMessage(roomId, trimmed, { id: profile.id, name: profile.displayName });
    },
    [roomId, profile],
  );

  return { messages, loading, send, currentUserId: profile?.id };
}
