import { useCallback, useMemo } from 'react';

import { mockSubjects } from '@/data';
import { arcadeService } from '@/services';
import type { Deck, Flashcard, Subject } from '@/types';

import { useAsync } from './useAsync';

export function useDecks() {
  const { data, loading, error, refresh, setData } = useAsync(() => arcadeService.listDecks(), []);
  const { data: sharedData, refresh: refreshShared } = useAsync(() => arcadeService.listSharedDecks(), []);
  const decks = useMemo(() => data ?? [], [data]);
  const customDecks = useMemo(() => decks.filter((d) => d.custom), [decks]);
  const sampleDecks = useMemo(() => decks.filter((d) => !d.custom), [decks]);
  const sharedDecks = useMemo(() => sharedData ?? [], [sharedData]);
  const ownedBySource = useMemo(() => {
    const map = new Map<string, string>();
    for (const deck of customDecks) {
      if (deck.sourceId) map.set(deck.sourceId, deck.id);
      if (deck.shared) map.set(deck.id, deck.id);
    }
    return map;
  }, [customDecks]);
  const subjectsById = useMemo(
    () => new Map<string, Subject>(mockSubjects.map((s) => [s.id, s])),
    [],
  );

  const createDeck = useCallback(
    async (input: { title: string; subjectId: string }) => {
      const created = await arcadeService.createDeck(input);
      setData((prev) => [created, ...(prev ?? [])]);
      return created;
    },
    [setData],
  );

  const updateDeck = useCallback(
    async (deckId: string, patch: Partial<Pick<Deck, 'title' | 'subjectId'>>) => {
      const next = await arcadeService.updateDeck(deckId, patch);
      if (next) setData((prev) => prev?.map((d) => (d.id === deckId ? next : d)));
      return next;
    },
    [setData],
  );

  const deleteDeck = useCallback(
    async (deckId: string) => {
      setData((prev) => prev?.filter((d) => d.id !== deckId));
      await arcadeService.deleteDeck(deckId);
      await refreshShared();
    },
    [setData, refreshShared],
  );

  const publishDeck = useCallback(
    async (deckId: string, authorName?: string) => {
      const next = await arcadeService.publishDeck(deckId, authorName);
      if (next) {
        setData((prev) =>
          prev?.map((d) =>
            d.id === deckId ? { ...d, shared: true, authorName: next.authorName, sharedAt: next.sharedAt } : d,
          ),
        );
        await refreshShared();
      }
      return next;
    },
    [setData, refreshShared],
  );

  const unpublishDeck = useCallback(
    async (deckId: string) => {
      const next = await arcadeService.unpublishDeck(deckId);
      if (next) setData((prev) => prev?.map((d) => (d.id === deckId ? next : d)));
      await refreshShared();
      return next;
    },
    [setData, refreshShared],
  );

  const addSharedToLibrary = useCallback(
    async (sharedDeckId: string) => {
      const created = await arcadeService.addSharedToLibrary(sharedDeckId);
      if (created) setData((prev) => [created, ...(prev ?? []).filter((d) => d.id !== created.id)]);
      return created;
    },
    [setData],
  );

  const importShareCode = useCallback(
    async (code: string) => {
      const created = await arcadeService.importShareCode(code);
      if (created) setData((prev) => [created, ...(prev ?? [])]);
      return created;
    },
    [setData],
  );

  const exportShareCode = useCallback(async (deckId: string) => {
    const deck = await arcadeService.getDeck(deckId);
    const cards = await arcadeService.listFlashcards(deckId);
    if (!deck || cards.length < 2) return null;
    return arcadeService.encodeShareCode(deck, cards);
  }, []);

  const refreshAll = useCallback(async () => {
    await Promise.all([refresh(), refreshShared()]);
  }, [refresh, refreshShared]);

  return {
    decks,
    customDecks,
    sampleDecks,
    sharedDecks,
    ownedBySource,
    loading,
    error,
    refresh: refreshAll,
    createDeck,
    updateDeck,
    deleteDeck,
    publishDeck,
    unpublishDeck,
    addSharedToLibrary,
    importShareCode,
    exportShareCode,
    subjectsById,
  };
}

export function useDeckCards(deckId: string | undefined) {
  const { data, loading, refresh, setData } = useAsync(
    () => (deckId ? arcadeService.listFlashcards(deckId) : Promise.resolve([])),
    [deckId],
  );
  const cards = useMemo(() => data ?? [], [data]);

  const addCard = useCallback(
    async (input: { front: string; back: string; title?: string; subjectId?: string }) => {
      if (!deckId) return null;
      const created = await arcadeService.addCard(deckId, input);
      setData((prev) => [...(prev ?? []), created]);
      return created;
    },
    [deckId, setData],
  );

  const updateCard = useCallback(
    async (card: Flashcard) => {
      const next = await arcadeService.updateCard(card);
      if (next) setData((prev) => prev?.map((c) => (c.id === card.id ? next : c)));
      return next;
    },
    [setData],
  );

  const deleteCard = useCallback(
    async (cardId: string) => {
      setData((prev) => prev?.filter((c) => c.id !== cardId));
      await arcadeService.deleteCard(cardId);
    },
    [setData],
  );

  return { cards, loading, refresh, addCard, updateCard, deleteCard };
}
