import * as ImagePicker from 'expo-image-picker';
import { useCallback, useState } from 'react';
import { Alert } from 'react-native';

import type { ChatAttachment } from '@/types';
import { uid } from '@/utils/format';

/** Camera / library picker producing ChatAttachment objects for the AI Helper. */
export function useImagePicker() {
  const [picking, setPicking] = useState(false);

  const toAttachment = (asset: ImagePicker.ImagePickerAsset): ChatAttachment => ({
    id: uid('img'),
    uri: asset.uri,
    width: asset.width,
    height: asset.height,
  });

  const fromLibrary = useCallback(async (): Promise<ChatAttachment | null> => {
    setPicking(true);
    try {
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Photo access needed', 'Allow photo access in Settings to upload homework.');
        return null;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        quality: 0.8,
        allowsEditing: true,
      });
      if (result.canceled || !result.assets[0]) return null;
      return toAttachment(result.assets[0]);
    } finally {
      setPicking(false);
    }
  }, []);

  const fromCamera = useCallback(async (): Promise<ChatAttachment | null> => {
    setPicking(true);
    try {
      const perm = await ImagePicker.requestCameraPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Camera access needed', 'Allow camera access in Settings to snap a problem.');
        return null;
      }
      const result = await ImagePicker.launchCameraAsync({ quality: 0.8, allowsEditing: true });
      if (result.canceled || !result.assets[0]) return null;
      return toAttachment(result.assets[0]);
    } finally {
      setPicking(false);
    }
  }, []);

  return { fromLibrary, fromCamera, picking };
}
