import { useCallback, useMemo } from 'react';

import { XP_RULES } from '@/constants/config';
import { mockSubjects } from '@/data';
import { useAuth } from '@/providers/AuthProvider';
import { tasksService } from '@/services';
import type { StudyTask, Subject } from '@/types';
import { isSameDay, startOfDay } from '@/utils/date';

import { useAsync } from './useAsync';

export function useTasks() {
  const { profile, session, addXP } = useAuth();
  const userId = session?.user.id;
  const { data, loading, error, refresh, setData } = useAsync(
    () => tasksService.listTasks(userId),
    [userId],
  );

  const tasks = useMemo(() => data ?? [], [data]);

  const subjectsById = useMemo(
    () => new Map<string, Subject>(mockSubjects.map((s) => [s.id, s])),
    [],
  );

  const toggleDone = useCallback(
    async (task: StudyTask) => {
      const wasDone = task.status === 'done';
      const optimistic: StudyTask = {
        ...task,
        status: wasDone ? 'todo' : 'done',
        completedMinutes: wasDone ? task.completedMinutes : task.estimatedMinutes,
      };
      setData((prev) => prev?.map((t) => (t.id === task.id ? optimistic : t)));
      if (!wasDone) addXP(XP_RULES.taskComplete);
      try {
        await tasksService.updateTask(optimistic, userId);
      } catch {
        refresh();
      }
    },
    [setData, userId, addXP, refresh],
  );

  const createTask = useCallback(
    async (input: Omit<StudyTask, 'id' | 'completedMinutes' | 'status'>) => {
      const created = await tasksService.createTask(input, userId);
      setData((prev) => [...(prev ?? []), created].sort((a, b) => a.dueAt.localeCompare(b.dueAt)));
      return created;
    },
    [setData, userId],
  );

  const deleteTask = useCallback(
    async (taskId: string) => {
      setData((prev) => prev?.filter((t) => t.id !== taskId));
      await tasksService.deleteTask(taskId, userId);
    },
    [setData, userId],
  );

  const tasksForDay = useCallback(
    (day: Date) => tasks.filter((t) => isSameDay(new Date(t.dueAt), day)),
    [tasks],
  );

  // Derive the day boundary from a primitive so memoised values stay stable across renders.
  const todayMs = startOfDay(new Date()).getTime();
  const todayTasks = useMemo(() => tasksForDay(new Date(todayMs)), [tasksForDay, todayMs]);
  const upcoming = useMemo(
    () => tasks.filter((t) => t.status !== 'done' && new Date(t.dueAt).getTime() >= todayMs).slice(0, 5),
    [tasks, todayMs],
  );
  const overdue = useMemo(
    () => tasks.filter((t) => t.status !== 'done' && new Date(t.dueAt).getTime() < todayMs),
    [tasks, todayMs],
  );

  return {
    tasks,
    todayTasks,
    upcoming,
    overdue,
    loading,
    error,
    refresh,
    toggleDone,
    createTask,
    deleteTask,
    tasksForDay,
    subjectsById,
    profile,
  };
}
