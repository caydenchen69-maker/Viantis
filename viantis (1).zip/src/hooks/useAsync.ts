import { useCallback, useEffect, useRef, useState } from 'react';

export interface AsyncState<T> {
  data: T | undefined;
  loading: boolean;
  error: Error | null;
  refresh: () => Promise<void>;
  setData: React.Dispatch<React.SetStateAction<T | undefined>>;
}

interface Result<T> {
  /** Key of the request that produced this result; mismatches mean "loading". */
  key: string;
  data: T | undefined;
  error: Error | null;
}

/**
 * Minimal data-loading hook for service calls. Re-runs when `deps` change,
 * ignores results from stale invocations and keeps the previous data visible
 * while refreshing. `loading` is derived from whether the latest request key
 * has resolved, so no state is set synchronously inside effects.
 */
export function useAsync<T>(fn: () => Promise<T>, deps: React.DependencyList): AsyncState<T> {
  const [tick, setTick] = useState(0);
  const requestKey = `${JSON.stringify(deps)}|${tick}`;
  const [result, setResult] = useState<Result<T>>({ key: '', data: undefined, error: null });

  // Keep the latest fn without making it a dependency; effects run in order so
  // the assignment below always precedes the fetch effect.
  const fnRef = useRef(fn);
  useEffect(() => {
    fnRef.current = fn;
  });

  useEffect(() => {
    let cancelled = false;
    fnRef
      .current()
      .then((data) => {
        if (!cancelled) setResult({ key: requestKey, data, error: null });
      })
      .catch((e: unknown) => {
        if (!cancelled) {
          setResult((prev) => ({
            key: requestKey,
            data: prev.data,
            error: e instanceof Error ? e : new Error(String(e)),
          }));
        }
      });
    return () => {
      cancelled = true;
    };
  }, [requestKey]);

  const refresh = useCallback(async () => {
    setTick((t) => t + 1);
  }, []);

  const setData = useCallback<React.Dispatch<React.SetStateAction<T | undefined>>>((update) => {
    setResult((prev) => ({
      ...prev,
      data: typeof update === 'function' ? (update as (prev: T | undefined) => T | undefined)(prev.data) : update,
    }));
  }, []);

  return {
    data: result.data,
    loading: result.key !== requestKey,
    error: result.key === requestKey ? result.error : null,
    refresh,
    setData,
  };
}
