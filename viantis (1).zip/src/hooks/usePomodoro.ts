import AsyncStorage from '@react-native-async-storage/async-storage';
import { useCallback, useEffect, useRef, useState } from 'react';

import { STORAGE_KEYS, XP_RULES } from '@/constants/config';
import { defaultPomodoroSettings } from '@/data';
import { useAuth } from '@/providers/AuthProvider';
import { soundService, tasksService } from '@/services';
import type { PomodoroSettings } from '@/types';

export type PomodoroPhase = 'focus' | 'short_break' | 'long_break';
export type PomodoroStatus = 'idle' | 'running' | 'paused';

const phaseMinutes = (phase: PomodoroPhase, s: PomodoroSettings) =>
  phase === 'focus' ? s.focusMinutes : phase === 'short_break' ? s.shortBreakMinutes : s.longBreakMinutes;

/**
 * Drift-free Pomodoro engine. Tracks an absolute `endsAt` timestamp rather than
 * decrementing a counter so backgrounding the app does not desync the timer.
 */
export function usePomodoro(taskId?: string) {
  const { addXP, session } = useAuth();
  const [settings, setSettings] = useState<PomodoroSettings>(defaultPomodoroSettings);
  const [phase, setPhase] = useState<PomodoroPhase>('focus');
  const [status, setStatus] = useState<PomodoroStatus>('idle');
  const [completedRounds, setCompletedRounds] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState(defaultPomodoroSettings.focusMinutes * 60);

  const endsAt = useRef<number | null>(null);
  const phaseStartedAt = useRef<string | null>(null);
  const interval = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEYS.pomodoroSettings).then((raw) => {
      if (!raw) return;
      try {
        const stored = { ...defaultPomodoroSettings, ...(JSON.parse(raw) as Partial<PomodoroSettings>) };
        setSettings(stored);
        setSecondsLeft(stored.focusMinutes * 60);
      } catch {
        // ignore corrupt settings
      }
    });
  }, []);

  const stopTicking = () => {
    if (interval.current) clearInterval(interval.current);
    interval.current = null;
  };

  const updateSettings = useCallback(
    (patch: Partial<PomodoroSettings>) => {
      setSettings((prev) => {
        const next = { ...prev, ...patch };
        AsyncStorage.setItem(STORAGE_KEYS.pomodoroSettings, JSON.stringify(next)).catch(() => {});
        if (status === 'idle') setSecondsLeft(phaseMinutes(phase, next) * 60);
        return next;
      });
    },
    [status, phase],
  );

  const resetTo = useCallback(
    (nextPhase: PomodoroPhase, nextSettings = settings) => {
      stopTicking();
      endsAt.current = null;
      phaseStartedAt.current = null;
      setPhase(nextPhase);
      setStatus('idle');
      setSecondsLeft(phaseMinutes(nextPhase, nextSettings) * 60);
    },
    [settings],
  );

  const start = useCallback(() => {
    if (status === 'running') return;
    const remaining = status === 'paused' ? secondsLeft : phaseMinutes(phase, settings) * 60;
    endsAt.current = Date.now() + remaining * 1000;
    phaseStartedAt.current ??= new Date().toISOString();
    setStatus('running');
    if (phase === 'focus' && settings.ambientSound) {
      soundService.playAmbient(settings.ambientSound).catch(() => {});
    }
  }, [status, secondsLeft, phase, settings]);

  const pause = useCallback(() => {
    if (status !== 'running') return;
    stopTicking();
    setStatus('paused');
    soundService.pauseAmbient();
  }, [status]);

  const skip = useCallback(() => {
    soundService.stopAmbient();
    if (phase === 'focus') {
      const rounds = completedRounds + 1;
      setCompletedRounds(rounds);
      resetTo(rounds % settings.roundsBeforeLongBreak === 0 ? 'long_break' : 'short_break');
    } else {
      resetTo('focus');
    }
  }, [phase, completedRounds, settings.roundsBeforeLongBreak, resetTo]);

  const reset = useCallback(() => {
    soundService.stopAmbient();
    resetTo(phase);
  }, [phase, resetTo]);

  const handleComplete = useCallback(() => {
    stopTicking();
    if (settings.soundEnabled) soundService.playChime();
    soundService.stopAmbient();

    if (phase === 'focus') {
      addXP(XP_RULES.focusSessionComplete);
      tasksService
        .logSession(
          {
            taskId,
            startedAt: phaseStartedAt.current ?? new Date().toISOString(),
            durationMinutes: settings.focusMinutes,
            kind: 'focus',
          },
          session?.user.id,
        )
        .catch(() => {});
      const rounds = completedRounds + 1;
      setCompletedRounds(rounds);
      const nextPhase: PomodoroPhase =
        rounds % settings.roundsBeforeLongBreak === 0 ? 'long_break' : 'short_break';
      resetTo(nextPhase);
      if (settings.autoStartBreaks) {
        endsAt.current = Date.now() + phaseMinutes(nextPhase, settings) * 1000 * 60;
        phaseStartedAt.current = new Date().toISOString();
        setStatus('running');
      }
    } else {
      resetTo('focus');
    }
  }, [settings, phase, addXP, taskId, session?.user.id, completedRounds, resetTo]);

  useEffect(() => {
    if (status !== 'running') return;
    const tick = () => {
      if (!endsAt.current) return;
      const remaining = Math.max(0, Math.round((endsAt.current - Date.now()) / 1000));
      setSecondsLeft(remaining);
      if (remaining === 0) handleComplete();
    };
    tick();
    interval.current = setInterval(tick, 250);
    return stopTicking;
  }, [status, handleComplete]);

  useEffect(() => () => soundService.stopAmbient(), []);

  const totalSeconds = phaseMinutes(phase, settings) * 60;

  return {
    settings,
    updateSettings,
    phase,
    status,
    secondsLeft,
    totalSeconds,
    progress: totalSeconds === 0 ? 0 : 1 - secondsLeft / totalSeconds,
    completedRounds,
    start,
    pause,
    skip,
    reset,
    setPhase: (p: PomodoroPhase) => resetTo(p),
  };
}
