import type { ChatMessage, ChatThread } from '@/types';
import { isoFromNow } from '@/utils/date';

export const aiSuggestedPrompts = [
  { icon: 'calculator-outline', label: 'Explain integration by parts with an example' },
  { icon: 'flask-outline', label: 'Why does ice float on water?' },
  { icon: 'book-outline', label: 'Summarize the causes of the Cold War' },
  { icon: 'code-slash-outline', label: 'Walk me through binary search step by step' },
];

/**
 * Canned responses keyed by keyword. Used in production and whenever the local IDE gateway is off.
 * so the chat UI can be developed and demoed offline.
 */
export const mockAIResponses: { match: RegExp; response: string }[] = [
  {
    match: /integrat|parts/i,
    response: `Let's work through **integration by parts** step by step.

**1. The formula**
∫ u dv = uv − ∫ v du

**2. Choose u and dv** (use LIATE: Logs, Inverse trig, Algebraic, Trig, Exponential)
For ∫ x·eˣ dx:
• u = x  →  du = dx
• dv = eˣ dx  →  v = eˣ

**3. Substitute**
∫ x·eˣ dx = x·eˣ − ∫ eˣ dx

**4. Finish the easy integral**
= x·eˣ − eˣ + C
= eˣ(x − 1) + C

**Check:** differentiate eˣ(x − 1) → eˣ(x − 1) + eˣ = x·eˣ ✓

Want to try ∫ x·cos(x) dx yourself? I'll check your work.`,
  },
  {
    match: /ice|float|water/i,
    response: `Great question—this one surprises a lot of people.

**Step 1 · Density decides floating.** An object floats if it is less dense than the liquid around it.

**Step 2 · Water is unusual.** Most substances get denser as they solidify. Water gets *less* dense when it freezes—ice is about 9% less dense than liquid water.

**Step 3 · Why?** Hydrogen bonds. In liquid water, molecules tumble around and pack fairly tightly. When water freezes, hydrogen bonds lock the molecules into a hexagonal lattice with lots of open space.

**Step 4 · The consequence.** Because the lattice is roomier, a given mass of ice takes up more volume → lower density → it floats.

**Why it matters:** Lakes freeze from the top down, insulating the water below so aquatic life survives winter.`,
  },
  {
    match: /cold war/i,
    response: `Here's a compact breakdown of the **causes of the Cold War**:

**1. Ideological clash**
Capitalist democracy (USA) vs. communist one-party state (USSR). Each saw the other's system as a threat.

**2. Wartime distrust**
Stalin resented the delayed D-Day invasion; the West was alarmed by Soviet expansion into Eastern Europe.

**3. Post-war power vacuum**
Germany and Japan were defeated, Britain and France exhausted—leaving two superpowers facing each other.

**4. The atomic bomb**
The US kept the Manhattan Project secret from Stalin, accelerating an arms race.

**5. Key flashpoints (1945–49)**
• Yalta & Potsdam disagreements
• Iron Curtain speech (1946)
• Truman Doctrine & Marshall Plan (1947)
• Berlin Blockade (1948–49)
• NATO formed (1949)

Want me to turn this into flashcards for your Trivia Tower deck?`,
  },
  {
    match: /binary search/i,
    response: `**Binary search** finds a target in a *sorted* array by halving the search space each step.

**Setup:** arr = [3, 8, 15, 23, 42, 57, 91], target = 42

**Step 1** · low = 0, high = 6 → mid = 3 → arr[3] = 23
23 < 42, so the target is to the right → low = 4

**Step 2** · low = 4, high = 6 → mid = 5 → arr[5] = 57
57 > 42, so look left → high = 4

**Step 3** · low = 4, high = 4 → mid = 4 → arr[4] = 42 ✓ Found at index 4.

**Pseudocode**
\`\`\`
while low <= high:
    mid = (low + high) // 2
    if arr[mid] == target: return mid
    if arr[mid] < target: low = mid + 1
    else: high = mid - 1
return -1
\`\`\`

**Complexity:** O(log n) time, O(1) space. Each step discards half the remaining elements.`,
  },
  {
    match: /photo|image|picture|scan/i,
    response: `I can read the problem in your photo. Here's what I see:

**Problem:** Solve 3x + 7 = 22

**Step 1 · Isolate the variable term**
Subtract 7 from both sides → 3x = 15

**Step 2 · Solve for x**
Divide both sides by 3 → x = 5

**Check:** 3(5) + 7 = 15 + 7 = 22 ✓

If any part of the handwriting was misread, tell me the correct equation and I'll redo it.`,
  },
];

export const mockAIFallbackResponse = `Let me break this down step by step.

**1. Identify what's being asked.** Restate the problem in your own words—this catches most misunderstandings early.

**2. List what you know.** Write down the given values, definitions, or facts.

**3. Pick a strategy.** Is there a formula, a pattern, or a similar example from class?

**4. Work it through.** Go one line at a time and label each step.

**5. Check the answer.** Plug it back in, estimate, or test an edge case.

Could you share the specific problem (or a photo of it)? I'll walk through it with you.`;

export const mockOCRText = '3x + 7 = 22';

export const mockThreads: ChatThread[] = [
  {
    id: 'th1',
    title: 'Integration by parts',
    updatedAt: isoFromNow({ hours: -3 }),
    messages: [
      {
        id: 'm1',
        role: 'user',
        content: 'Explain integration by parts with an example',
        createdAt: isoFromNow({ hours: -3, minutes: -2 }),
        status: 'complete',
      },
      {
        id: 'm2',
        role: 'assistant',
        content: mockAIResponses[0]!.response,
        createdAt: isoFromNow({ hours: -3 }),
        status: 'complete',
      },
    ],
  },
  {
    id: 'th2',
    title: 'Why does ice float?',
    updatedAt: isoFromNow({ days: -2 }),
    messages: [],
  },
];

export const aiWelcomeMessage: ChatMessage = {
  id: 'welcome',
  role: 'assistant',
  content:
    "Hi! I'm your homework helper. Ask me anything, or snap a photo of a problem and I'll walk through it step by step.",
  createdAt: new Date().toISOString(),
  status: 'complete',
};
