import type { AmbientSound, PomodoroSettings, StudySession, StudyTask, Subject } from '@/types';
import { isoAt, isoFromNow } from '@/utils/date';

export const mockSubjects: Subject[] = [
  { id: 's_math', name: 'Calculus', color: '#4F46E5', icon: 'calculator-outline' },
  { id: 's_bio', name: 'Biology', color: '#10B981', icon: 'leaf-outline' },
  { id: 's_hist', name: 'History', color: '#F59E0B', icon: 'book-outline' },
  { id: 's_eng', name: 'English', color: '#EC4899', icon: 'create-outline' },
  { id: 's_cs', name: 'Computer Science', color: '#0EA5E9', icon: 'code-slash-outline' },
  { id: 's_chem', name: 'Chemistry', color: '#8B5CF6', icon: 'flask-outline' },
  { id: 's_lang', name: 'Languages', color: '#E55C5C', icon: 'language-outline' },
];

/** Sample tasks for docs / fixtures. The live planner starts empty and persists what the user adds. */
export const mockTasks: StudyTask[] = [
  {
    id: 't1',
    title: 'Integration by parts problem set',
    subjectId: 's_math',
    dueAt: isoAt(16, 0, 0),
    estimatedMinutes: 60,
    completedMinutes: 25,
    priority: 'high',
    status: 'in_progress',
    notes: 'Problems 12–24, skip 19.',
  },
  {
    id: 't2',
    title: 'Read chapter 7: Cellular respiration',
    subjectId: 's_bio',
    dueAt: isoAt(20, 30, 0),
    estimatedMinutes: 45,
    completedMinutes: 0,
    priority: 'medium',
    status: 'todo',
  },
  {
    id: 't3',
    title: 'Outline essay on the Cold War',
    subjectId: 's_hist',
    dueAt: isoAt(9, 0, 1),
    estimatedMinutes: 90,
    completedMinutes: 0,
    priority: 'high',
    status: 'todo',
  },
  {
    id: 't4',
    title: 'Vocabulary flashcards review',
    subjectId: 's_eng',
    dueAt: isoAt(18, 0, 1),
    estimatedMinutes: 20,
    completedMinutes: 0,
    priority: 'low',
    status: 'todo',
  },
  {
    id: 't5',
    title: 'Finish binary tree lab',
    subjectId: 's_cs',
    dueAt: isoAt(23, 59, 2),
    estimatedMinutes: 120,
    completedMinutes: 40,
    priority: 'medium',
    status: 'in_progress',
  },
  {
    id: 't6',
    title: 'Stoichiometry practice quiz',
    subjectId: 's_chem',
    dueAt: isoAt(12, 0, 3),
    estimatedMinutes: 30,
    completedMinutes: 0,
    priority: 'medium',
    status: 'todo',
  },
  {
    id: 't7',
    title: 'Lab report draft',
    subjectId: 's_bio',
    dueAt: isoAt(15, 0, -1),
    estimatedMinutes: 60,
    completedMinutes: 60,
    priority: 'high',
    status: 'done',
  },
  {
    id: 't8',
    title: 'Peer review two essays',
    subjectId: 's_eng',
    dueAt: isoAt(17, 0, 5),
    estimatedMinutes: 40,
    completedMinutes: 0,
    priority: 'low',
    status: 'todo',
  },
];

export const mockSessions: StudySession[] = [
  { id: 'ss1', taskId: 't1', startedAt: isoFromNow({ hours: -2 }), durationMinutes: 25, kind: 'focus' },
  { id: 'ss2', taskId: 't5', startedAt: isoFromNow({ days: -1, hours: -3 }), durationMinutes: 25, kind: 'focus' },
  { id: 'ss3', taskId: 't7', startedAt: isoFromNow({ days: -1, hours: -5 }), durationMinutes: 50, kind: 'focus' },
  { id: 'ss4', taskId: 't1', startedAt: isoFromNow({ days: -2 }), durationMinutes: 25, kind: 'focus' },
  { id: 'ss5', startedAt: isoFromNow({ days: -3 }), durationMinutes: 75, kind: 'focus' },
  { id: 'ss6', startedAt: isoFromNow({ days: -4 }), durationMinutes: 50, kind: 'focus' },
  { id: 'ss7', startedAt: isoFromNow({ days: -5 }), durationMinutes: 25, kind: 'focus' },
  { id: 'ss8', startedAt: isoFromNow({ days: -6 }), durationMinutes: 100, kind: 'focus' },
];

export const defaultPomodoroSettings: PomodoroSettings = {
  focusMinutes: 25,
  shortBreakMinutes: 5,
  longBreakMinutes: 15,
  roundsBeforeLongBreak: 4,
  autoStartBreaks: true,
  soundEnabled: true,
  ambientSound: null,
};

export const ambientSounds: AmbientSound[] = [
  { id: 'rain', label: 'Rain', icon: 'rainy-outline' },
  { id: 'cafe', label: 'Café', icon: 'cafe-outline' },
  { id: 'forest', label: 'Forest', icon: 'leaf-outline' },
  { id: 'white_noise', label: 'White noise', icon: 'radio-outline' },
  { id: 'lofi', label: 'Lo-fi', icon: 'musical-notes-outline' },
];

export const pomodoroPresets = [
  { label: 'Classic', focus: 25, short: 5, long: 15 },
  { label: 'Deep work', focus: 50, short: 10, long: 30 },
  { label: 'Sprint', focus: 15, short: 3, long: 10 },
] as const;
