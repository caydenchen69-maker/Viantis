import type { LeaderboardEntry, UserProfile, XPEvent } from '@/types';
import { isoFromNow } from '@/utils/date';

/** Fictional student used only in community / leaderboard demo content. */
export const mockUser: UserProfile = {
  id: 'u_me',
  username: 'maya.k',
  displayName: 'Maya',
  avatar: { background: '#E0E7FF', frame: 'silver' },
  xp: 3260,
  level: 6,
  streakDays: 12,
  longestStreak: 21,
  joinedAt: '2026-01-14T09:00:00.000Z',
};

/** Empty local profile for a first-time guest. Nothing is pre-filled. */
export const freshGuestProfile = (): UserProfile => ({
  id: 'u_guest',
  username: '',
  displayName: '',
  avatar: { background: '#CFFAFE' },
  xp: 0,
  level: 1,
  streakDays: 0,
  longestStreak: 0,
  joinedAt: new Date().toISOString(),
});

/** True when storage still holds the old seeded Maya demo, not a real user. */
export const isSeededDemoProfile = (profile: Partial<UserProfile> | null | undefined) =>
  Boolean(
    profile &&
      profile.username === 'maya.k' &&
      profile.displayName === 'Maya' &&
      (profile.xp === 3260 || profile.streakDays === 12),
  );

export const leaderboardWithGuest = (
  entries: LeaderboardEntry[],
  profile: UserProfile | null | undefined,
): LeaderboardEntry[] => {
  const others = entries.filter((e) => !e.isCurrentUser && e.user.id !== profile?.id);
  if (!profile) return others.map((e, i) => ({ ...e, rank: i + 1 }));
  const me: LeaderboardEntry = {
    rank: 0,
    xp: profile.xp,
    isCurrentUser: true,
    user: {
      id: profile.id,
      username: profile.username || 'guest',
      displayName: profile.displayName || 'You',
      avatar: profile.avatar,
      level: profile.level,
    },
  };
  return [...others, me]
    .sort((a, b) => b.xp - a.xp || a.user.displayName.localeCompare(b.user.displayName))
    .map((e, i) => ({ ...e, rank: i + 1 }));
};

export const mockXPHistory: XPEvent[] = [
  { id: 'xp1', amount: 25, reason: 'Focus session · Calculus', createdAt: isoFromNow({ hours: -2 }) },
  { id: 'xp2', amount: 15, reason: 'Trivia Tower · 8 floors', createdAt: isoFromNow({ hours: -5 }) },
  { id: 'xp3', amount: 40, reason: 'Completed "Lab report draft"', createdAt: isoFromNow({ days: -1 }) },
  { id: 'xp4', amount: 20, reason: 'Daily streak bonus', createdAt: isoFromNow({ days: -1 }) },
];

const avatar = (background: string) => ({ background });

export const mockGlobalLeaderboard: LeaderboardEntry[] = [
  { rank: 1, xp: 12840, user: { id: 'u1', username: 'quantumleap', displayName: 'Priya', level: 14, avatar: avatar('#FEE2E2') } },
  { rank: 2, xp: 11205, user: { id: 'u2', username: 'noahwrites', displayName: 'Noah', level: 13, avatar: avatar('#FEF3C7') } },
  { rank: 3, xp: 9870, user: { id: 'u3', username: 'sofia.m', displayName: 'Sofia', level: 12, avatar: avatar('#DCFCE7') }, isFriend: true },
  { rank: 4, xp: 8455, user: { id: 'u4', username: 'kaito', displayName: 'Kaito', level: 11, avatar: avatar('#E0F2FE') } },
  { rank: 5, xp: 7630, user: { id: 'u5', username: 'amara_b', displayName: 'Amara', level: 10, avatar: avatar('#F3E8FF') }, isFriend: true },
  { rank: 6, xp: 6120, user: { id: 'u6', username: 'leo.codes', displayName: 'Leo', level: 9, avatar: avatar('#F1F5F9') } },
  { rank: 7, xp: 5340, user: { id: 'u7', username: 'zara', displayName: 'Zara', level: 8, avatar: avatar('#FCE7F3') }, isFriend: true },
  { rank: 8, xp: 4210, user: { id: 'u8', username: 'dev.dan', displayName: 'Daniel', level: 7, avatar: avatar('#ECFDF5') } },
  { rank: 9, xp: 3260, user: { id: 'u_me', username: 'maya.k', displayName: 'Maya', level: 6, avatar: avatar('#E0E7FF') } },
  { rank: 10, xp: 2980, user: { id: 'u9', username: 'ellie', displayName: 'Ellie', level: 6, avatar: avatar('#FFF7ED') }, isFriend: true },
];

export const mockFriendsLeaderboard: LeaderboardEntry[] = mockGlobalLeaderboard
  .filter((e) => e.isFriend || e.isCurrentUser)
  .map((e, i) => ({ ...e, rank: i + 1 }));
