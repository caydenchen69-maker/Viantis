import type { ArcadeGame, Deck, Flashcard, QuizQuestion } from '@/types';
import { isoFromNow } from '@/utils/date';

export const mockGames: ArcadeGame[] = [
  {
    id: 'space_shooter',
    title: 'Space Shooter',
    tagline: 'Blast the right answer',
    description:
      'Asteroids carry possible answers. Shoot the correct one before it reaches your ship. Combos multiply your XP.',
    icon: 'rocket-outline',
    tint: 'sky',
    bestScore: 4820,
    xpPerRound: 15,
    durationLabel: '~3 min',
  },
  {
    id: 'flashcard_match',
    title: 'Flashcard Match',
    tagline: 'Pair terms with definitions',
    description:
      'A memory grid built from your decks. Flip cards to match each term with its definition against the clock.',
    icon: 'grid-outline',
    tint: 'indigo',
    bestScore: 2150,
    xpPerRound: 15,
    durationLabel: '~2 min',
  },
  {
    id: 'trivia_tower',
    title: 'Trivia Tower',
    tagline: 'Climb with every correct answer',
    description:
      'Each correct answer adds a floor. One wrong answer and the tower shakes—two and it topples. How high can you go?',
    icon: 'business-outline',
    tint: 'amber',
    bestScore: 14,
    xpPerRound: 20,
    durationLabel: '~4 min',
  },
];

export const mockDecks: Deck[] = [
  { id: 'd_bio7', title: 'Bio Ch. 7 · Cellular respiration', subjectId: 's_bio', cardCount: 24, lastStudied: isoFromNow({ days: -1 }) },
  { id: 'd_calc', title: 'Calculus · Integration rules', subjectId: 's_math', cardCount: 18, lastStudied: isoFromNow({ hours: -3 }) },
  { id: 'd_vocab', title: 'SAT Vocabulary · Set 3', subjectId: 's_eng', cardCount: 40, lastStudied: isoFromNow({ days: -4 }) },
  { id: 'd_hist', title: 'Cold War · Key events', subjectId: 's_hist', cardCount: 30 },
];

export const mockFlashcards: Flashcard[] = [
  { id: 'f1', deckId: 'd_bio7', front: 'Glycolysis', back: 'Breakdown of glucose into two pyruvate molecules in the cytoplasm' },
  { id: 'f2', deckId: 'd_bio7', front: 'Krebs cycle', back: 'Series of reactions in the mitochondrial matrix producing NADH, FADH₂ and CO₂' },
  { id: 'f3', deckId: 'd_bio7', front: 'ATP synthase', back: 'Enzyme that produces ATP using the proton gradient across the inner membrane' },
  { id: 'f4', deckId: 'd_bio7', front: 'Electron transport chain', back: 'Protein complexes passing electrons to oxygen, pumping protons' },
  { id: 'f5', deckId: 'd_bio7', front: 'Fermentation', back: 'Anaerobic pathway regenerating NAD⁺ so glycolysis can continue' },
  { id: 'f6', deckId: 'd_bio7', front: 'Mitochondrial matrix', back: 'Innermost compartment of the mitochondrion where the Krebs cycle occurs' },
  { id: 'f7', deckId: 'd_calc', front: '∫ xⁿ dx', back: 'xⁿ⁺¹ / (n + 1) + C, for n ≠ −1' },
  { id: 'f8', deckId: 'd_calc', front: '∫ eˣ dx', back: 'eˣ + C' },
  { id: 'f9', deckId: 'd_calc', front: '∫ 1/x dx', back: 'ln|x| + C' },
  { id: 'f10', deckId: 'd_calc', front: 'Integration by parts', back: '∫ u dv = uv − ∫ v du' },
  { id: 'f11', deckId: 'd_vocab', front: 'Ephemeral', back: 'Lasting for a very short time' },
  { id: 'f12', deckId: 'd_vocab', front: 'Ubiquitous', back: 'Present or found everywhere' },
  { id: 'f13', deckId: 'd_vocab', front: 'Pragmatic', back: 'Dealing with things sensibly and realistically' },
  { id: 'f14', deckId: 'd_vocab', front: 'Candor', back: 'The quality of being open and honest' },
];

export const mockQuizQuestions: QuizQuestion[] = [
  {
    id: 'q1',
    prompt: 'Where does glycolysis take place?',
    choices: ['Mitochondrial matrix', 'Cytoplasm', 'Nucleus', 'Inner membrane'],
    answerIndex: 1,
    explanation: 'Glycolysis occurs in the cytoplasm and does not require oxygen.',
  },
  {
    id: 'q2',
    prompt: 'What is the derivative of ln(x)?',
    choices: ['1/x', 'x', 'eˣ', 'ln(x)/x'],
    answerIndex: 0,
  },
  {
    id: 'q3',
    prompt: 'The Berlin Wall fell in which year?',
    choices: ['1985', '1987', '1989', '1991'],
    answerIndex: 2,
    explanation: 'The wall opened on 9 November 1989, two years before the USSR dissolved.',
  },
  {
    id: 'q4',
    prompt: '"Ubiquitous" most nearly means:',
    choices: ['Rare', 'Everywhere', 'Ancient', 'Hidden'],
    answerIndex: 1,
  },
  {
    id: 'q5',
    prompt: 'Which molecule is the final electron acceptor in aerobic respiration?',
    choices: ['NAD⁺', 'Water', 'Oxygen', 'Carbon dioxide'],
    answerIndex: 2,
  },
  {
    id: 'q6',
    prompt: 'Time complexity of binary search on a sorted array:',
    choices: ['O(n)', 'O(log n)', 'O(n log n)', 'O(1)'],
    answerIndex: 1,
  },
  {
    id: 'q7',
    prompt: 'Balance: __ H₂ + O₂ → __ H₂O',
    choices: ['1, 1', '2, 2', '2, 1', '1, 2'],
    answerIndex: 1,
    explanation: '2H₂ + O₂ → 2H₂O balances four hydrogens and two oxygens on each side.',
  },
  {
    id: 'q8',
    prompt: '∫ eˣ dx equals:',
    choices: ['eˣ + C', 'xeˣ + C', 'eˣ / x + C', 'ln(x) + C'],
    answerIndex: 0,
  },
];
