export type LegalDocId = 'accessibility' | 'privacy' | 'terms' | 'cookies' | 'community';

export interface LegalSection {
  heading: string;
  paragraphs: string[];
  bullets?: string[];
}

export interface LegalDocument {
  id: LegalDocId;
  title: string;
  updated: string;
  intro: string;
  sections: LegalSection[];
}

export const LEGAL_UPDATED = '6 September 2026';
export const LEGAL_CONTACT = 'hello@viantis.app';
export const A11Y_CONTACT = 'accessibility@viantis.app';
export const PRIVACY_CONTACT = 'privacy@viantis.app';

export const legalDocs: Record<LegalDocId, LegalDocument> = {
  accessibility: {
    id: 'accessibility',
    title: 'Accessibility statement',
    updated: LEGAL_UPDATED,
    intro:
      'Viantis is a study companion for web, iOS and Android. We want students to plan, practise and take part regardless of ability. This statement describes our current accessibility approach, known limits, and how to ask for help.',
    sections: [
      {
        heading: 'Standard we aim for',
        paragraphs: [
          'We design Viantis to meet the Web Content Accessibility Guidelines (WCAG) 2.2 at Level AA, and to work with the accessibility features of iOS, Android and modern desktop browsers.',
        ],
        bullets: [
          'Text can be resized and stays readable in light and dark themes.',
          'Primary actions have visible labels, not colour alone.',
          'Interactive controls expose accessibility roles, names and states (tabs, buttons, checkboxes, progress).',
          'A keyboard or switch user can reach Settings, legal pages and the main tabs on the web build.',
        ],
      },
      {
        heading: 'What works today',
        paragraphs: [
          'Screen readers can announce tab names, planner tasks, form labels (including Front and Back when you build a deck), and most buttons. Dark mode, larger system text and Reduce Motion on the device are respected where the platform allows.',
        ],
      },
      {
        heading: 'Known limits',
        paragraphs: [
          'We are still improving some areas. They do not block core studying, but they may be harder with assistive technology:',
        ],
        bullets: [
          'Arcade games use short timers and a memory grid that can be difficult for some motor or cognitive needs. You can leave a round at any time.',
          'The School Finder map on the web is a schematic plot, not a fully labelled geographic map.',
          'AI Helper demo replies are not a substitute for human tutoring or official school accommodations.',
          'Some campus photographs are decorative; we provide text captions where the image carries meaning.',
        ],
      },
      {
        heading: 'Compatible tools',
        paragraphs: [
          'We test with VoiceOver (iOS/macOS), TalkBack (Android), and keyboard navigation in current Chrome, Safari, Firefox and Edge. We also check colour contrast on the sky-and-teal theme.',
        ],
      },
      {
        heading: 'Feedback and accommodations',
        paragraphs: [
          `If something is hard to use, or you need the information in another format, email ${A11Y_CONTACT}. Please include the page or screen, the device and assistive technology you use, and what you expected to happen.`,
          'We aim to reply within ten business days. Feedback about barriers is never used for marketing.',
        ],
      },
      {
        heading: 'Formal complaints',
        paragraphs: [
          'If you are not satisfied with our response, you may also contact your local education accessibility office or, in the United States, the U.S. Department of Education Office for Civil Rights, or file a complaint under applicable disability rights law.',
        ],
      },
    ],
  },
  privacy: {
    id: 'privacy',
    title: 'Privacy policy',
    updated: LEGAL_UPDATED,
    intro:
      'This policy explains what Viantis collects, why, and the choices you have. It applies to the Viantis app and website. We do not sell personal information.',
    sections: [
      {
        heading: 'Who we are',
        paragraphs: [
          `Viantis (“we”) provides a study planner, flashcard arcade, school finder, community feed and an optional homework helper. Questions: ${PRIVACY_CONTACT}.`,
        ],
      },
      {
        heading: 'Guest mode (default)',
        paragraphs: [
          'If you do not create an account, Viantis stores your profile name, tasks, focus sessions, custom decks, helper drafts and theme on this device or browser only (local storage). That data does not leave your device unless you later sign in to a configured cloud project, or you choose to upload a photo to the helper on a development build.',
          'A brand-new guest starts with an empty calendar and no assumed school or streak. Clearing site data or uninstalling the app deletes this local copy.',
        ],
      },
      {
        heading: 'If you create an account',
        paragraphs: [
          'When a school or operator enables cloud sync, we may store your email, display name, username, schedule, study sessions, decks, XP, posts, comments and chat messages on that operator’s Supabase project so you can sign in on another device. Access is limited by account login and row-level security. You can ask for deletion of your account data via the contact address above.',
        ],
      },
      {
        heading: 'Information we process',
        paragraphs: [],
        bullets: [
          'Account and profile: name, username, optional school, avatar colour, XP and streak.',
          'Study activity: tasks, due times, focus sessions, custom flashcards.',
          'Community: posts, comments, votes, reports and lounge messages you send.',
          'School Finder: search filters. Location is used only if you allow it, to sort nearby campuses, and is not required.',
          'AI Helper: prompts and optional photos you send. On the public website the helper uses on-device demo replies and does not call a language-model provider. A live model is only used from a local development gateway on the author’s machine.',
          'Device: theme preference and basic technical logs needed to keep the service running.',
        ],
      },
      {
        heading: 'What we do not do',
        paragraphs: [
          'We do not sell your personal information, do not use it for cross-context advertising, and do not require an account to try the planner. We do not ask for payment card numbers in this version.',
        ],
      },
      {
        heading: 'Sharing',
        paragraphs: [
          'Community posts and school reviews are visible to other people using Viantis. Moderators may remove content that breaks the community guidelines. If cloud sync is enabled, the operator’s infrastructure provider processes data under their terms solely to host the service.',
        ],
      },
      {
        heading: 'Retention',
        paragraphs: [
          'Guest data stays until you clear it. Account data is kept while the account is active and for a short period afterward if needed for security or legal reasons. You can delete tasks, decks and posts yourself in the app.',
        ],
      },
      {
        heading: 'Children',
        paragraphs: [
          'Viantis is intended for students aged 13 and older. If you are under 13, do not create an account. If you are between 13 and 17, use Viantis with a parent or guardian’s permission. We do not knowingly collect personal information from children under 13. If you believe we have, contact us and we will delete it.',
        ],
      },
      {
        heading: 'Your rights',
        paragraphs: [
          'Depending on where you live (including the EEA, UK and certain U.S. states), you may have the right to access, correct, delete, export or restrict use of your personal information, or to object to certain processing. Email the privacy address above. You may also lodge a complaint with your local data protection authority.',
        ],
      },
      {
        heading: 'Security',
        paragraphs: [
          'We use account authentication and access rules when cloud sync is on, and we keep provider keys off the public website. No method of transmission is perfectly secure. Do not post passwords or exam materials you are not allowed to share.',
        ],
      },
      {
        heading: 'Changes',
        paragraphs: [
          `We will update the date at the top of this page when the policy changes. Continued use after an update means you accept the revised policy. Last updated ${LEGAL_UPDATED}.`,
        ],
      },
    ],
  },
  terms: {
    id: 'terms',
    title: 'Terms of use',
    updated: LEGAL_UPDATED,
    intro:
      'These terms govern your use of Viantis. By opening the app or website you agree to them. If you do not agree, do not use Viantis.',
    sections: [
      {
        heading: 'The service',
        paragraphs: [
          'Viantis offers planning tools, study games, a school directory, a student community and an optional writing helper. Features may differ by device. Some data stays on your device in guest mode. Cloud sign-in is optional and only available when an operator has configured it.',
        ],
      },
      {
        heading: 'Eligibility',
        paragraphs: [
          'You must be at least 13 years old. If you are under 18, you confirm a parent or guardian consents to these terms. Schools and districts that deploy Viantis are responsible for obtaining any extra consents their policies require.',
        ],
      },
      {
        heading: 'Your content and licence',
        paragraphs: [
          'You keep ownership of tasks, decks, posts and messages you create. You grant Viantis a limited licence to store and display that content so the service can function (for example, showing your post in the community feed). You must have the right to post what you share and must not upload others’ copyrighted homework keys or private student records.',
        ],
      },
      {
        heading: 'Acceptable use',
        paragraphs: [
          'Do not harass others, post illegal or sexually explicit content involving minors, attempt to break into accounts, scrape the service in a way that harms it, or use the helper to cheat when your school forbids it. We may remove content or suspend access that violates these terms or the community guidelines.',
        ],
      },
      {
        heading: 'Homework helper',
        paragraphs: [
          'Helper output can be wrong. You are responsible for checking work against your own notes and your school’s academic-integrity rules. On the public website the helper uses demo responses and does not send your prompts to an external model.',
        ],
      },
      {
        heading: 'No academic or professional advice',
        paragraphs: [
          'School listings, acceptance-rate figures and community tips are for information only. They are not admissions counselling, legal advice or a guarantee of any outcome.',
        ],
      },
      {
        heading: 'Disclaimers',
        paragraphs: [
          'Viantis is provided “as is”. We do not warrant uninterrupted service, perfect accuracy of school data, or that the arcade or timers will meet a particular accessibility need. To the fullest extent allowed by law, we are not liable for lost work, lost grades, or indirect damages arising from use of the service. Some places do not allow these limits; in those places our liability is limited to what the law requires.',
        ],
      },
      {
        heading: 'Changes and termination',
        paragraphs: [
          'We may update the product or these terms. The date at the top will change when we do. You may stop using Viantis at any time and delete local data by clearing the site or uninstalling. We may stop offering a feature with reasonable notice where we can.',
        ],
      },
      {
        heading: 'Contact',
        paragraphs: [`Questions about these terms: ${LEGAL_CONTACT}.`],
      },
    ],
  },
  cookies: {
    id: 'cookies',
    title: 'Cookie and local storage notice',
    updated: LEGAL_UPDATED,
    intro:
      'Viantis uses on-device storage so your work survives a refresh. We do not use advertising or cross-site tracking cookies.',
    sections: [
      {
        heading: 'What we store on your device',
        paragraphs: [
          'The website and app use the platform’s local storage (and similar technologies) for:',
        ],
        bullets: [
          'Theme (light, dark or system).',
          'Guest profile, tasks, focus sessions and decks you create.',
          'Helper mode and any draft you leave in Composer.',
          'Pomodoro timer preferences.',
          'Signed-in session tokens, only if cloud login is configured.',
        ],
      },
      {
        heading: 'Why',
        paragraphs: [
          'These are strictly necessary or functional. Without them, a new visit would look empty every time and your theme would reset. We do not set third-party marketing cookies and we do not run advertising networks.',
        ],
      },
      {
        heading: 'Your choices',
        paragraphs: [
          'You can clear site data in your browser or uninstall the app. That deletes guest study data on that device. Blocking all storage may keep you on a blank guest state after every reload.',
        ],
      },
      {
        heading: 'More detail',
        paragraphs: [`See the Privacy policy for what we collect and why. Contact ${PRIVACY_CONTACT}.`],
      },
    ],
  },
  community: {
    id: 'community',
    title: 'Community guidelines',
    updated: LEGAL_UPDATED,
    intro:
      'The feed, comments and study lounge are for students helping students. Follow these rules so the space stays usable.',
    sections: [
      {
        heading: 'Be useful',
        paragraphs: [
          'Share study tactics, honest school impressions and questions you would be comfortable showing a teacher. Credit sources. Do not post full copyrighted textbooks or live exam papers.',
        ],
      },
      {
        heading: 'Be decent',
        paragraphs: [
          'No harassment, hate, threats, or sexual content involving anyone 17 or under. Do not out someone’s grades, disability, or private contact details.',
        ],
      },
      {
        heading: 'No cheating rings',
        paragraphs: [
          'Do not ask for or sell completed graded work, test banks you do not have rights to, or ways to bypass school integrity tools.',
        ],
      },
      {
        heading: 'Moderation',
        paragraphs: [
          'Use report controls when you see a problem. Moderators may hide or remove posts and comments. Repeated harm can lead to a ban. These guidelines sit alongside the Terms of use.',
        ],
      },
    ],
  },
};

export const isLegalDocId = (value: string | undefined): value is LegalDocId =>
  Boolean(value && value in legalDocs);

export const legalIndex: { id: LegalDocId; title: string; blurb: string }[] = [
  { id: 'accessibility', title: 'Accessibility', blurb: 'How Viantis works with assistive technology' },
  { id: 'privacy', title: 'Privacy', blurb: 'What we store and what we do not sell' },
  { id: 'terms', title: 'Terms of use', blurb: 'Rules for using the planner, arcade and community' },
  { id: 'cookies', title: 'Cookies & storage', blurb: 'Local data only — no ad tracking' },
  { id: 'community', title: 'Community guidelines', blurb: 'How to post in the feed and lounge' },
];
