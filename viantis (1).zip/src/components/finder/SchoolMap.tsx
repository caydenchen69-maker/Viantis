import React, { useEffect, useRef } from 'react';
import { View } from 'react-native';
import MapView, { Marker } from 'react-native-maps';

import { Text } from '@/components/ui';
import { palette } from '@/constants/theme';
import { useTheme } from '@/providers/ThemeProvider';
import type { LatLng } from '@/services';
import type { School } from '@/types';

export interface SchoolMapProps {
  schools: School[];
  origin: LatLng | null;
  selectedId?: string;
  onSelect: (school: School) => void;
  height?: number;
}

const typeColor: Record<School['type'], string> = {
  university: palette.coral[500],
  high_school: palette.charcoal[900],
  community_college: palette.gray[500],
};

export function SchoolMap({ schools, origin, selectedId, onSelect, height = 260 }: SchoolMapProps) {
  const { isDark } = useTheme();
  const mapRef = useRef<MapView>(null);
  const center = origin ?? schools[0]?.coordinates ?? { latitude: 0, longitude: 0 };

  useEffect(() => {
    if (!schools.length) return;
    mapRef.current?.fitToCoordinates(
      [...schools.map((s) => s.coordinates), ...(origin ? [origin] : [])],
      { edgePadding: { top: 40, right: 40, bottom: 40, left: 40 }, animated: true },
    );
  }, [schools, origin]);

  return (
    <View className="overflow-hidden rounded-2xl border border-line dark:border-line-dark" style={{ height }}>
      <MapView
        ref={mapRef}
        style={{ flex: 1 }}
        userInterfaceStyle={isDark ? 'dark' : 'light'}
        initialRegion={{ ...center, latitudeDelta: 0.15, longitudeDelta: 0.15 }}
        showsUserLocation
        showsPointsOfInterests={false}
      >
        {schools.map((s) => (
          <Marker
            key={s.id}
            coordinate={s.coordinates}
            title={s.name}
            description={`${s.rating.toFixed(1)} ★ · ${s.city}`}
            pinColor={typeColor[s.type]}
            opacity={selectedId && selectedId !== s.id ? 0.6 : 1}
            onPress={() => onSelect(s)}
          />
        ))}
      </MapView>
      <View className="absolute bottom-2 left-2 flex-row gap-2 rounded-full bg-surface/90 px-3 py-1.5 dark:bg-surface-dark/90">
        {(Object.keys(typeColor) as School['type'][]).map((t) => (
          <View key={t} className="flex-row items-center gap-1">
            <View className="h-2 w-2 rounded-full" style={{ backgroundColor: typeColor[t] }} />
            <Text variant="caption" tone="muted" className="text-[11px]">
              {t === 'high_school' ? 'High school' : t === 'university' ? 'University' : 'College'}
            </Text>
          </View>
        ))}
      </View>
    </View>
  );
}
