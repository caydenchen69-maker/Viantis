import React from 'react';
import { Pressable, View } from 'react-native';

import { Text } from '@/components/ui';
import { palette } from '@/constants/theme';
import type { School, SchoolType } from '@/types';
import { formatPercent } from '@/utils/format';
import { schoolCompatibility, schoolInstitutionId } from '@/utils/schoolMeta';

export const schoolTypeLabel: Record<SchoolType, string> = {
  high_school: 'High school',
  university: 'University',
  community_college: 'Community college',
};

interface Props {
  school: School;
  onPress: (school: School) => void;
}

/** Cream dossier card: institution id, serif name, SAT / acceptance grid. */
export function SchoolCard({ school, onPress }: Props) {
  const match = schoolCompatibility(school);
  const sat =
    school.satAverage != null
      ? String(school.satAverage)
      : school.type === 'community_college'
        ? '—'
        : '—';

  return (
    <Pressable
      onPress={() => onPress(school)}
      accessibilityRole="button"
      className="active:opacity-92"
      style={{
        backgroundColor: palette.cream[100],
        borderRadius: 8,
        overflow: 'hidden',
      }}
    >
      <View className="absolute right-0 top-0 px-3 py-1.5" style={{ backgroundColor: palette.coral[500] }}>
        <Text
          variant="overline"
          style={{ color: '#FFFFFF', fontSize: 10, letterSpacing: 1.1, lineHeight: 14 }}
        >
          {match}% Compatibility
        </Text>
      </View>

      <View className="px-5 pb-5 pt-8">
        <Text variant="overline" style={{ color: palette.coral[500], letterSpacing: 1.2 }}>
          Institution ID: {schoolInstitutionId(school)}
        </Text>
        <Text
          variant="heading"
          numberOfLines={2}
          style={{ color: '#111111', fontSize: 28, lineHeight: 32, letterSpacing: -0.4, marginTop: 8 }}
        >
          {school.name}
        </Text>
        <Text variant="caption" style={{ color: '#6B6862', marginTop: 6 }}>
          {schoolTypeLabel[school.type]} · {school.city}, {school.region}
        </Text>

        <View style={{ height: 1, backgroundColor: '#E4DDD2', marginTop: 18, marginBottom: 16 }} />

        <View className="flex-row">
          <Stat label="Avg SAT score" value={sat} />
          <Stat label="Acceptance rate" value={formatPercent(school.acceptanceRate, 1)} />
        </View>
      </View>
    </Pressable>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <View className="flex-1">
      <Text variant="overline" style={{ color: '#8A8780', letterSpacing: 1.1 }}>
        {label}
      </Text>
      <Text variant="heading" style={{ color: '#111111', fontSize: 28, lineHeight: 32, marginTop: 4 }}>
        {value}
      </Text>
    </View>
  );
}
