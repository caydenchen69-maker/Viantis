import React, { useMemo, useState } from 'react';
import { Pressable, View, type LayoutChangeEvent } from 'react-native';

import { Text } from '@/components/ui';
import { useTheme } from '@/providers/ThemeProvider';

import type { SchoolMapProps } from './SchoolMap';

/**
 * Web fallback: react-native-maps has no web renderer, so we plot the results
 * schematically on a plain panel using their real coordinates. Swap in a
 * Leaflet/MapLibre view here when a web map is needed.
 */
export function SchoolMap({ schools, origin, selectedId, onSelect, height = 220 }: SchoolMapProps) {
  const { colors } = useTheme();
  const [width, setWidth] = useState(0);

  const points = useMemo(() => {
    const all = [...schools.map((s) => s.coordinates), ...(origin ? [origin] : [])];
    if (!all.length) return [];
    const lats = all.map((c) => c.latitude);
    const lngs = all.map((c) => c.longitude);
    const pad = 0.12;
    const minLat = Math.min(...lats), maxLat = Math.max(...lats);
    const minLng = Math.min(...lngs), maxLng = Math.max(...lngs);
    const spanLat = maxLat - minLat;
    const spanLng = maxLng - minLng;
    // Leave room at the bottom for the caption row; a single point sits centred.
    const project = (c: { latitude: number; longitude: number }) => ({
      x: spanLng < 0.001 ? 0.5 : pad + ((c.longitude - minLng) / spanLng) * (1 - pad * 2),
      y: spanLat < 0.001 ? 0.42 : 0.08 + (1 - (c.latitude - minLat) / spanLat) * 0.68,
    });
    return [
      ...schools.map((s) => ({ id: s.id, school: s, ...project(s.coordinates) })),
      ...(origin ? [{ id: '__origin', school: null, ...project(origin) }] : []),
    ];
  }, [schools, origin]);

  const selected = schools.find((s) => s.id === selectedId);

  return (
    <View
      onLayout={(e: LayoutChangeEvent) => setWidth(e.nativeEvent.layout.width)}
      className="overflow-hidden rounded-2xl bg-surface-muted dark:bg-surface-muted-dark"
      style={{ height }}
    >
      {width > 0 &&
        points.map((p) =>
          p.school ? (
            <Pressable
              key={p.id}
              onPress={() => onSelect(p.school!)}
              hitSlop={10}
              accessibilityLabel={p.school.name}
              className="absolute items-center justify-center"
              style={{ left: p.x * width - 8, top: p.y * height - 8, width: 16, height: 16 }}
            >
              <View
                className="rounded-full"
                style={{
                  width: p.id === selectedId ? 12 : 8,
                  height: p.id === selectedId ? 12 : 8,
                  backgroundColor: p.id === selectedId ? colors.primary : colors.ink,
                  opacity: p.id === selectedId ? 1 : 0.7,
                }}
              />
            </Pressable>
          ) : (
            <View
              key={p.id}
              className="absolute h-4 w-4 items-center justify-center rounded-full border border-primary-600"
              style={{ left: p.x * width - 8, top: p.y * height - 8 }}
            >
              <View className="h-1.5 w-1.5 rounded-full bg-primary-600" />
            </View>
          ),
        )}
      <View className="absolute bottom-3 left-3 right-3 flex-row items-end justify-between">
        <Text variant="caption" tone="muted">
          {selected ? selected.name : schools.length === 1 ? `${schools[0]!.city}, ${schools[0]!.region}` : `${schools.length} schools plotted`}
        </Text>
        <Text variant="caption" tone="subtle">
          Full map on iOS and Android
        </Text>
      </View>
    </View>
  );
}
