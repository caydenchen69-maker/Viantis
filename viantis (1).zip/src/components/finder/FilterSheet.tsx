import React from 'react';
import { Modal, Pressable, ScrollView, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Button, Chip, Text } from '@/components/ui';
import { popularMajors } from '@/data';
import { defaultSchoolFilters } from '@/services';
import type { SchoolFilters, SchoolType } from '@/types';

import { schoolTypeLabel } from './SchoolCard';

interface Props {
  visible: boolean;
  filters: SchoolFilters;
  onChange: (filters: SchoolFilters) => void;
  onClose: () => void;
  resultCount: number;
}

const acceptanceOptions = [
  { label: 'Any', value: null },
  { label: '≤ 10%', value: 0.1 },
  { label: '≤ 25%', value: 0.25 },
  { label: '≤ 50%', value: 0.5 },
  { label: '≤ 75%', value: 0.75 },
];
const ratingOptions = [
  { label: 'Any', value: null },
  { label: '4.0+', value: 4 },
  { label: '4.5+', value: 4.5 },
];
const radiusOptions = [5, 10, 25, 50, 100];

export function FilterSheet({ visible, filters, onChange, onClose, resultCount }: Props) {
  const insets = useSafeAreaInsets();
  const toggleType = (type: SchoolType) =>
    onChange({
      ...filters,
      types: filters.types.includes(type) ? filters.types.filter((t) => t !== type) : [...filters.types, type],
    });
  const toggleMajor = (major: string) =>
    onChange({
      ...filters,
      majors: filters.majors.includes(major) ? filters.majors.filter((m) => m !== major) : [...filters.majors, major],
    });

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <View className="flex-1 bg-canvas dark:bg-canvas-dark" style={{ paddingTop: insets.top || 16 }}>
        <View className="flex-row items-center justify-between px-5 pb-3">
          <Pressable onPress={() => onChange({ ...defaultSchoolFilters, query: filters.query })} hitSlop={8}>
            <Text variant="label" tone="muted">
              Reset
            </Text>
          </Pressable>
          <Text variant="heading">Filters</Text>
          <Pressable onPress={onClose} hitSlop={8}>
            <Text variant="label" tone="primary">
              Done
            </Text>
          </Pressable>
        </View>

        <ScrollView contentContainerClassName="px-5 pb-32" showsVerticalScrollIndicator={false}>
          <Section title="School type">
            {(Object.keys(schoolTypeLabel) as SchoolType[]).map((t) => (
              <Chip key={t} label={schoolTypeLabel[t]} selected={filters.types.includes(t)} onPress={() => toggleType(t)} />
            ))}
          </Section>

          <Section title="Majors & programs">
            {popularMajors.map((m) => (
              <Chip key={m} label={m} selected={filters.majors.includes(m)} onPress={() => toggleMajor(m)} />
            ))}
          </Section>

          <Section title="Acceptance rate">
            {acceptanceOptions.map((o) => (
              <Chip
                key={o.label}
                label={o.label}
                selected={filters.maxAcceptanceRate === o.value}
                onPress={() => onChange({ ...filters, maxAcceptanceRate: o.value })}
              />
            ))}
          </Section>

          <Section title="Student rating">
            {ratingOptions.map((o) => (
              <Chip
                key={o.label}
                label={o.label}
                icon={o.value ? 'star' : undefined}
                color="#F59E0B"
                selected={filters.minRating === o.value}
                onPress={() => onChange({ ...filters, minRating: o.value })}
              />
            ))}
          </Section>

          <Section title="Distance">
            {radiusOptions.map((r) => (
              <Chip key={r} label={`${r} km`} selected={filters.radiusKm === r} onPress={() => onChange({ ...filters, radiusKm: r })} />
            ))}
          </Section>
        </ScrollView>

        <View className="absolute inset-x-0 bottom-0 border-t border-line bg-surface px-5 pt-3 dark:border-line-dark dark:bg-surface-dark" style={{ paddingBottom: insets.bottom + 12 }}>
          <Button label={`Show ${resultCount} ${resultCount === 1 ? 'school' : 'schools'}`} size="lg" fullWidth onPress={onClose} />
        </View>
      </View>
    </Modal>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View className="mb-6">
      <Text variant="label" tone="muted" className="mb-2.5">
        {title}
      </Text>
      <View className="flex-row flex-wrap gap-2">{children}</View>
    </View>
  );
}
