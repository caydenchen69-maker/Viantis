import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Pressable, View } from 'react-native';

import { Avatar, PressableCard, Text } from '@/components/ui';
import { useTheme } from '@/providers/ThemeProvider';
import type { Post } from '@/types';
import { cn } from '@/utils/cn';
import { timeAgo } from '@/utils/date';
import { formatCompact } from '@/utils/format';

const kindLabel: Record<Post['kind'], string> = {
  discussion: 'Discussion',
  tip: 'Study tip',
  review: 'School review',
  question: 'Question',
};

interface Props {
  post: Post;
  onPress: (post: Post) => void;
  onVote: (post: Post, direction: 1 | -1) => void;
  onTagPress?: (tag: string) => void;
  expanded?: boolean;
}

export function PostCard({ post, onPress, onVote, onTagPress, expanded = false }: Props) {
  const { colors } = useTheme();
  const upvoted = post.userVote === 1;
  const downvoted = post.userVote === -1;

  return (
    <PressableCard onPress={() => onPress(post)} padding="lg">
      <View className="flex-row items-center gap-2">
        <Avatar avatar={post.author.avatar} name={post.author.displayName} size={22} />
        <Text variant="caption" tone="muted" className="flex-1" numberOfLines={1}>
          <Text variant="caption" weight="medium">
            {post.author.displayName}
          </Text>
          {' · '}
          {timeAgo(post.createdAt)}
          {' · '}
          {kindLabel[post.kind]}
        </Text>
        {post.isPinned && <Ionicons name="pin-outline" size={14} color={colors.inkMuted} />}
        {post.isFlagged && (
          <Text variant="caption" tone="danger">
            Reported
          </Text>
        )}
      </View>

      <Text variant="heading" className="mt-3" style={{ fontSize: 21, lineHeight: 26 }}>
        {post.title}
      </Text>
      <Text
        variant="body"
        tone={expanded ? 'default' : 'muted'}
        className="mt-2"
        numberOfLines={expanded ? undefined : 3}
      >
        {post.body}
      </Text>

      <View className="mt-4 flex-row items-center">
        <Pressable
          onPress={() => onVote(post, 1)}
          hitSlop={8}
          accessibilityLabel="Upvote"
          className="flex-row items-center gap-1 active:opacity-70"
        >
          <Ionicons name="arrow-up" size={16} color={upvoted ? colors.primary : colors.ink} />
          <Text
            variant="label"
            className={cn(
              upvoted && 'text-primary-600 dark:text-primary-400',
              downvoted && 'text-ink-subtle',
            )}
            style={{ fontVariant: ['tabular-nums'] }}
          >
            {formatCompact(post.upvotes)}
          </Text>
        </Pressable>
        <Pressable
          onPress={() => onVote(post, -1)}
          hitSlop={8}
          accessibilityLabel="Downvote"
          className="ml-2 active:opacity-70"
        >
          <Ionicons name="arrow-down" size={16} color={downvoted ? colors.danger : colors.inkSubtle} />
        </Pressable>

        <Text variant="caption" tone="subtle" className="mx-3">
          ·
        </Text>
        <Ionicons name="chatbubble-outline" size={14} color={colors.inkMuted} />
        <Text variant="caption" tone="muted" className="ml-1.5">
          {post.commentCount}
        </Text>

        <View className="flex-1" />
        <View className="flex-row gap-2">
          {post.tags.slice(0, 2).map((tag) => (
            <Pressable
              key={tag}
              onPress={onTagPress ? () => onTagPress(tag) : undefined}
              hitSlop={4}
              className="active:opacity-70"
            >
              <Text variant="caption" tone="muted">
                #{tag}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>
    </PressableCard>
  );
}
