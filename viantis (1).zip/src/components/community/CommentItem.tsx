import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Pressable, View } from 'react-native';

import { Avatar, Text } from '@/components/ui';
import { useTheme } from '@/providers/ThemeProvider';
import type { Comment } from '@/types';
import { cn } from '@/utils/cn';
import { timeAgo } from '@/utils/date';

interface Props {
  comment: Comment;
  depth?: number;
  onReply: (comment: Comment) => void;
  onModerate: (comment: Comment) => void;
  canModerate: boolean;
}

export function CommentItem({ comment, depth = 0, onReply, onModerate, canModerate }: Props) {
  const { colors } = useTheme();
  return (
    <View className={cn(depth > 0 && 'ml-6 border-l-2 border-line pl-3 dark:border-line-dark')}>
      <View className="flex-row gap-2.5 py-3.5">
        <Avatar avatar={comment.author.avatar} name={comment.author.displayName} size={26} />
        <View className="flex-1">
          <View className="flex-row items-center gap-1.5">
            <Text variant="caption" weight="medium">
              {comment.author.displayName}
            </Text>
            <Text variant="caption" tone="subtle">
              · {timeAgo(comment.createdAt)}
            </Text>
          </View>
          <Text variant="body" tone={comment.isRemoved ? 'subtle' : 'default'} className={cn('mt-0.5', comment.isRemoved && 'italic')}>
            {comment.body}
          </Text>
          {!comment.isRemoved && (
            <View className="mt-2 flex-row items-center gap-4">
              <View className="flex-row items-center gap-1">
                <Ionicons name="arrow-up" size={13} color={comment.userVote === 1 ? colors.primary : colors.inkMuted} />
                <Text variant="caption" tone="muted">
                  {comment.upvotes}
                </Text>
              </View>
              <Pressable onPress={() => onReply(comment)} hitSlop={6} className="active:opacity-70">
                <Text variant="caption" tone="muted">
                  Reply
                </Text>
              </Pressable>
              <Pressable onPress={() => onModerate(comment)} hitSlop={6} className="active:opacity-70">
                <Text variant="caption" tone="subtle">
                  {canModerate ? 'Remove' : 'Report'}
                </Text>
              </Pressable>
            </View>
          )}
        </View>
      </View>
      {comment.replies?.map((reply) => (
        <CommentItem key={reply.id} comment={reply} depth={depth + 1} onReply={onReply} onModerate={onModerate} canModerate={canModerate} />
      ))}
    </View>
  );
}
