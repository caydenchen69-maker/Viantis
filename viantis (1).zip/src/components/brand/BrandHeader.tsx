import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import React, { useState } from 'react';
import { Modal, Pressable, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Text } from '@/components/ui';
import { palette } from '@/constants/theme';
import type { RootStackParamList } from '@/navigation/types';
import { useTheme } from '@/providers/ThemeProvider';

import { BrandMark } from './BrandMark';

const MENU_LINKS: { label: string; href: keyof RootStackParamList | 'toggleTheme'; params?: RootStackParamList[keyof RootStackParamList] }[] = [
  { label: 'Settings', href: 'Settings' },
  { label: 'Accessibility', href: 'Legal', params: { doc: 'accessibility' } },
  { label: 'Privacy', href: 'Legal', params: { doc: 'privacy' } },
  { label: 'Terms', href: 'Legal', params: { doc: 'terms' } },
  { label: 'Community guidelines', href: 'Legal', params: { doc: 'community' } },
  { label: 'Toggle appearance', href: 'toggleTheme' },
];

/** Light editorial top bar: wordmark left, hamburger right. */
export function BrandHeader() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { toggle, isDark } = useTheme();
  const [open, setOpen] = useState(false);

  const onSelect = (href: (typeof MENU_LINKS)[number]['href'], params?: RootStackParamList[keyof RootStackParamList]) => {
    setOpen(false);
    if (href === 'toggleTheme') {
      toggle();
      return;
    }
    if (href === 'Legal') {
      navigation.navigate('Legal', (params as RootStackParamList['Legal']) ?? { doc: 'accessibility' });
      return;
    }
    navigation.navigate(href as 'Settings');
  };

  return (
    <>
      <View
        style={{
          backgroundColor: palette.gray[100],
          paddingTop: insets.top,
          borderBottomWidth: 1,
          borderBottomColor: '#E0DDD6',
        }}
      >
        <View className="h-14 flex-row items-center justify-between px-5">
          <BrandMark />
          <Pressable
            onPress={() => setOpen(true)}
            hitSlop={12}
            accessibilityRole="button"
            accessibilityLabel="Open menu"
            className="h-10 w-10 items-center justify-center active:opacity-70"
          >
            <Ionicons name="menu" size={26} color="#111111" />
          </Pressable>
        </View>
      </View>

      <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
        <Pressable className="flex-1" style={{ backgroundColor: 'rgba(12,18,17,0.55)' }} onPress={() => setOpen(false)}>
          <View
            style={{
              marginTop: insets.top + 56,
              marginHorizontal: 16,
              backgroundColor: palette.cream[50],
              borderWidth: 1,
              borderColor: '#E4DDD2',
            }}
          >
            <Pressable onPress={(e) => e.stopPropagation()}>
              <View className="px-5 py-4 border-b border-line">
                <Text variant="overline" tone="primary">
                  Index
                </Text>
              </View>
              {MENU_LINKS.map((item) => (
                <Pressable
                  key={item.label}
                  onPress={() => onSelect(item.href, item.params)}
                  className="flex-row items-center justify-between px-5 py-4 active:opacity-70"
                  style={{ borderBottomWidth: 1, borderBottomColor: '#E4DDD2' }}
                >
                  <Text variant="label" style={{ letterSpacing: 0.4 }}>
                    {item.label === 'Toggle appearance' ? (isDark ? 'Use light canvas' : 'Use dark canvas') : item.label}
                  </Text>
                  <Ionicons name="arrow-forward" size={14} color="#8A8780" />
                </Pressable>
              ))}
            </Pressable>
          </View>
        </Pressable>
      </Modal>
    </>
  );
}
