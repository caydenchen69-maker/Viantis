import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import React from 'react';
import { Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Text } from '@/components/ui';
import type { RootStackParamList } from '@/navigation/types';

interface Props {
  prompt?: string;
}

/** Floating black pill — opens the Helper to edit the current query or draft. */
export function ChatFab({ prompt }: Props) {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel="Chat to edit"
      onPress={() =>
        navigation.navigate('Tabs', {
          screen: 'AIHelperTab',
          params: prompt ? { prompt } : undefined,
        })
      }
      className="absolute right-5 active:opacity-85"
      style={{
        bottom: Math.max(insets.bottom, 12) + 12,
        backgroundColor: '#111111',
        borderRadius: 999,
        paddingHorizontal: 18,
        paddingVertical: 12,
        shadowColor: '#000',
        shadowOpacity: 0.28,
        shadowRadius: 12,
        shadowOffset: { width: 0, height: 6 },
        elevation: 6,
      }}
    >
      <Text variant="label" weight="medium" style={{ color: '#FFFFFF', letterSpacing: 0.2 }}>
        Chat to Edit
      </Text>
    </Pressable>
  );
}
