import React from 'react';
import { View } from 'react-native';

import { Text } from '@/components/ui';
import { fonts } from '@/constants/typography';

interface Props {
  /** Compact mark for tight headers. */
  size?: 'sm' | 'md';
}

/** Black square V + VIANTIS. wordmark with a coral period. */
export function BrandMark({ size = 'md' }: Props) {
  const mark = size === 'sm' ? 22 : 26;
  const word = size === 'sm' ? 16 : 18;

  return (
    <View className="flex-row items-center" style={{ gap: 10 }} accessibilityRole="image" accessibilityLabel="Viantis">
      <View
        style={{
          width: mark,
          height: mark,
          backgroundColor: '#111111',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Text
          style={{
            fontFamily: fonts.serif,
            fontSize: mark * 0.72,
            lineHeight: mark,
            color: '#FFFFFF',
            fontWeight: 'normal',
          }}
        >
          V
        </Text>
      </View>
      <View className="flex-row items-end">
        <Text
          style={{
            fontFamily: fonts.serif,
            fontSize: word,
            lineHeight: word + 2,
            letterSpacing: 1.4,
            color: '#111111',
            fontWeight: 'normal',
          }}
        >
          VIANTIS
        </Text>
        <Text
          style={{
            fontFamily: fonts.serif,
            fontSize: word,
            lineHeight: word + 2,
            color: '#E55C5C',
            fontWeight: 'normal',
          }}
        >
          .
        </Text>
      </View>
    </View>
  );
}
