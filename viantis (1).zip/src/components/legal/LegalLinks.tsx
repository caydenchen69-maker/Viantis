import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import React from 'react';
import { Pressable, View } from 'react-native';

import { Text } from '@/components/ui';
import { legalIndex, type LegalDocId } from '@/content/legal';
import type { RootStackParamList } from '@/navigation/types';
import { useTheme } from '@/providers/ThemeProvider';
import { cn } from '@/utils/cn';

interface Props {
  compact?: boolean;
  className?: string;
}

export function LegalLinks({ compact = false, className }: Props) {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { colors } = useTheme();

  const open = (doc: LegalDocId) => navigation.navigate('Legal', { doc });

  if (compact) {
    return (
      <View className={cn('flex-row flex-wrap justify-center gap-x-3 gap-y-1', className)}>
        {legalIndex.map((item) => (
          <Pressable
            key={item.id}
            onPress={() => open(item.id)}
            accessibilityRole="link"
            accessibilityLabel={item.title}
            className="py-1 active:opacity-70"
          >
            <Text variant="caption" tone="muted">
              {item.title}
            </Text>
          </Pressable>
        ))}
      </View>
    );
  }

  return (
    <View className={className}>
      {legalIndex.map((item, i) => (
        <Pressable
          key={item.id}
          onPress={() => open(item.id)}
          accessibilityRole="link"
          accessibilityLabel={`${item.title}. ${item.blurb}`}
          className={cn(
            'flex-row items-center gap-3 py-3.5 active:opacity-80',
            i < legalIndex.length - 1 && 'border-b border-line dark:border-line-dark',
          )}
        >
          <View className="flex-1">
            <Text variant="body" weight="medium">
              {item.title}
            </Text>
            <Text variant="caption" tone="muted" className="mt-0.5">
              {item.blurb}
            </Text>
          </View>
          <Ionicons name="chevron-forward" size={16} color={colors.inkSubtle} />
        </Pressable>
      ))}
    </View>
  );
}
