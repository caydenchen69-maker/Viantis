import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Pressable, ScrollView, TextInput, View } from 'react-native';

import { Text } from '@/components/ui';
import { fonts } from '@/constants/typography';
import { useTheme } from '@/providers/ThemeProvider';
import { cn } from '@/utils/cn';

export const composerStarters = [
  'Outline a five-paragraph essay on this topic',
  'Turn my notes into a lab report introduction',
  'Rewrite this more formally for a teacher',
  'Add a thesis and topic sentences',
];

interface Props {
  title: string;
  draft: string;
  onChangeTitle: (value: string) => void;
  onChangeDraft: (value: string) => void;
  onUseStarter: (starter: string) => void;
  onClear: () => void;
  busy: boolean;
}

/** Writing surface for Helper Composer mode — the draft is the source of truth. */
export function ComposerPane({ title, draft, onChangeTitle, onChangeDraft, onUseStarter, onClear, busy }: Props) {
  const { colors } = useTheme();
  const empty = draft.trim().length === 0;

  return (
    <ScrollView
      className="flex-1"
      contentContainerClassName="px-5 pb-4"
      keyboardShouldPersistTaps="handled"
      keyboardDismissMode="interactive"
    >
      <View className="mb-3 flex-row items-center justify-between">
        <Text variant="caption" tone="muted">
          {busy ? 'Rewriting…' : empty ? 'Start a draft, then ask the helper to revise it' : `${draft.trim().split(/\s+/).length} words`}
        </Text>
        {!empty && (
          <Pressable onPress={onClear} hitSlop={8} className="flex-row items-center gap-1 active:opacity-70">
            <Ionicons name="trash-outline" size={14} color={colors.inkMuted} />
            <Text variant="caption" tone="muted">
              Clear
            </Text>
          </Pressable>
        )}
      </View>

      <TextInput
        value={title}
        onChangeText={onChangeTitle}
        placeholder="Title"
        placeholderTextColor={colors.inkMuted}
        style={{ fontFamily: fonts.serif, fontSize: 28, lineHeight: 34, fontWeight: 'normal', color: colors.ink }}
        accessibilityLabel="Draft title"
      />

      <TextInput
        value={draft}
        onChangeText={onChangeDraft}
        placeholder="Write here. The helper will rewrite this document — not start a chat."
        placeholderTextColor={colors.inkMuted}
        multiline
        textAlignVertical="top"
        className="mt-4 min-h-[280px]"
        style={{ fontFamily: fonts.sans.regular, fontSize: 16, lineHeight: 26, color: colors.ink }}
        accessibilityLabel="Draft body"
      />

      {empty && (
        <View className="mt-8">
          <Text variant="heading" className="mb-1">
            Start from
          </Text>
          {composerStarters.map((starter, i) => (
            <Pressable
              key={starter}
              onPress={() => onUseStarter(starter)}
              className={cn(
                'flex-row items-center gap-3 py-3.5 active:opacity-70',
                i < composerStarters.length - 1 && 'border-b border-line dark:border-line-dark',
              )}
            >
              <Text variant="body" className="flex-1">
                {starter}
              </Text>
              <Ionicons name="arrow-forward" size={15} color={colors.inkSubtle} />
            </Pressable>
          ))}
        </View>
      )}
    </ScrollView>
  );
}
