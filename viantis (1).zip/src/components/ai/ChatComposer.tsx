import { Ionicons } from '@expo/vector-icons';
import React, { useState } from 'react';
import { ActivityIndicator, Image, Pressable, TextInput, View } from 'react-native';

import { Text } from '@/components/ui';
import { fonts } from '@/constants/typography';
import { useTheme } from '@/providers/ThemeProvider';
import type { ChatAttachment } from '@/types';

interface Props {
  attachment: ChatAttachment | null;
  onRemoveAttachment: () => void;
  onPickImage: () => void;
  onTakePhoto: () => void;
  onSend: (text: string) => void;
  onStop: () => void;
  busy: boolean;
  scanning: boolean;
  placeholder?: string;
}

export function ChatComposer({
  attachment,
  onRemoveAttachment,
  onPickImage,
  onTakePhoto,
  onSend,
  onStop,
  busy,
  scanning,
  placeholder = 'Ask anything…',
}: Props) {
  const { colors } = useTheme();
  const [text, setText] = useState('');
  const canSend = (text.trim().length > 0 || attachment) && !busy && !scanning;

  const submit = () => {
    if (!canSend) return;
    onSend(text.trim() || 'Help me solve this problem');
    setText('');
  };

  return (
    <View className="px-4 pb-2 pt-2">
      {attachment && (
        <View className="mb-3 flex-row items-center gap-3 rounded-xl bg-surface-muted p-2 dark:bg-surface-muted-dark">
          <Image source={{ uri: attachment.uri }} style={{ width: 52, height: 52, borderRadius: 10 }} />
          <View className="flex-1">
            {scanning ? (
              <View className="flex-row items-center gap-2">
                <ActivityIndicator size="small" color={colors.primary} />
                <Text variant="caption" tone="muted">
                  Reading text from photo…
                </Text>
              </View>
            ) : (
              <>
                <Text variant="caption" className="font-semibold">
                  {attachment.ocrText ? 'Detected' : 'Photo attached'}
                </Text>
                {attachment.ocrText && (
                  <Text variant="caption" tone="muted" numberOfLines={2}>
                    {attachment.ocrText}
                  </Text>
                )}
              </>
            )}
          </View>
          <Pressable onPress={onRemoveAttachment} hitSlop={8} accessibilityLabel="Remove attachment">
            <Ionicons name="close-circle" size={22} color={colors.inkSubtle} />
          </Pressable>
        </View>
      )}

      <View className="flex-row items-end gap-2">
        <Pressable onPress={onTakePhoto} accessibilityLabel="Take photo" className="h-11 w-10 items-center justify-center active:opacity-70">
          <Ionicons name="camera-outline" size={22} color={colors.inkMuted} />
        </Pressable>
        <Pressable onPress={onPickImage} accessibilityLabel="Upload image" className="h-11 w-10 items-center justify-center active:opacity-70">
          <Ionicons name="image-outline" size={22} color={colors.inkMuted} />
        </Pressable>
        <View className="max-h-32 min-h-[44px] flex-1 justify-center rounded-[22px] border border-line bg-surface px-4 py-2 dark:border-line-dark dark:bg-surface-dark">
          <TextInput
            value={text}
            onChangeText={setText}
            placeholder={placeholder}
            placeholderTextColor={colors.inkSubtle}
            multiline
            className="text-[15px] leading-5 text-ink dark:text-ink-dark"
            style={{ maxHeight: 110, fontFamily: fonts.sans.regular }}
            onSubmitEditing={submit}
            blurOnSubmit={false}
            returnKeyType="send"
          />
        </View>
        {busy ? (
          <Pressable onPress={onStop} accessibilityLabel="Stop generating" className="h-11 w-11 items-center justify-center rounded-full bg-primary-600 dark:bg-primary-500 active:opacity-80">
            <Ionicons name="stop" size={18} color="#FFFFFF" />
          </Pressable>
        ) : (
          <Pressable
            onPress={submit}
            disabled={!canSend}
            accessibilityLabel="Send"
            className="h-11 w-11 items-center justify-center rounded-full bg-primary-600 dark:bg-primary-500 active:opacity-80"
            style={{ opacity: canSend ? 1 : 0.3 }}
          >
            <Ionicons name="arrow-up" size={22} color="#FFFFFF" />
          </Pressable>
        )}
      </View>
    </View>
  );
}
