import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Image, View } from 'react-native';

import { Text } from '@/components/ui';
import { useTheme } from '@/providers/ThemeProvider';
import type { ChatMessage } from '@/types';
import { cn } from '@/utils/cn';

interface Props {
  message: ChatMessage;
}

/**
 * Renders a chat message. Assistant text supports a light markdown subset
 * (**bold**, bullet lines, fenced code) which is enough for step-by-step maths.
 */
export function ChatBubble({ message }: Props) {
  const { colors } = useTheme();
  const isUser = message.role === 'user';

  return (
    <View className={cn('mb-5', isUser ? 'max-w-[85%] self-end' : 'self-stretch')}>
      {!isUser && (
        <Text variant="heading" italic tone="muted" className="mb-1.5" style={{ fontSize: 17, lineHeight: 20 }}>
          Helper
        </Text>
      )}

      {message.attachments?.map((a) => (
        <View key={a.id} className="mb-2 overflow-hidden rounded-2xl border border-line dark:border-line-dark">
          <Image source={{ uri: a.uri }} style={{ width: 220, height: 160 }} resizeMode="cover" />
          {a.ocrText && (
            <View className="flex-row items-center gap-1.5 bg-surface px-3 py-2 dark:bg-surface-dark">
              <Ionicons name="scan-outline" size={14} color={colors.inkMuted} />
              <Text variant="caption" tone="muted" numberOfLines={2}>
                Read: {a.ocrText}
              </Text>
            </View>
          )}
        </View>
      ))}

      <View
        className={cn(
          isUser
            ? 'rounded-2xl rounded-br-md bg-primary-600 px-4 py-3 dark:bg-primary-500'
            : 'border-l-2 border-line pl-4 dark:border-line-dark',
          message.status === 'error' && 'border-danger',
        )}
      >
        {message.status === 'error' ? (
          <Text variant="body" tone="danger">
            {message.content}
          </Text>
        ) : isUser ? (
          <Text variant="body" className="text-white dark:text-ink">
            {message.content}
          </Text>
        ) : (
          <RichText content={message.content} streaming={message.status === 'streaming'} />
        )}
      </View>
    </View>
  );
}

function RichText({ content, streaming }: { content: string; streaming: boolean }) {
  const blocks = content.split(/```/);
  return (
    <View>
      {blocks.map((block, bi) =>
        bi % 2 === 1 ? (
          <View key={bi} className="my-2 rounded-xl bg-surface-muted p-3 dark:bg-surface-muted-dark">
            <Text variant="caption" className="font-mono">
              {block.trim()}
            </Text>
          </View>
        ) : (
          block.split('\n').map((line, li) => <Line key={`${bi}-${li}`} line={line} />)
        ),
      )}
      {streaming && (
        <View className="mt-1 h-3.5 w-1.5 rounded-sm bg-primary-600 dark:bg-primary-500" />
      )}
    </View>
  );
}

function Line({ line }: { line: string }) {
  if (!line.trim()) return <View className="h-2" />;
  const isBullet = /^[•\-–]\s/.test(line.trim());
  const text = isBullet ? line.trim().replace(/^[•\-–]\s/, '') : line;
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return (
    <View className={cn('flex-row', isBullet && 'pl-2')}>
      {isBullet && (
        <Text variant="body" tone="muted" className="mr-1.5">
          •
        </Text>
      )}
      <Text variant="body" className="flex-1">
        {parts.map((part, i) =>
          part.startsWith('**') && part.endsWith('**') ? (
            <Text key={i} variant="body" className="font-semibold">
              {part.slice(2, -2)}
            </Text>
          ) : (
            part
          ),
        )}
      </Text>
    </View>
  );
}
