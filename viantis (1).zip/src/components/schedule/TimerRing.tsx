import React from 'react';
import { View } from 'react-native';
import Svg, { Circle } from 'react-native-svg';

import { useTheme } from '@/providers/ThemeProvider';

interface Props {
  /** 0–1 */
  progress: number;
  size?: number;
  strokeWidth?: number;
  color: string;
  children?: React.ReactNode;
}

/** Circular progress ring used by the Pomodoro screen. */
export function TimerRing({ progress, size = 260, strokeWidth = 12, color, children }: Props) {
  const { colors } = useTheme();
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const clamped = Math.min(1, Math.max(0, progress));
  const dashOffset = circumference * (1 - clamped);
  const center = size / 2;

  return (
    <View style={{ width: size, height: size }} className="items-center justify-center">
      <Svg width={size} height={size} style={{ position: 'absolute' }}>
        <Circle cx={center} cy={center} r={radius} stroke={colors.surfaceMuted} strokeWidth={strokeWidth} fill="none" />
        {clamped > 0 && (
          <Circle
            cx={center}
            cy={center}
            r={radius}
            stroke={color}
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            fill="none"
            strokeDasharray={`${circumference} ${circumference}`}
            strokeDashoffset={dashOffset}
            // Start the arc at 12 o'clock; string transform works on native and web.
            transform={`rotate(-90 ${center} ${center})`}
          />
        )}
      </Svg>
      {children}
    </View>
  );
}
