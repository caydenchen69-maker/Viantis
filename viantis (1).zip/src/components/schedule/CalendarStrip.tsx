import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Pressable, View } from 'react-native';

import { IconButton, Text } from '@/components/ui';
import { useTheme } from '@/providers/ThemeProvider';
import { cn } from '@/utils/cn';
import { addDays, isSameDay, isToday, MONTH_SHORT, WEEKDAY_SHORT, weekAround } from '@/utils/date';

interface Props {
  selected: Date;
  onSelect: (date: Date) => void;
  /** Map of yyyy-mm-dd → number of tasks, used for dot indicators. */
  taskCounts: Record<string, number>;
}

export const dayKey = (d: Date) =>
  `${d.getFullYear()}-${(d.getMonth() + 1).toString().padStart(2, '0')}-${d.getDate().toString().padStart(2, '0')}`;

export function CalendarStrip({ selected, onSelect, taskCounts }: Props) {
  const { colors } = useTheme();
  const week = weekAround(selected);
  const first = week[0]!;
  const last = week[6]!;
  const monthLabel =
    first.getMonth() === last.getMonth()
      ? `${MONTH_SHORT[first.getMonth()]} ${first.getFullYear()}`
      : `${MONTH_SHORT[first.getMonth()]} – ${MONTH_SHORT[last.getMonth()]} ${last.getFullYear()}`;

  return (
    <View className="mb-4">
      <View className="mb-3 flex-row items-center justify-between">
        <Text variant="heading">{monthLabel}</Text>
        <View className="flex-row items-center gap-1">
          <IconButton
            name="chevron-back"
            variant="plain"
            size={18}
            onPress={() => onSelect(addDays(selected, -7))}
            accessibilityLabel="Previous week"
          />
          <Pressable onPress={() => onSelect(new Date())} className="px-2 py-1.5 active:opacity-70">
            <Text variant="label" tone="muted">
              Today
            </Text>
          </Pressable>
          <IconButton
            name="chevron-forward"
            variant="plain"
            size={18}
            onPress={() => onSelect(addDays(selected, 7))}
            accessibilityLabel="Next week"
          />
        </View>
      </View>

      <View className="flex-row justify-between gap-1">
        {week.map((day) => {
          const active = isSameDay(day, selected);
          const today = isToday(day);
          const count = taskCounts[dayKey(day)] ?? 0;
          return (
            <Pressable
              key={day.toISOString()}
              onPress={() => onSelect(day)}
              accessibilityRole="button"
              accessibilityState={{ selected: active }}
              className="flex-1 items-center py-1"
            >
              <Text variant="caption" tone={active ? 'default' : 'subtle'}>
                {WEEKDAY_SHORT[day.getDay()]!.slice(0, 1)}
              </Text>
              <View
                className={cn('mt-1.5 h-10 w-10 items-center justify-center rounded-full', active && 'bg-primary-600 dark:bg-primary-500')}
              >
                <Text
                  variant="heading"
                  style={{ fontSize: 20, lineHeight: 24 }}
                  className={cn(active ? 'text-white dark:text-ink' : today && 'text-primary-600 dark:text-primary-400')}
                >
                  {day.getDate()}
                </Text>
              </View>
              <View className="mt-1.5 h-1 flex-row gap-0.5">
                {Array.from({ length: Math.min(count, 3) }).map((_, i) => (
                  <View key={i} className="h-1 w-1 rounded-full" style={{ backgroundColor: active ? colors.ink : colors.inkSubtle }} />
                ))}
              </View>
            </Pressable>
          );
        })}
      </View>
      {!isToday(selected) && (
        <Pressable onPress={() => onSelect(new Date())} className="mt-2 flex-row items-center justify-center gap-1 active:opacity-70">
          <Ionicons name="return-down-back-outline" size={14} color={colors.inkMuted} />
          <Text variant="caption" tone="muted">
            Back to today
          </Text>
        </Pressable>
      )}
    </View>
  );
}
