import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Pressable, View } from 'react-native';

import { Text } from '@/components/ui';
import { useTheme } from '@/providers/ThemeProvider';
import type { StudyTask, Subject } from '@/types';
import { cn } from '@/utils/cn';
import { dayLabel, formatTime, isToday } from '@/utils/date';
import { formatMinutes } from '@/utils/format';

interface Props {
  task: StudyTask;
  subject?: Subject;
  onToggle: (task: StudyTask) => void;
  onPress?: (task: StudyTask) => void;
  /** `row` renders as a hairline-divided list row; `card` as a standalone card. */
  variant?: 'row' | 'card';
  /** Hide the bottom hairline (last row in a list). */
  last?: boolean;
  /** Show the due date instead of just the time (for lists spanning days). */
  showDate?: boolean;
}

export function TaskItem({ task, subject, onToggle, onPress, variant = 'row', last = false, showDate = false }: Props) {
  const { colors } = useTheme();
  const done = task.status === 'done';
  const dueDate = new Date(task.dueAt);
  const overdue = !done && dueDate < new Date();
  const crossDay = showDate || !isToday(dueDate);

  return (
    <Pressable
      onPress={() => onPress?.(task)}
      className={cn(
        'flex-row items-center gap-3.5 active:opacity-80',
        variant === 'card'
          ? 'rounded-2xl border border-line bg-surface px-4 py-3.5 dark:border-line-dark dark:bg-surface-dark'
          : cn('py-3.5', !last && 'border-b border-line dark:border-line-dark'),
      )}
    >
      <Pressable
        onPress={() => onToggle(task)}
        hitSlop={10}
        accessibilityRole="checkbox"
        accessibilityState={{ checked: done }}
        className={cn(
          'h-[22px] w-[22px] items-center justify-center rounded-full border-[1.5px]',
          done ? 'border-primary-600 bg-primary-600 dark:border-primary-500 dark:bg-primary-500' : 'border-ink-subtle dark:border-ink-subtle-dark',
        )}
      >
        {done && <Ionicons name="checkmark" size={13} color={colors.canvas} />}
      </Pressable>

      <View className="flex-1">
        <Text
          variant="body"
          weight="medium"
          className={cn(done && 'line-through text-ink-subtle dark:text-ink-subtle-dark')}
          numberOfLines={1}
        >
          {task.title}
        </Text>
        <View className="mt-0.5 flex-row items-center gap-1.5">
          {subject && (
            <View className="flex-row items-center gap-1.5">
              <View className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: subject.color }} />
              <Text variant="caption" tone="muted">
                {subject.name}
              </Text>
            </View>
          )}
          {subject && (
            <Text variant="caption" tone="subtle">
              ·
            </Text>
          )}
          <Text variant="caption" tone="muted">
            {formatMinutes(task.estimatedMinutes)}
          </Text>
          {!done && task.priority === 'high' && (
            <>
              <Text variant="caption" tone="subtle">
                ·
              </Text>
              <Text variant="caption" tone="danger">
                High
              </Text>
            </>
          )}
        </View>
      </View>

      <View className="items-end">
        <Text variant="caption" tone={overdue ? 'danger' : 'muted'} style={{ fontVariant: ['tabular-nums'] }}>
          {crossDay ? dayLabel(dueDate) : formatTime(task.dueAt)}
        </Text>
        {crossDay && (
          <Text variant="caption" tone="subtle" style={{ fontVariant: ['tabular-nums'] }}>
            {formatTime(task.dueAt)}
          </Text>
        )}
      </View>
    </Pressable>
  );
}
