import React from 'react';
import Svg, { Circle, Line, Path, Rect, type SvgProps } from 'react-native-svg';

export interface MarkProps {
  color: string;
  size?: number;
  focused?: boolean;
  accent?: string;
}

const stroke = (focused: boolean) => (focused ? 1.7 : 1.45);

/** Shared canvas for the tab traces. */
function Frame({ size = 26, children, ...rest }: SvgProps & { size?: number; children: React.ReactNode }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" {...rest}>
      {children}
    </Svg>
  );
}

/** Campus portico — landing / home. */
export function HomeMark({ color, size, focused = false, accent = '#E55C5C' }: MarkProps) {
  const sw = stroke(focused);
  const glow = focused ? accent : color;
  return (
    <Frame size={size}>
      <Path d="M3.6 10.2 12 4.2l8.4 6" stroke={color} strokeWidth={sw} strokeLinejoin="miter" />
      <Path d="M5.2 10.4h13.6v2.1H5.2z" stroke={color} strokeWidth={sw} />
      <Path d="M6.4 12.5v7.7M10.2 12.5v7.7M13.8 12.5v7.7M17.6 12.5v7.7" stroke={color} strokeWidth={sw} />
      <Path d="M4.6 20.2h14.8" stroke={color} strokeWidth={sw} strokeLinecap="square" />
      <Rect x="10.4" y="14.6" width="3.2" height="5.6" stroke={glow} strokeWidth={sw} fill={focused ? glow : 'none'} fillOpacity={focused ? 0.85 : 0} />
    </Frame>
  );
}

/** Upright cabinet with stick, buttons, and a lit marquee. */
export function ArcadeCabinetMark({ color, size, focused = false, accent = '#E55C5C' }: MarkProps) {
  const sw = stroke(focused);
  const glow = focused ? accent : color;
  return (
    <Frame size={size}>
      <Path d="M7.2 3.2h9.6v3.1H7.2z" stroke={color} strokeWidth={sw} />
      <Path d="M6.4 6.3h11.2v7.2H6.4z" stroke={color} strokeWidth={sw} />
      <Rect x="8" y="7.6" width="8" height="4.4" stroke={glow} strokeWidth={sw} fill={focused ? glow : 'none'} fillOpacity={focused ? 0.22 : 0} />
      <Path d="M5.6 13.5h12.8v3.1H5.6z" stroke={color} strokeWidth={sw} />
      <Circle cx="9.1" cy="15.05" r="1.15" stroke={glow} strokeWidth={sw} fill={focused ? glow : 'none'} />
      <Circle cx="13.3" cy="14.7" r="0.55" fill={glow} />
      <Circle cx="15.4" cy="15.35" r="0.55" fill={glow} />
      <Path d="M6.8 16.6 8.2 21.2h7.6l1.4-4.6" stroke={color} strokeWidth={sw} strokeLinejoin="miter" />
      <Path d="M11.2 18.4h1.6" stroke={color} strokeWidth={sw} strokeLinecap="square" />
    </Frame>
  );
}

/** Handheld console — dual pads, screen, shoulder line. */
export function ConsoleMark({ color, size, focused = false, accent = '#E55C5C' }: MarkProps) {
  const sw = stroke(focused);
  const glow = focused ? accent : color;
  return (
    <Frame size={size}>
      <Path
        d="M4.2 8.6h15.6c.9 0 1.6.7 1.6 1.6v5.2c0 1.4-1.1 2.5-2.5 2.5H5.1C3.7 17.9 2.6 16.8 2.6 15.4V10.2c0-.9.7-1.6 1.6-1.6Z"
        stroke={color}
        strokeWidth={sw}
      />
      <Rect x="8.2" y="10.2" width="7.6" height="5.2" stroke={glow} strokeWidth={sw} fill={focused ? glow : 'none'} fillOpacity={focused ? 0.2 : 0} />
      <Circle cx="5.6" cy="13" r="1.15" stroke={color} strokeWidth={sw} />
      <Path d="M17.6 11.7v2.6M16.3 13h2.6" stroke={glow} strokeWidth={sw} strokeLinecap="square" />
      <Path d="M4.6 8.6V7.4M19.4 8.6V7.4" stroke={color} strokeWidth={sw} strokeLinecap="square" />
    </Frame>
  );
}

/** CRT terminal with a prompt — Helper. */
export function TerminalMark({ color, size, focused = false, accent = '#E55C5C' }: MarkProps) {
  const sw = stroke(focused);
  const glow = focused ? accent : color;
  return (
    <Frame size={size}>
      <Rect x="3.4" y="3.6" width="17.2" height="13.2" stroke={color} strokeWidth={sw} />
      <Rect x="5.2" y="5.4" width="13.6" height="8.6" stroke={glow} strokeWidth={sw} fill={focused ? glow : 'none'} fillOpacity={focused ? 0.16 : 0} />
      <Path d="M7 8.2h4.4M7 10.4h7.2" stroke={color} strokeWidth={sw} strokeLinecap="square" />
      <Path d="M7 12.6h2.2" stroke={glow} strokeWidth={sw} strokeLinecap="square" />
      <Path d="M9.6 16.8v1.8h4.8v-1.8" stroke={color} strokeWidth={sw} />
      <Path d="M8.4 20.4h7.2" stroke={color} strokeWidth={sw} strokeLinecap="square" />
    </Frame>
  );
}

/** Compass crest — Matches. */
export function CompassMark({ color, size, focused = false, accent = '#E55C5C' }: MarkProps) {
  const sw = stroke(focused);
  const glow = focused ? accent : color;
  return (
    <Frame size={size}>
      <Circle cx="12" cy="12" r="8.2" stroke={color} strokeWidth={sw} />
      <Circle cx="12" cy="12" r="3.1" stroke={color} strokeWidth={sw} />
      <Path d="M12 4.6 13.4 12 12 19.4 10.6 12Z" stroke={glow} strokeWidth={sw} fill={focused ? glow : 'none'} fillOpacity={focused ? 0.85 : 0} />
      <Path d="M4.6 12h2.4M17 12h2.4M12 4.6V6.8M12 17.2v2.2" stroke={color} strokeWidth={sw} strokeLinecap="square" />
    </Frame>
  );
}

/** Two stools at a cabinet — Community. */
export function LoungeMark({ color, size, focused = false, accent = '#E55C5C' }: MarkProps) {
  const sw = stroke(focused);
  const glow = focused ? accent : color;
  return (
    <Frame size={size}>
      <Path d="M5.2 8.4h5.2v4.6H5.2z" stroke={color} strokeWidth={sw} />
      <Path d="M13.6 8.4h5.2v4.6h-5.2z" stroke={color} strokeWidth={sw} />
      <Path d="M6.4 13v6.4M9.2 13v6.4M14.8 13v6.4M17.6 13v6.4" stroke={color} strokeWidth={sw} strokeLinecap="square" />
      <Path d="M5.6 19.6h4.4M13.8 19.6h4.6" stroke={color} strokeWidth={sw} strokeLinecap="square" />
      <Path d="M8.2 6.2c0-1.4 1.1-2.4 2.6-2.4h2.4c1.5 0 2.6 1 2.6 2.4" stroke={glow} strokeWidth={sw} />
      {focused && <Circle cx="12" cy="5.2" r="0.7" fill={glow} />}
    </Frame>
  );
}

/** Vector ship for Space Shooter. */
export function ShipMark({ color, size = 22 }: MarkProps) {
  return (
    <Frame size={size}>
      <Path d="M12 3.6 18.4 19.2 12 15.6 5.6 19.2Z" stroke={color} strokeWidth={1.5} strokeLinejoin="miter" />
      <Path d="M12 8.4v7.2" stroke={color} strokeWidth={1.5} />
      <Path d="M8.6 13.6H5.4M15.4 13.6h3.2" stroke={color} strokeWidth={1.5} strokeLinecap="square" />
    </Frame>
  );
}

/** Stacked cartridges for flashcard match. */
export function CartridgeMark({ color, size = 22 }: MarkProps) {
  return (
    <Frame size={size}>
      <Path d="M5.2 8.2h10.4v11H5.2z" stroke={color} strokeWidth={1.5} />
      <Path d="M7 8.2V6.2h10.4v11H15.6" stroke={color} strokeWidth={1.5} />
      <Path d="M7.4 11.2h6M7.4 13.6h4.4" stroke={color} strokeWidth={1.5} strokeLinecap="square" />
    </Frame>
  );
}

/** Ticket tower for trivia. */
export function TicketTowerMark({ color, size = 22 }: MarkProps) {
  return (
    <Frame size={size}>
      <Path d="M7.2 20.4h9.6v-3.4H7.2z" stroke={color} strokeWidth={1.5} />
      <Path d="M8 17h8V13.6H8z" stroke={color} strokeWidth={1.5} />
      <Path d="M8.8 13.6h6.4V9.8H8.8z" stroke={color} strokeWidth={1.5} />
      <Path d="M9.8 9.8h4.4V6.2H9.8z" stroke={color} strokeWidth={1.5} />
      <Circle cx="12" cy="4.6" r="1.2" stroke={color} strokeWidth={1.5} />
    </Frame>
  );
}

export function gameMark(icon: string) {
  if (icon.includes('rocket') || icon.includes('ship')) return ShipMark;
  if (icon.includes('grid') || icon.includes('card')) return CartridgeMark;
  if (icon.includes('business') || icon.includes('tower')) return TicketTowerMark;
  return ArcadeCabinetMark;
}
