import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Pressable, View } from 'react-native';

import { Button, Text } from '@/components/ui';
import { palette } from '@/constants/theme';
import type { StudyTask, Subject } from '@/types';
import { formatDueLabel } from '@/utils/date';
import { formatMinutes } from '@/utils/format';

interface Props {
  nextTask?: StudyTask;
  subject?: Subject;
  focusMinutes: number;
  onStart: (taskId?: string) => void;
  onChooseTask: () => void;
}

/** Charcoal focal block — the one dark plane on the editorial landing. */
export function FocusPanel({ nextTask, subject, focusMinutes, onStart, onChooseTask }: Props) {
  return (
    <View className="mb-7 px-5 py-6" style={{ backgroundColor: palette.charcoal[900], borderRadius: 8 }}>
      <View className="flex-row items-center justify-between">
        <Text variant="overline" style={{ color: palette.coral[400], letterSpacing: 1.4 }}>
          Next focus session
        </Text>
        <View className="flex-row items-center gap-1.5">
          <Ionicons name="timer-outline" size={15} color="rgba(246,241,232,0.55)" />
          <Text variant="caption" style={{ color: 'rgba(246,241,232,0.55)' }}>
            {formatMinutes(focusMinutes)}
          </Text>
        </View>
      </View>

      <View className="mt-5 mb-6">
        {nextTask ? (
          <>
            <Text variant="title" tone="inverse" numberOfLines={2} style={{ fontSize: 29, lineHeight: 34, letterSpacing: -0.3 }}>
              {nextTask.title}
            </Text>
            <Text variant="caption" style={{ color: 'rgba(246,241,232,0.55)', marginTop: 10, lineHeight: 17 }}>
              {subject ? `${subject.name} · ` : ''}
              {formatDueLabel(nextTask.dueAt)} · {formatMinutes(nextTask.estimatedMinutes)} planned
            </Text>
          </>
        ) : (
          <>
            <Text variant="title" tone="inverse" italic style={{ fontSize: 29, lineHeight: 34, letterSpacing: -0.3 }}>
              Nothing queued.
            </Text>
            <Text variant="caption" style={{ color: 'rgba(246,241,232,0.55)', marginTop: 10, lineHeight: 17 }}>
              Start an open session or pick a task from your planner.
            </Text>
          </>
        )}
      </View>

      <View className="flex-row items-center justify-between">
        <Button label="Start session" variant="inverse" icon="play" onPress={() => onStart(nextTask?.id)} />
        <Pressable onPress={onChooseTask} hitSlop={8} className="flex-row items-center gap-1.5 active:opacity-70">
          <Text variant="overline" style={{ color: 'rgba(246,241,232,0.7)', letterSpacing: 1.2 }}>
            {nextTask ? 'Change' : 'Planner'}
          </Text>
          <Ionicons name="arrow-forward" size={15} color="rgba(246,241,232,0.6)" />
        </Pressable>
      </View>
    </View>
  );
}
