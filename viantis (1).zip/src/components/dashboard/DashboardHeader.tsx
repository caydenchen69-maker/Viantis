import React from 'react';
import { Pressable, View } from 'react-native';

import { Avatar, CampusPhoto, IconButton, Text } from '@/components/ui';
import { campusCaptions } from '@/constants/campus';
import { useTheme } from '@/providers/ThemeProvider';
import type { UserProfile } from '@/types';
import { greetingForNow, MONTH_SHORT, WEEKDAY_SHORT } from '@/utils/date';

interface Props {
  profile: UserProfile | null;
  onOpenSettings: () => void;
  onOpenProfile: () => void;
}

export function DashboardHeader({ profile, onOpenSettings, onOpenProfile }: Props) {
  const { isDark, toggle } = useTheme();
  const now = new Date();
  const dateLabel = `${WEEKDAY_SHORT[now.getDay()]} ${now.getDate()} ${MONTH_SHORT[now.getMonth()]}`;
  const firstName = profile?.displayName?.split(' ')[0];

  return (
    <CampusPhoto photo="harvard" height={240} dim={0.28} caption={false} className="mb-6">
      <View className="flex-1 justify-between p-5">
        <View className="flex-row items-center justify-between">
          <Text variant="label" tone="inverseMuted" style={{ letterSpacing: 0.3 }}>
            {dateLabel}
          </Text>
          <View className="flex-row items-center gap-2">
            <IconButton
              name={isDark ? 'sunny-outline' : 'moon-outline'}
              size={20}
              color="#FFFFFF"
              onPress={toggle}
              accessibilityLabel="Toggle dark mode"
            />
            <IconButton
              name="settings-outline"
              size={20}
              color="#FFFFFF"
              onPress={onOpenSettings}
              accessibilityLabel="Open settings"
            />
            {profile && (
              <Pressable onPress={onOpenProfile} accessibilityLabel="Open profile" className="ml-0.5 active:opacity-80">
                <Avatar avatar={profile.avatar} name={profile.displayName} size={36} />
              </Pressable>
            )}
          </View>
        </View>
        <View>
          <Text variant="display" tone="inverse" style={{ fontSize: 38, lineHeight: 42, letterSpacing: -0.5 }}>
            {greetingForNow(now)}
            {firstName ? `, ${firstName}.` : '.'}
          </Text>
          <Text variant="caption" tone="inverseMuted" className="mt-2.5" style={{ lineHeight: 18 }}>
            {campusCaptions.harvard}
          </Text>
        </View>
      </View>
    </CampusPhoto>
  );
}
