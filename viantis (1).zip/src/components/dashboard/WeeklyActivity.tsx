import React from 'react';
import { View } from 'react-native';

import { Text } from '@/components/ui';
import type { DayStat } from '@/hooks/useStudyStats';
import { useTheme } from '@/providers/ThemeProvider';
import { isToday } from '@/utils/date';
import { formatMinutes } from '@/utils/format';

const BAR_AREA = 76;

interface Props {
  week: DayStat[];
  weekMinutes: number;
  maxMinutes: number;
}

/** Minimal 7-day bar chart. Sits directly on the canvas, no card. */
export function WeeklyActivity({ week, weekMinutes, maxMinutes }: Props) {
  const { colors } = useTheme();
  return (
    <View className="mb-7">
      <View className="mb-4 flex-row items-baseline justify-between">
        <Text variant="heading" style={{ letterSpacing: -0.2 }}>This week</Text>
        <Text variant="label" tone="muted" style={{ letterSpacing: 0.1 }}>
          {formatMinutes(weekMinutes)} focused
        </Text>
      </View>
      <View className="flex-row gap-2.5">
        {week.map((day) => {
          const ratio = day.minutes / maxMinutes;
          const today = isToday(day.date);
          return (
            <View key={day.date.toISOString()} className="flex-1 items-center gap-2.5">
              <View className="w-full justify-end" style={{ height: BAR_AREA }}>
                <View
                  className="w-full rounded-[4px]"
                  style={{
                    height: Math.max(Math.round(ratio * BAR_AREA), 4),
                    backgroundColor: today ? colors.primary : day.minutes > 0 ? colors.accent : colors.line,
                    opacity: today ? 1 : day.minutes > 0 ? 0.8 : 1,
                  }}
                />
              </View>
              <Text
                variant="caption"
                weight={today ? 'semibold' : 'regular'}
                style={{
                  color: today ? colors.ink : colors.inkSubtle,
                  letterSpacing: 0.2,
                }}
              >
                {day.label}
              </Text>
            </View>
          );
        })}
      </View>
    </View>
  );
}
