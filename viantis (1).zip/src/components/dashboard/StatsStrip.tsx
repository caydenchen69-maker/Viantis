import React from 'react';
import { Pressable, View } from 'react-native';

import { Text } from '@/components/ui';
import { cn } from '@/utils/cn';

export interface Stat {
  key: string;
  value: string;
  label: string;
  onPress?: () => void;
}

interface Props {
  stats: Stat[];
  className?: string;
}

/** Three-up row of serif numerals separated by hairlines. */
export function StatsStrip({ stats, className }: Props) {
  return (
    <View
      className={cn(
        'flex-row border-y border-line py-5 dark:border-line-dark',
        className,
      )}
    >
      {stats.map((stat, index) => (
        <Pressable
          key={stat.key}
          onPress={stat.onPress}
          disabled={!stat.onPress}
          className={cn(
            'flex-1 active:opacity-70',
            index > 0 && 'border-l border-line pl-5 dark:border-line-dark',
          )}
        >
          <Text variant="title" tone="primary" style={{ fontSize: 30, lineHeight: 34, letterSpacing: -0.4 }}>
            {stat.value}
          </Text>
          <Text variant="caption" tone="muted" className="mt-1" style={{ letterSpacing: 0.1 }}>
            {stat.label}
          </Text>
        </Pressable>
      ))}
    </View>
  );
}
