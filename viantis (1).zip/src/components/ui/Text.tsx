import React from 'react';
import { Text as RNText, type StyleProp, type TextProps, type TextStyle } from 'react-native';

import { fonts, type FontWeight } from '@/constants/typography';
import { cn } from '@/utils/cn';

type Variant =
  | 'display' // serif, hero numbers / page titles
  | 'title' // serif, screen titles
  | 'heading' // serif, section titles
  | 'subheading' // sans semibold
  | 'body'
  | 'caption'
  | 'label'
  | 'overline';

type Tone = 'default' | 'muted' | 'subtle' | 'primary' | 'inverse' | 'inverseMuted' | 'danger' | 'success';

interface VariantSpec {
  className: string;
  serif?: boolean;
  weight: FontWeight;
}

const variants: Record<Variant, VariantSpec> = {
  display: { className: 'text-[40px] leading-[44px] tracking-[-0.5px]', serif: true, weight: 'regular' },
  title: { className: 'text-[30px] leading-[34px] tracking-[-0.3px]', serif: true, weight: 'regular' },
  heading: { className: 'text-[22px] leading-[26px]', serif: true, weight: 'regular' },
  subheading: { className: 'text-[16px] leading-[22px]', weight: 'semibold' },
  body: { className: 'text-[15px] leading-[22px]', weight: 'regular' },
  caption: { className: 'text-[13px] leading-[18px]', weight: 'regular' },
  label: { className: 'text-[14px] leading-[20px]', weight: 'medium' },
  overline: { className: 'text-[11px] leading-[14px] tracking-[0.6px] uppercase', weight: 'medium' },
};

const tones: Record<Tone, string> = {
  default: 'text-ink dark:text-ink-dark',
  muted: 'text-ink-muted dark:text-ink-muted-dark',
  subtle: 'text-ink-subtle dark:text-ink-subtle-dark',
  primary: 'text-primary-600 dark:text-primary-400',
  inverse: 'text-white',
  inverseMuted: 'text-white/60',
  danger: 'text-danger',
  success: 'text-success',
};

export interface AppTextProps extends TextProps {
  variant?: Variant;
  tone?: Tone;
  /** Overrides the variant's default weight (sans variants only). */
  weight?: FontWeight;
  /** Use the italic serif cut (serif variants only). */
  italic?: boolean;
  className?: string;
}

/** Infer weight from legacy `font-*` utility classes so call sites stay terse. */
const weightFromClassName = (className?: string): FontWeight | undefined => {
  if (!className) return undefined;
  if (/\bfont-bold\b/.test(className)) return 'bold';
  if (/\bfont-semibold\b/.test(className)) return 'semibold';
  if (/\bfont-medium\b/.test(className)) return 'medium';
  if (/\bfont-normal\b/.test(className)) return 'regular';
  return undefined;
};

export function Text({ variant = 'body', tone = 'default', weight, italic, className, style, ...rest }: AppTextProps) {
  const spec = variants[variant];
  const resolvedWeight = weight ?? weightFromClassName(className) ?? spec.weight;
  const fontFamily = spec.serif ? (italic ? fonts.serifItalic : fonts.serif) : fonts.sans[resolvedWeight];

  // fontWeight is pinned to normal so platforms don't try to synthesise a
  // weight the static font file doesn't contain.
  const fontStyle: StyleProp<TextStyle> = [{ fontFamily, fontWeight: 'normal' }, style];

  return <RNText className={cn(spec.className, tones[tone], className)} style={fontStyle} {...rest} />;
}
