import React from 'react';
import { Pressable, View } from 'react-native';

import { cn } from '@/utils/cn';

import { Text } from './Text';

export interface SegmentedControlProps<T extends string> {
  options: { value: T; label: string }[];
  value: T;
  onChange: (value: T) => void;
  className?: string;
}

export function SegmentedControl<T extends string>({ options, value, onChange, className }: SegmentedControlProps<T>) {
  return (
    <View className={cn('flex-row rounded-full bg-surface-muted p-1 dark:bg-surface-muted-dark', className)}>
      {options.map((opt) => {
        const active = opt.value === value;
        return (
          <Pressable
            key={opt.value}
            onPress={() => onChange(opt.value)}
            accessibilityRole="tab"
            accessibilityState={{ selected: active }}
            className={cn(
              'flex-1 items-center justify-center rounded-full py-2',
              active && 'bg-ink shadow-sm dark:bg-ink',
            )}
          >
            <Text
              variant="label"
              className={cn(active ? 'font-semibold text-white' : 'text-ink-muted dark:text-ink-muted-dark')}
            >
              {opt.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}
