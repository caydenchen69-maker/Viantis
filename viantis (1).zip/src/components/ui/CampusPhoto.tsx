import React from 'react';
import { Image, Platform, View, type ImageSourcePropType, type ImageStyle, type ViewStyle } from 'react-native';

import { campusCaptions, campusPhotos, type CampusPhotoId } from '@/constants/campus';
import { cn } from '@/utils/cn';

import { Text } from './Text';

interface Props {
  photo?: CampusPhotoId;
  source?: ImageSourcePropType;
  height: number;
  /** 0–1 dark wash so type stays readable. */
  dim?: number;
  caption?: string | false;
  rounded?: boolean;
  grayscale?: boolean;
  className?: string;
  style?: ViewStyle;
  children?: React.ReactNode;
}

/** Campus still with a light wash so the photo stays bright. */
export function CampusPhoto({
  photo = 'harvard',
  source,
  height,
  dim = 0.26,
  caption,
  rounded = true,
  grayscale = false,
  className,
  style,
  children,
}: Props) {
  const label = caption === false ? undefined : (caption ?? campusCaptions[photo]);
  return (
    <View
      className={cn('overflow-hidden', rounded && 'rounded-2xl', className)}
      style={[{ height }, style]}
    >
      <Image
        source={source ?? campusPhotos[photo]}
        resizeMode="cover"
        style={
          {
            position: 'absolute',
            top: 0,
            right: 0,
            bottom: 0,
            left: 0,
            width: '100%',
            height: '100%',
            ...(Platform.OS === 'web' && grayscale ? { filter: 'grayscale(1) contrast(1.08)' } : null),
          } as ImageStyle
        }
      />
      <View
        pointerEvents="none"
        style={{
          position: 'absolute',
          top: 0,
          right: 0,
          bottom: 0,
          left: 0,
          backgroundColor: `rgba(12, 28, 24, ${dim})`,
        }}
      />
      {children}
      {label && !children && (
        <View className="absolute bottom-3 left-3 right-3">
          <Text variant="caption" tone="inverseMuted">
            {label}
          </Text>
        </View>
      )}
    </View>
  );
}
