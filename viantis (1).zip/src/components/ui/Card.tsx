import React from 'react';
import { Pressable, View, type PressableProps, type ViewProps } from 'react-native';

import { cn } from '@/utils/cn';

type Padding = 'none' | 'sm' | 'md' | 'lg';

const paddingClasses: Record<Padding, string> = {
  none: '',
  sm: 'p-3',
  md: 'p-4',
  lg: 'p-5',
};

const baseClasses =
  'overflow-hidden rounded-[8px] border border-line bg-surface dark:border-line-dark dark:bg-surface-dark';

export interface CardProps extends ViewProps {
  padding?: Padding;
  className?: string;
}

export function Card({ padding = 'md', className, ...rest }: CardProps) {
  return <View className={cn(baseClasses, paddingClasses[padding], className)} {...rest} />;
}

export interface PressableCardProps extends PressableProps {
  padding?: Padding;
  className?: string;
  children?: React.ReactNode;
}

/** Card that responds to touch with a subtle press state. */
export function PressableCard({ padding = 'md', className, children, ...rest }: PressableCardProps) {
  return (
    <Pressable
      className={cn(baseClasses, paddingClasses[padding], 'active:opacity-90 active:scale-[0.99]', className)}
      {...rest}
    >
      {children}
    </Pressable>
  );
}
