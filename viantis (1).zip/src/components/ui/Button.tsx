import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { ActivityIndicator, Pressable, type PressableProps } from 'react-native';

import { palette } from '@/constants/theme';
import { useTheme } from '@/providers/ThemeProvider';
import { cn } from '@/utils/cn';

import { Text } from './Text';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'outline' | 'ink' | 'inverse';
type Size = 'sm' | 'md' | 'lg';

const variantClasses: Record<Variant, string> = {
  primary: 'bg-ink active:opacity-90 dark:bg-ink',
  secondary:
    'bg-cream active:opacity-90 dark:bg-surface-muted-dark',
  ghost: 'bg-transparent active:bg-surface-muted dark:active:bg-surface-muted-dark',
  danger: 'bg-danger active:opacity-90',
  outline:
    'bg-transparent border border-line dark:border-line-dark active:bg-surface-muted dark:active:bg-surface-muted-dark',
  ink: 'bg-ink active:opacity-90 dark:bg-ink',
  inverse: 'bg-white active:bg-white/90',
};

const sizeClasses: Record<Size, string> = {
  sm: 'h-9 px-4 rounded-full',
  md: 'h-11 px-5 rounded-full',
  lg: 'h-[52px] px-6 rounded-full',
};

const textSize: Record<Size, string> = {
  sm: 'text-[13px]',
  md: 'text-[15px]',
  lg: 'text-base',
};

export interface ButtonProps extends Omit<PressableProps, 'children'> {
  label: string;
  variant?: Variant;
  size?: Size;
  icon?: React.ComponentProps<typeof Ionicons>['name'];
  iconPosition?: 'left' | 'right';
  loading?: boolean;
  fullWidth?: boolean;
  className?: string;
}

export function Button({
  label,
  variant = 'primary',
  size = 'md',
  icon,
  iconPosition = 'left',
  loading = false,
  fullWidth = false,
  disabled,
  className,
  ...rest
}: ButtonProps) {
  const { colors } = useTheme();
  // Resolved inline so dark-mode text utilities can't override variant colours.
  const iconColor =
    variant === 'primary' || variant === 'danger' || variant === 'ink'
      ? '#FFFFFF'
      : variant === 'inverse'
          ? palette.charcoal[900]
          : variant === 'secondary'
            ? colors.ink
            : colors.ink;
  const iconSize = size === 'sm' ? 16 : 18;

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled: disabled || loading }}
      disabled={disabled || loading}
      className={cn(
        'flex-row items-center justify-center gap-2',
        variantClasses[variant],
        sizeClasses[size],
        (disabled || loading) && 'opacity-50',
        fullWidth && 'w-full',
        className,
      )}
      {...rest}
    >
      {loading ? (
        <ActivityIndicator size="small" color={iconColor} />
      ) : (
        <>
          {icon && iconPosition === 'left' && <Ionicons name={icon} size={iconSize} color={iconColor} />}
          <Text variant="label" weight="semibold" className={textSize[size]} style={{ color: iconColor }}>
            {label}
          </Text>
          {icon && iconPosition === 'right' && <Ionicons name={icon} size={iconSize} color={iconColor} />}
        </>
      )}
    </Pressable>
  );
}
