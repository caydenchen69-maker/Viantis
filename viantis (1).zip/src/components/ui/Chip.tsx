import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Pressable, View } from 'react-native';

import { useTheme } from '@/providers/ThemeProvider';
import { cn } from '@/utils/cn';

import { Text } from './Text';

export interface ChipProps {
  label: string;
  selected?: boolean;
  onPress?: () => void;
  icon?: React.ComponentProps<typeof Ionicons>['name'];
  /** Custom accent colour (e.g. for tags). Falls back to primary. */
  color?: string;
  size?: 'sm' | 'md';
  className?: string;
}

/** Pill-shaped filter/tag chip. Selectable when `onPress` is provided. */
export function Chip({ label, selected = false, onPress, icon, color, size = 'md', className }: ChipProps) {
  const { colors } = useTheme();
  const fill = color ?? colors.primary;

  const content = (
    <View
      className={cn(
        'flex-row items-center gap-1.5 rounded-full border',
        size === 'sm' ? 'h-7 px-2.5' : 'h-9 px-3.5',
        selected
          ? 'border-transparent'
          : 'border-line bg-surface dark:border-line-dark dark:bg-surface-dark',
        className,
      )}
      style={selected ? { backgroundColor: fill, borderColor: 'transparent' } : undefined}
    >
      {icon && <Ionicons name={icon} size={size === 'sm' ? 12 : 14} color={selected ? '#FFFFFF' : colors.inkMuted} />}
      <Text
        variant={size === 'sm' ? 'caption' : 'label'}
        weight="medium"
        style={{ color: selected ? '#FFFFFF' : colors.inkMuted }}
      >
        {label}
      </Text>
    </View>
  );

  if (!onPress) return content;
  return (
    <Pressable onPress={onPress} accessibilityRole="button" accessibilityState={{ selected }} className="active:opacity-80">
      {content}
    </Pressable>
  );
}
