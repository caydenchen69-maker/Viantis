import React from 'react';
import { View } from 'react-native';

import { cn } from '@/utils/cn';

import { Text } from './Text';

type Tone = 'primary' | 'accent' | 'success' | 'warning' | 'danger' | 'neutral';

const toneClasses: Record<Tone, { bg: string; text: string }> = {
  primary: { bg: 'bg-primary-50 dark:bg-primary-500/15', text: 'text-primary-700 dark:text-primary-300' },
  accent: { bg: 'bg-accent-50 dark:bg-accent-500/15', text: 'text-accent-700 dark:text-accent-300' },
  success: { bg: 'bg-emerald-50 dark:bg-emerald-500/15', text: 'text-emerald-700 dark:text-emerald-300' },
  warning: { bg: 'bg-amber-50 dark:bg-amber-500/15', text: 'text-amber-700 dark:text-amber-300' },
  danger: { bg: 'bg-red-50 dark:bg-red-500/15', text: 'text-red-700 dark:text-red-300' },
  neutral: { bg: 'bg-surface-muted dark:bg-surface-muted-dark', text: 'text-ink-muted dark:text-ink-muted-dark' },
};

export interface BadgeProps {
  label: string;
  tone?: Tone;
  className?: string;
}

export function Badge({ label, tone = 'neutral', className }: BadgeProps) {
  const t = toneClasses[tone];
  return (
    <View className={cn('self-start rounded-full px-2 py-0.5', t.bg, className)}>
      <Text variant="caption" className={cn('font-semibold', t.text)}>
        {label}
      </Text>
    </View>
  );
}
