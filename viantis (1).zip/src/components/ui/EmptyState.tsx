import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { View } from 'react-native';

import { useTheme } from '@/providers/ThemeProvider';
import { cn } from '@/utils/cn';

import { Button } from './Button';
import { Text } from './Text';

export interface EmptyStateProps {
  icon: React.ComponentProps<typeof Ionicons>['name'];
  title: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

export function EmptyState({ icon, title, description, actionLabel, onAction, className }: EmptyStateProps) {
  const { colors } = useTheme();
  return (
    <View className={cn('items-center justify-center px-6 py-10', className)}>
      <Ionicons name={icon} size={28} color={colors.inkMuted} style={{ marginBottom: 14 }} />
      <Text variant="heading" className="text-center" style={{ color: colors.ink }}>
        {title}
      </Text>
      {description && (
        <Text variant="body" className="mt-1.5 max-w-[280px] text-center" style={{ color: colors.inkMuted }}>
          {description}
        </Text>
      )}
      {actionLabel && onAction && (
        <Button label={actionLabel} variant="outline" size="sm" onPress={onAction} className="mt-5" />
      )}
    </View>
  );
}
