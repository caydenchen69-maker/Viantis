import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import {
  Platform,
  TextInput,
  View,
  type NativeSyntheticEvent,
  type TextInputChangeEventData,
  type TextInputProps,
  type TextStyle,
} from 'react-native';

import { fonts } from '@/constants/typography';
import { useTheme } from '@/providers/ThemeProvider';
import { cn } from '@/utils/cn';

import { Text } from './Text';

export interface InputProps extends TextInputProps {
  label?: string;
  icon?: React.ComponentProps<typeof Ionicons>['name'];
  error?: string;
  right?: React.ReactNode;
  containerClassName?: string;
}

export function Input({
  label,
  icon,
  error,
  right,
  containerClassName,
  className,
  multiline,
  onChangeText,
  onChange,
  style,
  ...rest
}: InputProps) {
  const { colors, isDark } = useTheme();
  // Pin fill + type to the same pair so NativeWind / web `color: inherit`
  // cannot paint typed text the same as the field or the page.
  const fieldBg = colors.surface;
  const fieldText = isDark ? '#F6F1E8' : '#111111';
  const fieldPlaceholder = isDark ? '#7A766E' : '#6B6862';

  const handleText = (value: string) => {
    onChangeText?.(value);
  };

  const webFill: TextStyle =
    Platform.OS === 'web'
      ? ({
          caretColor: fieldText,
          WebkitTextFillColor: fieldText,
        } as TextStyle)
      : {};

  return (
    <View className={containerClassName}>
      {label && (
        <Text variant="label" className="mb-1.5" style={{ color: fieldText }}>
          {label}
        </Text>
      )}
      <View
        className={cn(
          'flex-row gap-2 border px-4',
          multiline ? 'items-start rounded-2xl py-1' : 'h-12 items-center rounded-full',
          error ? 'border-danger' : undefined,
        )}
        style={{
          backgroundColor: fieldBg,
          borderColor: error ? colors.danger : colors.line,
        }}
      >
        {icon && <Ionicons name={icon} size={18} color={fieldPlaceholder} />}
        <TextInput
          {...rest}
          className={className}
          multiline={multiline}
          placeholderTextColor={fieldPlaceholder}
          selectionColor={isDark ? '#E55C5C' : '#E8B4B4'}
          onChangeText={handleText}
          onChange={(event: NativeSyntheticEvent<TextInputChangeEventData>) => {
            onChange?.(event);
            const fromNative = event.nativeEvent?.text;
            const fromDom =
              event.target && typeof event.target === 'object' && 'value' in event.target
                ? String((event.target as { value: string }).value)
                : undefined;
            if (typeof fromNative === 'string') handleText(fromNative);
            else if (typeof fromDom === 'string') handleText(fromDom);
          }}
          style={[
            {
              flex: 1,
              fontFamily: fonts.sans.regular,
              fontSize: 15,
              lineHeight: 20,
              color: fieldText,
              backgroundColor: 'transparent',
              paddingVertical: multiline ? 10 : 0,
              minHeight: multiline ? 72 : undefined,
              ...webFill,
            },
            style,
          ]}
        />
        {right}
      </View>
      {error && (
        <Text variant="caption" tone="danger" className="mt-1">
          {error}
        </Text>
      )}
    </View>
  );
}
