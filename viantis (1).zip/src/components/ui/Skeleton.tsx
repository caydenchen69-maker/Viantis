import React, { useEffect } from 'react';
import Animated, { useAnimatedStyle, useSharedValue, withRepeat, withTiming } from 'react-native-reanimated';

import { cn } from '@/utils/cn';

export interface SkeletonProps {
  className?: string;
  width?: number | `${number}%`;
  height?: number;
  rounded?: number;
}

/** Pulsing placeholder used while service calls resolve. */
export function Skeleton({ className, width = '100%', height = 16, rounded = 8 }: SkeletonProps) {
  const opacity = useSharedValue(0.5);
  useEffect(() => {
    opacity.value = withRepeat(withTiming(1, { duration: 800 }), -1, true);
  }, [opacity]);
  const style = useAnimatedStyle(() => ({ opacity: opacity.value }));
  return (
    <Animated.View
      className={cn('bg-surface-muted dark:bg-surface-muted-dark', className)}
      style={[{ width, height, borderRadius: rounded }, style]}
    />
  );
}
