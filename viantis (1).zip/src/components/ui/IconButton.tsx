import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Pressable, type PressableProps } from 'react-native';

import { useTheme } from '@/providers/ThemeProvider';
import { cn } from '@/utils/cn';

export interface IconButtonProps extends PressableProps {
  name: React.ComponentProps<typeof Ionicons>['name'];
  size?: number;
  color?: string;
  variant?: 'plain' | 'soft' | 'solid';
  className?: string;
  accessibilityLabel: string;
}

export function IconButton({
  name,
  size = 20,
  color,
  variant = 'plain',
  className,
  ...rest
}: IconButtonProps) {
  const { colors } = useTheme();
  const resolvedColor = color ?? (variant === 'solid' ? '#FFFFFF' : colors.ink);
  return (
    <Pressable
      accessibilityRole="button"
      hitSlop={6}
      className={cn(
        'h-10 w-10 items-center justify-center rounded-full active:opacity-80',
        variant === 'soft' && 'bg-surface-muted dark:bg-surface-muted-dark',
        variant === 'solid' && 'bg-primary-600 dark:bg-primary-500',
        className,
      )}
      {...rest}
    >
      <Ionicons name={name} size={size} color={resolvedColor} />
    </Pressable>
  );
}
