import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Pressable, View } from 'react-native';

import { useTheme } from '@/providers/ThemeProvider';
import { cn } from '@/utils/cn';

import { Text } from './Text';

export interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

export function SectionHeader({ title, subtitle, actionLabel, onAction, className }: SectionHeaderProps) {
  const { colors } = useTheme();
  return (
    <View className={cn('mb-4 flex-row items-end justify-between', className)}>
      <View className="flex-1 pr-3">
        <Text variant="heading">{title}</Text>
        {subtitle && (
          <Text variant="caption" tone="muted" className="mt-0.5">
            {subtitle}
          </Text>
        )}
      </View>
      {actionLabel && onAction && (
        <Pressable onPress={onAction} hitSlop={8} className="flex-row items-center gap-0.5 active:opacity-70">
          <Text variant="label" tone="muted">
            {actionLabel}
          </Text>
          <Ionicons name="arrow-forward" size={14} color={colors.inkMuted} />
        </Pressable>
      )}
    </View>
  );
}
