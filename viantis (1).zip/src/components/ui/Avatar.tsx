import React from 'react';
import { View } from 'react-native';

import type { AvatarConfig } from '@/types';
import { cn } from '@/utils/cn';

import { Text } from './Text';

const frameColors: Record<NonNullable<AvatarConfig['frame']>, string | null> = {
  none: null,
  bronze: '#B45309',
  silver: '#94A3B8',
  gold: '#D97706',
};

export interface AvatarProps {
  avatar: AvatarConfig;
  /** Display name used for the monogram. */
  name: string;
  size?: number;
  className?: string;
}

/** Monogram avatar: soft tinted disc with a serif initial. */
export function Avatar({ avatar, name, size = 40, className }: AvatarProps) {
  const frame = avatar.frame ? frameColors[avatar.frame] : null;
  const initial = name.trim().charAt(0).toUpperCase() || '·';
  return (
    <View
      className={cn('items-center justify-center rounded-full', className)}
      style={{
        width: size,
        height: size,
        backgroundColor: avatar.background,
        borderWidth: frame ? Math.max(1.5, size * 0.05) : 0,
        borderColor: frame ?? 'transparent',
      }}
    >
      <Text
        variant="heading"
        style={{ fontSize: size * 0.5, lineHeight: size * 0.6, color: avatar.foreground ?? '#1F2937' }}
      >
        {initial}
      </Text>
    </View>
  );
}
