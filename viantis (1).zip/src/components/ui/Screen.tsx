import React from 'react';
import { RefreshControl, ScrollView, View, type ScrollViewProps } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useTheme } from '@/providers/ThemeProvider';
import { cn } from '@/utils/cn';

export interface ScreenProps extends ScrollViewProps {
  children: React.ReactNode;
  /** Use a plain View instead of ScrollView (for lists that scroll themselves). */
  scroll?: boolean;
  /** Apply top safe-area padding (disable when a navigation header is shown). */
  safeTop?: boolean;
  padded?: boolean;
  refreshing?: boolean;
  onRefresh?: () => void;
  className?: string;
  contentClassName?: string;
}

/**
 * Standard screen shell: canvas background, safe-area handling and consistent
 * horizontal padding. Every screen should render inside one of these.
 */
export function Screen({
  children,
  scroll = true,
  safeTop = true,
  padded = true,
  refreshing = false,
  onRefresh,
  className,
  contentClassName,
  ...rest
}: ScreenProps) {
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const paddingTop = safeTop ? insets.top + 8 : 0;

  if (!scroll) {
    return (
      <View
        className={cn('flex-1 bg-canvas dark:bg-canvas-dark', padded && 'px-5', className)}
        style={{ paddingTop }}
      >
        {children}
      </View>
    );
  }

  return (
    <ScrollView
      className={cn('flex-1 bg-canvas dark:bg-canvas-dark', className)}
      contentContainerClassName={cn(padded && 'px-5', 'pb-8', contentClassName)}
      contentContainerStyle={{ paddingTop }}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
      refreshControl={
        onRefresh ? (
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
        ) : undefined
      }
      {...rest}
    >
      {children}
    </ScrollView>
  );
}
