import React from 'react';
import { View } from 'react-native';

import { useTheme } from '@/providers/ThemeProvider';
import { cn } from '@/utils/cn';
import { clamp } from '@/utils/format';

export interface ProgressBarProps {
  /** 0–1 */
  value: number;
  color?: string;
  trackClassName?: string;
  height?: number;
  className?: string;
}

export function ProgressBar({ value, color, height = 6, className, trackClassName }: ProgressBarProps) {
  const { colors } = useTheme();
  return (
    <View
      className={cn('w-full overflow-hidden rounded-full bg-surface-muted dark:bg-surface-muted-dark', trackClassName, className)}
      style={{ height }}
      accessibilityRole="progressbar"
      accessibilityValue={{ min: 0, max: 100, now: Math.round(clamp(value, 0, 1) * 100) }}
    >
      <View
        className="h-full rounded-full"
        style={{ width: `${clamp(value, 0, 1) * 100}%`, backgroundColor: color ?? colors.primary }}
      />
    </View>
  );
}
