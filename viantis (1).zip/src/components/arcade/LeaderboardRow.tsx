import React from 'react';
import { View } from 'react-native';

import { Avatar, Text } from '@/components/ui';
import type { LeaderboardEntry } from '@/types';
import { cn } from '@/utils/cn';
import { formatCompact } from '@/utils/format';

interface Props {
  entry: LeaderboardEntry;
  last?: boolean;
}

/** Hairline-divided leaderboard row; rank as a serif numeral. */
export function LeaderboardRow({ entry, last = false }: Props) {
  return (
    <View
      className={cn(
        'flex-row items-center gap-3.5 py-3',
        !last && 'border-b border-line dark:border-line-dark',
      )}
    >
      <Text
        variant="heading"
        tone={entry.rank <= 3 ? 'default' : 'subtle'}
        className="w-7"
        style={{ fontSize: 20, lineHeight: 24, fontVariant: ['tabular-nums'] }}
      >
        {entry.rank}
      </Text>
      <Avatar avatar={entry.user.avatar} name={entry.user.displayName} size={36} />
      <View className="flex-1">
        <View className="flex-row items-center gap-1.5">
          <Text variant="body" weight="medium">
            {entry.user.displayName}
          </Text>
          {entry.isCurrentUser && (
            <Text variant="caption" tone="primary">
              you
            </Text>
          )}
        </View>
        <Text variant="caption" tone="muted">
          Level {entry.user.level}
          {entry.isFriend && !entry.isCurrentUser ? ' · friend' : ''}
        </Text>
      </View>
      <Text variant="body" weight="medium" style={{ fontVariant: ['tabular-nums'] }}>
        {formatCompact(entry.xp)}
        <Text variant="caption" tone="subtle">
          {' '}
          XP
        </Text>
      </Text>
    </View>
  );
}
