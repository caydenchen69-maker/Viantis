import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { View } from 'react-native';

import { Button, Text } from '@/components/ui';
import { useTheme } from '@/providers/ThemeProvider';
import type { Deck } from '@/types';

interface Props {
  deck: Deck;
  subjectName?: string;
  subjectColor: string;
  alreadyAdded?: boolean;
  busy?: boolean;
  onPlay: () => void;
  onAdd: () => void;
  onOpenMine?: () => void;
}

export function SharedDeckCard({
  deck,
  subjectName,
  subjectColor,
  alreadyAdded,
  busy,
  onPlay,
  onAdd,
  onOpenMine,
}: Props) {
  const { colors } = useTheme();
  return (
    <View className="rounded-[8px] border border-line bg-surface p-4 dark:border-line-dark dark:bg-surface-dark">
      <View className="flex-row items-start gap-3">
        <View className="mt-1.5 h-2 w-2 rounded-full" style={{ backgroundColor: subjectColor }} />
        <View className="flex-1">
          <Text variant="body" weight="semibold">
            {deck.title}
          </Text>
          <Text variant="caption" tone="muted" className="mt-0.5">
            {deck.cardCount} {deck.cardCount === 1 ? 'card' : 'cards'}
            {subjectName ? ` · ${subjectName}` : ''}
            {deck.authorName ? ` · ${deck.authorName}` : ''}
          </Text>
        </View>
        <Ionicons name="people-outline" size={16} color={colors.inkSubtle} />
      </View>
      <View className="mt-3 flex-row gap-2">
        <Button label="Play" variant="outline" size="sm" icon="play-outline" onPress={onPlay} className="flex-1" />
        {alreadyAdded ? (
          <Button
            label="In your decks"
            variant="secondary"
            size="sm"
            icon="checkmark"
            onPress={onOpenMine}
            className="flex-1"
          />
        ) : (
          <Button
            label="Add to mine"
            variant="ink"
            size="sm"
            icon="download-outline"
            loading={busy}
            onPress={onAdd}
            className="flex-1"
          />
        )}
      </View>
    </View>
  );
}
