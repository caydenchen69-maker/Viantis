import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Pressable, View } from 'react-native';

import { gameMark } from '@/components/icons';
import { Text } from '@/components/ui';
import { tintFor } from '@/constants/theme';
import { useTheme } from '@/providers/ThemeProvider';
import type { ArcadeGame } from '@/types';
import { formatCompact } from '@/utils/format';

interface Props {
  game: ArcadeGame;
  onPress: (game: ArcadeGame) => void;
}

/** Muted paper-tint card with a serif title. Colour is the only ornament. */
export function GameCard({ game, onPress }: Props) {
  const { isDark } = useTheme();
  const tint = tintFor(game.tint, isDark);
  return (
    <Pressable
      onPress={() => onPress(game)}
      className="rounded-2xl p-5 active:opacity-90"
      style={{ backgroundColor: tint.bg }}
    >
      <View className="flex-row items-start justify-between">
        {(() => {
          const Mark = gameMark(game.icon);
          return <Mark color={tint.fg} size={26} />;
        })()}
        <View className="items-end">
          <Text variant="caption" style={{ color: tint.fg, opacity: 0.65 }}>
            Best
          </Text>
          <Text variant="heading" style={{ color: tint.fg, fontSize: 20, lineHeight: 24 }}>
            {formatCompact(game.bestScore)}
          </Text>
        </View>
      </View>
      <Text variant="title" className="mt-8" style={{ color: tint.fg }}>
        {game.title}
      </Text>
      <Text variant="body" className="mt-1" style={{ color: tint.fg, opacity: 0.7 }}>
        {game.tagline}
      </Text>
      <View className="mt-5 flex-row items-center justify-between">
        <Text variant="caption" style={{ color: tint.fg, opacity: 0.7 }}>
          +{game.xpPerRound} XP · {game.durationLabel}
        </Text>
        <View className="flex-row items-center gap-1">
          <Text variant="label" style={{ color: tint.fg }}>
            Play
          </Text>
          <Ionicons name="arrow-forward" size={14} color={tint.fg} />
        </View>
      </View>
    </Pressable>
  );
}
