import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import React, { useEffect, useRef, useState } from 'react';
import { Platform, Pressable, View } from 'react-native';

import { Text } from '@/components/ui';
import type { GameId, QuizQuestion } from '@/types';
import { cn } from '@/utils/cn';

export interface RoundResult {
  correct: number;
  total: number;
  bestStreak: number;
  score: number;
}

interface Props {
  gameId: Extract<GameId, 'space_shooter' | 'trivia_tower'>;
  questions: QuizQuestion[];
  /** Seconds per question. */
  secondsPerQuestion?: number;
  onFinish: (result: RoundResult) => void;
}

const MAX_LIVES = 2;

/**
 * Shared multiple-choice engine. Space Shooter renders answers as incoming
 * asteroids with a countdown; Trivia Tower stacks a floor per correct answer
 * and topples after two misses.
 */
export function QuizRound({ gameId, questions, secondsPerQuestion = 12, onFinish }: Props) {
  const [index, setIndex] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [correct, setCorrect] = useState(0);
  const [streak, setStreak] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);
  const [lives, setLives] = useState(MAX_LIVES);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(secondsPerQuestion);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const question = questions[index];
  const isTower = gameId === 'trivia_tower';

  const finish = (finalCorrect: number, finalScore: number, finalBest: number) =>
    onFinish({ correct: finalCorrect, total: questions.length, bestStreak: finalBest, score: finalScore });

  const stopTimer = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = null;
  };

  const advance = (nextCorrect: number, nextScore: number, nextBest: number, nextLives: number) => {
    setTimeout(() => {
      if (isTower && nextLives <= 0) return finish(nextCorrect, nextScore, nextBest);
      if (index + 1 >= questions.length) return finish(nextCorrect, nextScore, nextBest);
      setIndex((i) => i + 1);
      setPicked(null);
      setTimeLeft(secondsPerQuestion);
    }, 900);
  };

  const answer = (choice: number | null) => {
    if (picked !== null || !question) return;
    stopTimer();
    setPicked(choice ?? -1);
    const isRight = choice === question.answerIndex;
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(isRight ? Haptics.ImpactFeedbackStyle.Medium : Haptics.ImpactFeedbackStyle.Heavy).catch(() => {});
    }
    const nextStreak = isRight ? streak + 1 : 0;
    const nextBest = Math.max(bestStreak, nextStreak);
    const speedBonus = isRight ? Math.round((timeLeft / secondsPerQuestion) * 50) : 0;
    const gained = isRight ? 100 + speedBonus + Math.min(nextStreak - 1, 5) * 20 : 0;
    const nextCorrect = correct + (isRight ? 1 : 0);
    const nextScore = score + gained;
    const nextLives = isRight ? lives : lives - 1;
    setStreak(nextStreak);
    setBestStreak(nextBest);
    setCorrect(nextCorrect);
    setScore(nextScore);
    setLives(nextLives);
    advance(nextCorrect, nextScore, nextBest, nextLives);
  };

  useEffect(() => {
    if (picked !== null) return;
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          stopTimer();
          answer(null);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return stopTimer;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index, picked]);

  if (!question) return null;

  const timeRatio = timeLeft / secondsPerQuestion;

  return (
    <View className="flex-1">
      {/* HUD */}
      <View className="mb-4 flex-row items-center justify-between">
        <Text variant="label" className="text-white/80">
          {index + 1} / {questions.length}
        </Text>
        <View className="flex-row items-center gap-3">
          {isTower ? (
            <View className="flex-row gap-1">
              {Array.from({ length: MAX_LIVES }).map((_, i) => (
                <Ionicons key={i} name={i < lives ? 'heart' : 'heart-outline'} size={18} color="#FFFFFF" />
              ))}
            </View>
          ) : (
            <View className="flex-row items-center gap-1">
              <Ionicons name="flame" size={16} color="#FDE68A" />
              <Text variant="label" className="text-white">
                ×{streak}
              </Text>
            </View>
          )}
          <Text variant="label" className="font-bold text-white">
            {score}
          </Text>
        </View>
      </View>

      {/* Timer bar */}
      <View className="mb-6 h-1.5 overflow-hidden rounded-full bg-white/20">
        <View className="h-full rounded-full bg-white" style={{ width: `${timeRatio * 100}%` }} />
      </View>

      {/* Scene */}
      {isTower ? (
        <View className="mb-6 h-24 flex-row items-end justify-center gap-1">
          {Array.from({ length: Math.max(correct, 1) }).map((_, i) => (
            <View key={i} className="h-full w-6 items-center justify-end">
              <View className="w-6 rounded-sm bg-white/90" style={{ height: 10 + (i % 3) * 4 }} />
            </View>
          ))}
          <View className="absolute -top-1 rounded-full bg-white/20 px-3 py-1">
            <Text variant="caption" tone="inverse" className="font-semibold">
              Floor {correct}
            </Text>
          </View>
        </View>
      ) : (
        <View className="mb-6 items-center">
          <Ionicons name="rocket" size={44} color="#FFFFFF" style={{ transform: [{ rotate: '-45deg' }] }} />
          <Text variant="caption" className="mt-1 text-white/70">
            Shoot the right asteroid
          </Text>
        </View>
      )}

      {/* Prompt */}
      <View className="mb-5 rounded-2xl bg-white/15 p-5">
        <Text variant="heading" tone="inverse" className="text-center">
          {question.prompt}
        </Text>
      </View>

      {/* Choices */}
      <View className={cn(isTower ? 'gap-2.5' : 'flex-row flex-wrap justify-between gap-y-3')}>
        {question.choices.map((choice, i) => {
          const isAnswer = i === question.answerIndex;
          const isPicked = picked === i;
          const revealed = picked !== null;
          return (
            <Pressable
              key={i}
              onPress={() => answer(i)}
              disabled={revealed}
              accessibilityRole="button"
              className={cn(
                'items-center justify-center border-2 border-transparent active:opacity-90',
                isTower ? 'rounded-2xl px-4 py-4' : 'w-[48%] rounded-full px-3 py-6',
                !revealed && 'bg-white/90',
                revealed && isAnswer && 'border-white bg-emerald-400',
                revealed && isPicked && !isAnswer && 'bg-red-400',
                revealed && !isPicked && !isAnswer && 'bg-white/40',
              )}
            >
              <Text
                variant="label"
                weight="semibold"
                className="text-center"
                style={{ color: revealed && (isAnswer || isPicked) ? '#FFFFFF' : '#0A2430' }}
              >
                {choice}
              </Text>
            </Pressable>
          );
        })}
      </View>

      {picked !== null && question.explanation && (
        <View className="mt-4 rounded-xl bg-black/20 p-3">
          <Text variant="caption" tone="inverse">
            {question.explanation}
          </Text>
        </View>
      )}
    </View>
  );
}
