import * as Haptics from 'expo-haptics';
import React, { useEffect, useMemo, useState } from 'react';
import { Platform, Pressable, View } from 'react-native';

import { Text } from '@/components/ui';
import type { Flashcard } from '@/types';
import { cn } from '@/utils/cn';

import type { RoundResult } from './QuizRound';

interface Tile {
  key: string;
  cardId: string;
  side: 'front' | 'back';
  label: string;
}

interface Props {
  cards: Flashcard[];
  pairs?: number;
  onFinish: (result: RoundResult) => void;
}

const shuffle = <T,>(list: T[]) => [...list].sort(() => Math.random() - 0.5);

/** Memory-match board: pair each term with its definition. */
export function MatchGrid({ cards, pairs = 6, onFinish }: Props) {
  const tiles = useMemo<Tile[]>(() => {
    const chosen = shuffle(cards).slice(0, pairs);
    return shuffle(
      chosen.flatMap((c) => [
        { key: `${c.id}-f`, cardId: c.id, side: 'front' as const, label: c.front },
        { key: `${c.id}-b`, cardId: c.id, side: 'back' as const, label: c.back },
      ]),
    );
  }, [cards, pairs]);

  const [selected, setSelected] = useState<string[]>([]);
  const [matched, setMatched] = useState<Set<string>>(new Set());
  const [attempts, setAttempts] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const [mismatch, setMismatch] = useState<string[]>([]);

  useEffect(() => {
    const t = setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (matched.size === tiles.length && tiles.length > 0) {
      const total = tiles.length / 2;
      const accuracy = total / Math.max(attempts, total);
      const score = Math.round(total * 200 * accuracy + Math.max(0, 120 - seconds) * 5);
      setTimeout(() => onFinish({ correct: total, total, bestStreak: 0, score }), 600);
    }
  }, [matched, tiles.length, attempts, seconds, onFinish]);

  const tap = (tile: Tile) => {
    if (matched.has(tile.key) || selected.includes(tile.key) || selected.length === 2) return;
    const next = [...selected, tile.key];
    setSelected(next);
    if (next.length < 2) return;

    setAttempts((a) => a + 1);
    const [a, b] = next.map((k) => tiles.find((t) => t.key === k)!);
    const isMatch = a!.cardId === b!.cardId && a!.side !== b!.side;
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(isMatch ? Haptics.ImpactFeedbackStyle.Medium : Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    }
    if (isMatch) {
      setMatched((m) => new Set([...m, a!.key, b!.key]));
      setSelected([]);
    } else {
      setMismatch(next);
      setTimeout(() => {
        setSelected([]);
        setMismatch([]);
      }, 700);
    }
  };

  return (
    <View className="flex-1">
      <View className="mb-4 flex-row items-center justify-between">
        <Text variant="label" className="text-white/80">
          {matched.size / 2} / {tiles.length / 2} pairs
        </Text>
        <Text variant="label" className="text-white/80">
          {attempts} tries · {seconds}s
        </Text>
      </View>
      <View className="flex-row flex-wrap justify-between gap-y-2.5">
        {tiles.map((tile) => {
          const isMatched = matched.has(tile.key);
          const isSelected = selected.includes(tile.key);
          const isWrong = mismatch.includes(tile.key);
          return (
            <Pressable
              key={tile.key}
              onPress={() => tap(tile)}
              disabled={isMatched}
              className={cn(
                'w-[48%] min-h-[84px] items-center justify-center rounded-2xl border-2 px-3 py-3 active:opacity-90',
                isMatched && 'border-emerald-300 bg-emerald-400/70',
                isWrong && 'border-red-300 bg-red-400/80',
                !isMatched && !isWrong && isSelected && 'border-white bg-white',
                !isMatched && !isWrong && !isSelected && 'border-transparent bg-white/85',
              )}
            >
              <Text
                variant="overline"
                style={{ color: isMatched || isWrong ? 'rgba(255,255,255,0.85)' : '#3A5A68' }}
              >
                {tile.side === 'front' ? 'Term' : 'Definition'}
              </Text>
              <Text
                variant="caption"
                weight="semibold"
                className="mt-1 text-center"
                style={{ color: isMatched || isWrong ? '#FFFFFF' : '#0A2430' }}
                numberOfLines={4}
              >
                {tile.label}
              </Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}
