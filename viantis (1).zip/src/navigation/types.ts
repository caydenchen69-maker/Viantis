import type { BottomTabScreenProps } from '@react-navigation/bottom-tabs';
import type { CompositeScreenProps, NavigatorScreenParams } from '@react-navigation/native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';

import type { GameId } from '@/types';

// ---------- Schedule tab (Dashboard is the landing screen) ----------
export type ScheduleStackParamList = {
  Dashboard: undefined;
  Planner: { date?: string } | undefined;
};

// ---------- Bottom tabs ----------
export type TabParamList = {
  ScheduleTab: NavigatorScreenParams<ScheduleStackParamList>;
  ArcadeTab: undefined;
  AIHelperTab: { prompt?: string } | undefined;
  FinderTab: undefined;
  CommunityTab: undefined;
};

// ---------- Root stack (tabs + full-screen detail routes) ----------
export type RootStackParamList = {
  Tabs: NavigatorScreenParams<TabParamList>;
  Pomodoro: { taskId?: string } | undefined;
  TaskEditor: { taskId?: string; date?: string } | undefined;
  Game: { gameId: GameId; deckId?: string };
  DeckLibrary: undefined;
  DeckEditor: { deckId: string };
  Leaderboard: undefined;
  SchoolDetail: { schoolId: string };
  PostDetail: { postId: string };
  CreatePost: undefined;
  CommunityChat: { roomId?: string } | undefined;
  Settings: undefined;
  Auth: undefined;
  Legal: { doc: import('@/content/legal').LegalDocId };
};

export type RootStackScreenProps<T extends keyof RootStackParamList> = NativeStackScreenProps<
  RootStackParamList,
  T
>;

export type TabScreenProps<T extends keyof TabParamList> = CompositeScreenProps<
  BottomTabScreenProps<TabParamList, T>,
  NativeStackScreenProps<RootStackParamList>
>;

export type ScheduleScreenProps<T extends keyof ScheduleStackParamList> = CompositeScreenProps<
  NativeStackScreenProps<ScheduleStackParamList, T>,
  TabScreenProps<'ScheduleTab'>
>;

declare global {
   
  namespace ReactNavigation {
    // eslint-disable-next-line @typescript-eslint/no-empty-object-type
    interface RootParamList extends RootStackParamList {}
  }
}
