import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React from 'react';

import { DashboardScreen } from '@/screens/dashboard/DashboardScreen';
import { PlannerScreen } from '@/screens/schedule/PlannerScreen';

import type { ScheduleStackParamList } from './types';

const Stack = createNativeStackNavigator<ScheduleStackParamList>();

export function ScheduleStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Dashboard" component={DashboardScreen} />
      <Stack.Screen name="Planner" component={PlannerScreen} />
    </Stack.Navigator>
  );
}
