import { DarkTheme, DefaultTheme, type Theme } from '@react-navigation/native';

import { darkColors, lightColors } from '@/constants/theme';

const fonts = DefaultTheme.fonts;

export const lightNavigationTheme: Theme = {
  ...DefaultTheme,
  fonts,
  colors: {
    ...DefaultTheme.colors,
    primary: lightColors.primary,
    background: lightColors.canvas,
    card: lightColors.surface,
    text: lightColors.ink,
    border: lightColors.line,
    notification: lightColors.accent,
  },
};

export const darkNavigationTheme: Theme = {
  ...DarkTheme,
  fonts,
  colors: {
    ...DarkTheme.colors,
    primary: darkColors.primary,
    background: darkColors.canvas,
    card: darkColors.surface,
    text: darkColors.ink,
    border: darkColors.line,
    notification: darkColors.accent,
  },
};
