import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import React from 'react';

import { fonts } from '@/constants/typography';
import { useTheme } from '@/providers/ThemeProvider';
import { DeckEditorScreen } from '@/screens/arcade/DeckEditorScreen';
import { DeckLibraryScreen } from '@/screens/arcade/DeckLibraryScreen';
import { GameScreen } from '@/screens/arcade/GameScreen';
import { LeaderboardScreen } from '@/screens/arcade/LeaderboardScreen';
import { AuthScreen } from '@/screens/auth/AuthScreen';
import { CommunityChatScreen } from '@/screens/community/CommunityChatScreen';
import { CreatePostScreen } from '@/screens/community/CreatePostScreen';
import { PostDetailScreen } from '@/screens/community/PostDetailScreen';
import { SchoolDetailScreen } from '@/screens/finder/SchoolDetailScreen';
import { PomodoroScreen } from '@/screens/schedule/PomodoroScreen';
import { TaskEditorScreen } from '@/screens/schedule/TaskEditorScreen';
import { LegalDocumentScreen, legalTitle } from '@/screens/legal/LegalDocumentScreen';
import { SettingsScreen } from '@/screens/settings/SettingsScreen';

import { linking } from './linking';
import { darkNavigationTheme, lightNavigationTheme } from './navigationTheme';
import { TabNavigator } from './TabNavigator';
import type { RootStackParamList } from './types';

const Stack = createNativeStackNavigator<RootStackParamList>();

export function RootNavigator() {
  const { isDark, colors } = useTheme();

  return (
    <NavigationContainer theme={isDark ? darkNavigationTheme : lightNavigationTheme} linking={linking}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <Stack.Navigator
        screenOptions={{
          headerShown: true,
          headerShadowVisible: false,
          headerTintColor: colors.ink,
          headerTitleStyle: { fontFamily: fonts.sans.medium, fontWeight: 'normal', fontSize: 16 },
          headerStyle: { backgroundColor: colors.canvas },
          contentStyle: { backgroundColor: colors.canvas },
          headerBackButtonDisplayMode: 'minimal',
        }}
      >
        <Stack.Screen name="Tabs" component={TabNavigator} options={{ headerShown: false }} />

        <Stack.Group>
          <Stack.Screen name="Pomodoro" component={PomodoroScreen} options={{ title: 'Focus' }} />
          <Stack.Screen name="TaskEditor" component={TaskEditorScreen} options={{ title: 'Task', presentation: 'modal' }} />
          <Stack.Screen name="Leaderboard" component={LeaderboardScreen} options={{ title: 'Leaderboard' }} />
          <Stack.Screen name="DeckLibrary" component={DeckLibraryScreen} options={{ title: 'Decks' }} />
          <Stack.Screen name="DeckEditor" component={DeckEditorScreen} options={{ title: 'Edit deck' }} />
          <Stack.Screen name="SchoolDetail" component={SchoolDetailScreen} options={{ title: '' }} />
          <Stack.Screen name="PostDetail" component={PostDetailScreen} options={{ title: 'Post' }} />
          <Stack.Screen name="CreatePost" component={CreatePostScreen} options={{ title: 'New post', presentation: 'modal' }} />
          <Stack.Screen name="CommunityChat" component={CommunityChatScreen} options={{ title: 'Study lounge' }} />
          <Stack.Screen name="Settings" component={SettingsScreen} options={{ title: 'Settings', presentation: 'modal' }} />
          <Stack.Screen
            name="Legal"
            component={LegalDocumentScreen}
            options={({ route }) => ({ title: legalTitle(route.params?.doc ?? 'accessibility') })}
          />
        </Stack.Group>

        <Stack.Group screenOptions={{ headerShown: false, presentation: 'fullScreenModal' }}>
          <Stack.Screen name="Game" component={GameScreen} />
          <Stack.Screen name="Auth" component={AuthScreen} />
        </Stack.Group>
      </Stack.Navigator>
    </NavigationContainer>
  );
}
