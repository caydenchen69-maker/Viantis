import type { LinkingOptions } from '@react-navigation/native';

import type { RootStackParamList } from './types';

export const linking: LinkingOptions<RootStackParamList> = {
  prefixes: ['viantis://', 'https://viantis.app', 'https://caydenchen69-maker.github.io/Viantis'],
  config: {
    screens: {
      Tabs: {
        screens: {
          ScheduleTab: {
            screens: {
              Dashboard: '',
              Planner: 'planner',
            },
          },
          ArcadeTab: 'arcade',
          AIHelperTab: 'helper',
          FinderTab: 'finder',
          CommunityTab: 'community',
        },
      },
      Pomodoro: 'focus',
      TaskEditor: 'task',
      Game: 'arcade/play/:gameId',
      DeckLibrary: 'arcade/decks',
      DeckEditor: 'arcade/decks/:deckId',
      Leaderboard: 'arcade/leaderboard',
      SchoolDetail: 'schools/:schoolId',
      PostDetail: 'posts/:postId',
      CreatePost: 'posts/new',
      CommunityChat: 'chat/:roomId?',
      Settings: 'settings',
      Auth: 'auth',
      Legal: {
        path: 'legal/:doc',
        parse: {
          doc: (doc: string) => doc,
        },
      },
    },
  },
};
