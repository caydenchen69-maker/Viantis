import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import React from 'react';
import { Platform } from 'react-native';

import {
  ArcadeCabinetMark,
  CompassMark,
  HomeMark,
  LoungeMark,
  TerminalMark,
} from '@/components/icons';
import { fonts } from '@/constants/typography';
import { palette } from '@/constants/theme';
import { useTheme } from '@/providers/ThemeProvider';
import { AIHelperScreen } from '@/screens/ai/AIHelperScreen';
import { ArcadeScreen } from '@/screens/arcade/ArcadeScreen';
import { CommunityScreen } from '@/screens/community/CommunityScreen';
import { FinderScreen } from '@/screens/finder/FinderScreen';

import { ScheduleStack } from './ScheduleStack';
import type { TabParamList } from './types';

const Tab = createBottomTabNavigator<TabParamList>();

const marks: Record<
  keyof TabParamList,
  React.ComponentType<{ color: string; size?: number; focused?: boolean; accent?: string }>
> = {
  ScheduleTab: HomeMark,
  ArcadeTab: ArcadeCabinetMark,
  AIHelperTab: TerminalMark,
  FinderTab: CompassMark,
  CommunityTab: LoungeMark,
};

export function TabNavigator() {
  const { colors } = useTheme();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.ink,
        tabBarInactiveTintColor: colors.tabInactive,
        tabBarStyle: {
          backgroundColor: colors.tabBar,
          borderTopColor: colors.line,
          borderTopWidth: 1,
          height: Platform.OS === 'ios' ? 88 : 68,
          paddingTop: 8,
        },
        tabBarLabelStyle: {
          fontSize: 10,
          fontFamily: fonts.sans.medium,
          fontWeight: 'normal',
          letterSpacing: 0.6,
          textTransform: 'uppercase',
          marginTop: 3,
        },
        tabBarIcon: ({ focused, color }) => {
          const Mark = marks[route.name];
          return <Mark color={color} size={26} focused={focused} accent={palette.coral[500]} />;
        },
      })}
    >
      <Tab.Screen name="ScheduleTab" component={ScheduleStack} options={{ title: 'Home' }} />
      <Tab.Screen name="ArcadeTab" component={ArcadeScreen} options={{ title: 'Arcade' }} />
      <Tab.Screen name="AIHelperTab" component={AIHelperScreen} options={{ title: 'Helper' }} />
      <Tab.Screen name="FinderTab" component={FinderScreen} options={{ title: 'Matches' }} />
      <Tab.Screen name="CommunityTab" component={CommunityScreen} options={{ title: 'Lounge' }} />
    </Tab.Navigator>
  );
}
