import type { School } from '@/types';
import { clamp } from '@/utils/format';

/** Compatibility 0–99 from selectivity + rating. Used on dossier cards. */
export function schoolCompatibility(school: School): number {
  const selectivity = school.acceptanceRate == null ? 0.45 : 1 - school.acceptanceRate;
  const rating = school.rating / 5;
  return Math.round(clamp(selectivity * 52 + rating * 46, 62, 99));
}

export function schoolInstitutionId(school: School): string {
  if (school.institutionId) return school.institutionId;
  const zip = String(Math.abs(school.coordinates.latitude * 10000)).replace('.', '').slice(0, 5);
  return `${school.region}-${zip}`;
}
