const DAY_MS = 24 * 60 * 60 * 1000;

export const WEEKDAY_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
export const MONTH_SHORT = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

export const startOfDay = (date: Date) => {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
};

export const addDays = (date: Date, days: number) => new Date(date.getTime() + days * DAY_MS);

export const isSameDay = (a: Date, b: Date) =>
  a.getFullYear() === b.getFullYear() &&
  a.getMonth() === b.getMonth() &&
  a.getDate() === b.getDate();

export const isToday = (date: Date) => isSameDay(date, new Date());

/** Returns the 7 days of the week that contains `anchor`, starting Monday. */
export const weekAround = (anchor: Date) => {
  const start = startOfDay(anchor);
  const weekday = (start.getDay() + 6) % 7; // Monday = 0
  const monday = addDays(start, -weekday);
  return Array.from({ length: 7 }, (_, i) => addDays(monday, i));
};

export const formatTime = (iso: string | Date) => {
  const d = typeof iso === 'string' ? new Date(iso) : iso;
  const hours = d.getHours();
  const minutes = d.getMinutes().toString().padStart(2, '0');
  const suffix = hours >= 12 ? 'PM' : 'AM';
  return `${((hours + 11) % 12) + 1}:${minutes} ${suffix}`;
};

export const formatShortDate = (iso: string | Date) => {
  const d = typeof iso === 'string' ? new Date(iso) : iso;
  return `${MONTH_SHORT[d.getMonth()]} ${d.getDate()}`;
};

export const formatDueLabel = (iso: string) => {
  const due = new Date(iso);
  const today = startOfDay(new Date());
  const diffDays = Math.round((startOfDay(due).getTime() - today.getTime()) / DAY_MS);
  if (diffDays < 0) return `Overdue · ${formatShortDate(due)}`;
  if (diffDays === 0) return formatTime(due);
  if (diffDays === 1) return `Tomorrow, ${formatTime(due)}`;
  if (diffDays < 7) return `${WEEKDAY_SHORT[due.getDay()]}, ${formatTime(due)}`;
  return formatShortDate(due);
};

/** "Today", "Tomorrow", weekday within a week, else "Sep 12". */
export const dayLabel = (date: Date) => {
  const today = startOfDay(new Date());
  const diffDays = Math.round((startOfDay(date).getTime() - today.getTime()) / DAY_MS);
  if (diffDays < 0) return 'Overdue';
  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Tomorrow';
  if (diffDays < 7) return WEEKDAY_SHORT[date.getDay()]!;
  return formatShortDate(date);
};

export const timeAgo = (iso: string) => {
  const diff = Date.now() - new Date(iso).getTime();
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  const weeks = Math.floor(days / 7);
  if (weeks < 5) return `${weeks}w ago`;
  return formatShortDate(iso);
};

export const greetingForNow = (date = new Date()) => {
  const h = date.getHours();
  if (h < 5) return 'Burning the midnight oil';
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  if (h < 21) return 'Good evening';
  return 'Late night grind';
};

export const formatCountdown = (totalSeconds: number) => {
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
};

/** Helper for mock data: produce an ISO string relative to now. */
export const isoFromNow = (opts: { days?: number; hours?: number; minutes?: number }) => {
  const d = new Date();
  if (opts.days) d.setDate(d.getDate() + opts.days);
  if (opts.hours) d.setHours(d.getHours() + opts.hours);
  if (opts.minutes) d.setMinutes(d.getMinutes() + opts.minutes);
  return d.toISOString();
};

/** Helper for mock data: today at a fixed clock time, offset by days. */
export const isoAt = (hour: number, minute = 0, dayOffset = 0) => {
  const d = addDays(startOfDay(new Date()), dayOffset);
  d.setHours(hour, minute, 0, 0);
  return d.toISOString();
};
