-- Viantis · Supabase schema
-- Run in the SQL editor of a fresh project, then enable Realtime for `messages`.

create extension if not exists "pgcrypto";

-- ---------- Profiles ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  username text unique not null,
  display_name text not null,
  avatar jsonb not null default '{"emoji":"🎓","background":"#E0E7FF"}',
  xp integer not null default 0,
  level integer not null default 1,
  streak_days integer not null default 0,
  longest_streak integer not null default 0,
  last_active_on date,
  school text,
  grade_level text,
  role text not null default 'student' check (role in ('student', 'moderator', 'admin')),
  created_at timestamptz not null default now()
);

-- ---------- Schedule ----------
create table if not exists public.tasks (
  id text primary key,
  user_id uuid not null references public.profiles (id) on delete cascade,
  title text not null,
  subject_id text not null,
  due_at timestamptz not null,
  estimated_minutes integer not null default 25,
  completed_minutes integer not null default 0,
  priority text not null default 'medium' check (priority in ('low', 'medium', 'high')),
  status text not null default 'todo' check (status in ('todo', 'in_progress', 'done')),
  notes text,
  created_at timestamptz not null default now()
);
create index if not exists tasks_user_due_idx on public.tasks (user_id, due_at);

create table if not exists public.study_sessions (
  id text primary key,
  user_id uuid not null references public.profiles (id) on delete cascade,
  task_id text references public.tasks (id) on delete set null,
  started_at timestamptz not null,
  duration_minutes integer not null,
  kind text not null check (kind in ('focus', 'break'))
);
create index if not exists sessions_user_started_idx on public.study_sessions (user_id, started_at desc);

-- ---------- Arcade ----------
create table if not exists public.decks (
  id text primary key,
  user_id uuid not null references public.profiles (id) on delete cascade,
  title text not null,
  subject_id text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.flashcards (
  id text primary key,
  deck_id text not null references public.decks (id) on delete cascade,
  front text not null,
  back text not null
);

create table if not exists public.xp_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  amount integer not null,
  reason text not null,
  created_at timestamptz not null default now()
);

create or replace function public.increment_xp(user_id uuid, amount integer)
returns void language sql security definer as $$
  update public.profiles
  set xp = xp + amount,
      level = greatest(1, floor(sqrt((xp + amount) / 75.0))::int)
  where id = user_id;
$$;

-- ---------- School Finder ----------
create table if not exists public.schools (
  id text primary key,
  name text not null,
  type text not null check (type in ('high_school', 'university', 'community_college')),
  city text not null,
  region text not null,
  country text not null,
  latitude double precision not null,
  longitude double precision not null,
  acceptance_rate numeric(4, 3),
  rating numeric(2, 1) not null default 0,
  review_count integer not null default 0,
  student_count integer,
  tuition_per_year integer,
  majors text[] not null default '{}',
  highlights text[] not null default '{}',
  image_url text,
  website text
);

create table if not exists public.school_reviews (
  id uuid primary key default gen_random_uuid(),
  school_id text not null references public.schools (id) on delete cascade,
  author_id uuid not null references public.profiles (id) on delete cascade,
  rating integer not null check (rating between 1 and 5),
  title text not null,
  body text not null,
  helpful_count integer not null default 0,
  created_at timestamptz not null default now()
);

-- ---------- Community ----------
create table if not exists public.posts (
  id text primary key,
  author_id uuid not null references public.profiles (id) on delete cascade,
  kind text not null check (kind in ('discussion', 'tip', 'review', 'question')),
  title text not null,
  body text not null,
  tags text[] not null default '{}',
  upvotes integer not null default 0,
  comment_count integer not null default 0,
  is_pinned boolean not null default false,
  is_flagged boolean not null default false,
  is_removed boolean not null default false,
  school_id text references public.schools (id),
  created_at timestamptz not null default now()
);
create index if not exists posts_tags_idx on public.posts using gin (tags);

create table if not exists public.comments (
  id text primary key,
  post_id text not null references public.posts (id) on delete cascade,
  parent_id text references public.comments (id) on delete cascade,
  author_id uuid not null references public.profiles (id) on delete cascade,
  body text not null,
  upvotes integer not null default 0,
  is_removed boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.votes (
  user_id uuid not null references public.profiles (id) on delete cascade,
  post_id text references public.posts (id) on delete cascade,
  comment_id text references public.comments (id) on delete cascade,
  value smallint not null check (value in (-1, 1)),
  primary key (user_id, post_id)
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  post_id text references public.posts (id) on delete cascade,
  comment_id text references public.comments (id) on delete cascade,
  reporter_id uuid references public.profiles (id) on delete set null,
  reason text not null,
  resolved boolean not null default false,
  created_at timestamptz not null default now()
);

-- Keep post.upvotes in sync with votes.
create or replace function public.sync_post_votes() returns trigger language plpgsql as $$
begin
  update public.posts p
  set upvotes = coalesce((select sum(value) from public.votes v where v.post_id = p.id), 0)
  where p.id = coalesce(new.post_id, old.post_id);
  return null;
end $$;
drop trigger if exists votes_sync on public.votes;
create trigger votes_sync after insert or update or delete on public.votes
  for each row execute function public.sync_post_votes();

-- ---------- Realtime chat ----------
create table if not exists public.messages (
  id text primary key,
  room_id text not null,
  author_id uuid not null references public.profiles (id) on delete cascade,
  author_name text not null,
  body text not null,
  created_at timestamptz not null default now()
);
create index if not exists messages_room_created_idx on public.messages (room_id, created_at);
alter publication supabase_realtime add table public.messages;

-- ---------- Row Level Security ----------
alter table public.profiles enable row level security;
alter table public.tasks enable row level security;
alter table public.study_sessions enable row level security;
alter table public.decks enable row level security;
alter table public.flashcards enable row level security;
alter table public.xp_events enable row level security;
alter table public.schools enable row level security;
alter table public.school_reviews enable row level security;
alter table public.posts enable row level security;
alter table public.comments enable row level security;
alter table public.votes enable row level security;
alter table public.reports enable row level security;
alter table public.messages enable row level security;

create policy "profiles are public" on public.profiles for select using (true);
create policy "users manage own profile" on public.profiles for all using (auth.uid() = id);

create policy "own tasks" on public.tasks for all using (auth.uid() = user_id);
create policy "own sessions" on public.study_sessions for all using (auth.uid() = user_id);
create policy "own decks" on public.decks for all using (auth.uid() = user_id);
create policy "cards via deck" on public.flashcards for all
  using (exists (select 1 from public.decks d where d.id = deck_id and d.user_id = auth.uid()));
create policy "own xp" on public.xp_events for all using (auth.uid() = user_id);

create policy "schools are public" on public.schools for select using (true);
create policy "reviews are public" on public.school_reviews for select using (true);
create policy "authors write reviews" on public.school_reviews for insert with check (auth.uid() = author_id);

create policy "posts are public" on public.posts for select using (true);
create policy "authors create posts" on public.posts for insert with check (auth.uid() = author_id);
create policy "authors edit posts" on public.posts for update using (auth.uid() = author_id);

create policy "comments are public" on public.comments for select using (true);
create policy "authors create comments" on public.comments for insert with check (auth.uid() = author_id);
create policy "moderators remove comments" on public.comments for update
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('moderator', 'admin')));

create policy "own votes" on public.votes for all using (auth.uid() = user_id);
create policy "anyone can report" on public.reports for insert with check (true);

create policy "messages are public" on public.messages for select using (true);
create policy "authenticated users chat" on public.messages for insert with check (auth.uid() = author_id);
